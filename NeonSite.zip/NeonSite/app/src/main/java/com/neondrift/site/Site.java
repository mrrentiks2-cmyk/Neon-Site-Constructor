package com.neondrift.site;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Сайт: настройки, оформление, общие шапка и подвал, страницы из блоков.
 * Значения блоков — простые словари (строки, флажки, числа, списки пунктов), чтобы проект
 * легко читался человеком и Claude: project.json — это и есть описание сайта.
 */
final class Site {
    static final int VERSION = 1;

    static String newId() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 10);
    }

    // ------------------------------------------------------------------ оформление

    static final class Look {
        String palette = "snow";
        boolean dark;
        String bg = "#FFFFFF", surface = "#F4F5F8", text = "#14161C", muted = "#5E6472", primary = "#2B59FF", onPrimary = "#FFFFFF",
                accent = "#FF7A1A", border = "#E3E6EC";
        String fonts = "modern";
        /** Скругления: none, s, m, l, xl. */
        String radius = "m";
        /** Кнопки: filled, outline, soft, gradient. */
        String buttons = "filled";
        boolean shadows = true;
        /** Ширина содержимого: narrow, normal, wide. */
        String width = "normal";
        /** Плавное появление блоков при прокрутке. */
        boolean animate = true;

        Map<String, Object> toMap() {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            m.put("palette", palette);
            m.put("dark", dark);
            m.put("bg", bg);
            m.put("surface", surface);
            m.put("text", text);
            m.put("muted", muted);
            m.put("primary", primary);
            m.put("onPrimary", onPrimary);
            m.put("accent", accent);
            m.put("border", border);
            m.put("fonts", fonts);
            m.put("radius", radius);
            m.put("buttons", buttons);
            m.put("shadows", shadows);
            m.put("width", width);
            m.put("animate", animate);
            return m;
        }

        static Look from(Map<String, Object> m) {
            Look l = new Look();
            if (m == null) return l;
            l.palette = Json.str(m, "palette", l.palette);
            l.dark = Json.bool(m, "dark");
            l.bg = Json.str(m, "bg", l.bg);
            l.surface = Json.str(m, "surface", l.surface);
            l.text = Json.str(m, "text", l.text);
            l.muted = Json.str(m, "muted", l.muted);
            l.primary = Json.str(m, "primary", l.primary);
            l.onPrimary = Json.str(m, "onPrimary", l.onPrimary);
            l.accent = Json.str(m, "accent", l.accent);
            l.border = Json.str(m, "border", l.border);
            l.fonts = Json.str(m, "fonts", l.fonts);
            l.radius = Json.str(m, "radius", l.radius);
            l.buttons = Json.str(m, "buttons", l.buttons);
            l.shadows = !m.containsKey("shadows") || Json.bool(m, "shadows");
            l.width = Json.str(m, "width", l.width);
            l.animate = !m.containsKey("animate") || Json.bool(m, "animate");
            return l;
        }

        /** Применить готовую палитру. */
        void palette(Themes.Palette p) {
            palette = p.id;
            dark = p.dark;
            bg = p.bg;
            surface = p.surface;
            text = p.text;
            muted = p.muted;
            primary = p.primary;
            onPrimary = p.onPrimary;
            accent = p.accent;
            border = p.border;
        }
    }

    // ------------------------------------------------------------------ блок

    static final class Block {
        String id = newId(), type, variant = "";
        /** Содержимое: поля блока; списки пунктов — под ключом «items». */
        LinkedHashMap<String, Object> v = new LinkedHashMap<>();
        /** Фон: auto, bg, surface, primary, accent, dark, light, color, image. */
        String bg = "auto", bgColor = "", bgImage = "";
        /** Отступы сверху и снизу: none, s, m, l. */
        String pad = "m";
        /** Якорь для ссылок «#about». */
        String anchor = "";
        /** Где показывать: all, mobile, desktop. */
        String show = "all";
        boolean hidden;
        /** Пожелания — для доработки (их увидит Claude в проекте). */
        String notes = "";

        Block() {
        }

        Block(String type, String variant) {
            this.type = type;
            this.variant = variant;
        }

        String s(String k) {
            Object o = v.get(k);
            return o == null ? "" : o instanceof String ? (String) o : String.valueOf(o);
        }

        boolean b(String k) {
            Object o = v.get(k);
            return o instanceof Boolean ? (Boolean) o : "true".equals(o);
        }

        int n(String k, int def) {
            Object o = v.get(k);
            if (o instanceof Number) return ((Number) o).intValue();
            try {
                return o == null ? def : Integer.parseInt(String.valueOf(o).trim());
            } catch (NumberFormatException e) {
                return def;
            }
        }

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> items() {
            Object o = v.get("items");
            if (o instanceof List) return (List<Map<String, Object>>) o;
            List<Map<String, Object>> l = new ArrayList<>();
            v.put("items", l);
            return l;
        }

        Block copy() {
            Block b = from(Json.deep(toMap()));
            b.id = newId();
            return b;
        }

        Map<String, Object> toMap() {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            m.put("id", id);
            m.put("type", type);
            m.put("variant", variant);
            m.put("v", v);
            m.put("bg", bg);
            if (!bgColor.isEmpty()) m.put("bgColor", bgColor);
            if (!bgImage.isEmpty()) m.put("bgImage", bgImage);
            m.put("pad", pad);
            if (!anchor.isEmpty()) m.put("anchor", anchor);
            if (!show.equals("all")) m.put("show", show);
            if (hidden) m.put("hidden", true);
            if (!notes.isEmpty()) m.put("notes", notes);
            return m;
        }

        @SuppressWarnings("unchecked")
        static Block from(Map<String, Object> m) {
            Block b = new Block();
            b.id = Json.str(m, "id", b.id);
            b.type = Json.str(m, "type", "text");
            b.variant = Json.str(m, "variant", "");
            Object v = m.get("v");
            if (v instanceof Map) b.v = new LinkedHashMap<>((Map<String, Object>) v);
            b.bg = Json.str(m, "bg", "auto");
            b.bgColor = Json.str(m, "bgColor", "");
            b.bgImage = Json.str(m, "bgImage", "");
            b.pad = Json.str(m, "pad", "m");
            b.anchor = Json.str(m, "anchor", "");
            b.show = Json.str(m, "show", "all");
            b.hidden = Json.bool(m, "hidden");
            b.notes = Json.str(m, "notes", "");
            return b;
        }
    }

    // ------------------------------------------------------------------ страница

    static final class Page {
        String id = newId(), title = "Страница", slug = "", seoTitle = "", seoDescription = "";
        /** page — обычная страница, post — запись блога (дата, обложка, анонс). */
        String kind = "page";
        String date = "", cover = "", excerpt = "";
        boolean menu = true, noHeader, noFooter;
        final List<Block> blocks = new ArrayList<>();

        boolean post() {
            return kind.equals("post");
        }

        Map<String, Object> toMap() {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            m.put("id", id);
            m.put("title", title);
            m.put("slug", slug);
            m.put("kind", kind);
            if (!seoTitle.isEmpty()) m.put("seoTitle", seoTitle);
            if (!seoDescription.isEmpty()) m.put("seoDescription", seoDescription);
            if (!date.isEmpty()) m.put("date", date);
            if (!cover.isEmpty()) m.put("cover", cover);
            if (!excerpt.isEmpty()) m.put("excerpt", excerpt);
            m.put("menu", menu);
            if (noHeader) m.put("noHeader", true);
            if (noFooter) m.put("noFooter", true);
            List<Object> bl = new ArrayList<>();
            for (Block b : blocks) bl.add(b.toMap());
            m.put("blocks", bl);
            return m;
        }

        @SuppressWarnings("unchecked")
        static Page from(Map<String, Object> m) {
            Page p = new Page();
            p.id = Json.str(m, "id", p.id);
            p.title = Json.str(m, "title", p.title);
            p.slug = Json.str(m, "slug", "");
            p.kind = Json.str(m, "kind", "page");
            p.seoTitle = Json.str(m, "seoTitle", "");
            p.seoDescription = Json.str(m, "seoDescription", "");
            p.date = Json.str(m, "date", "");
            p.cover = Json.str(m, "cover", "");
            p.excerpt = Json.str(m, "excerpt", "");
            p.menu = !m.containsKey("menu") || Json.bool(m, "menu");
            p.noHeader = Json.bool(m, "noHeader");
            p.noFooter = Json.bool(m, "noFooter");
            for (Object o : Json.list(m, "blocks")) if (o instanceof Map) p.blocks.add(Block.from((Map<String, Object>) o));
            return p;
        }
    }

    // ------------------------------------------------------------------ сайт

    String id = newId(), name = "Мой сайт", lang = "ru", domain = "", description = "", favicon = "", ogImage = "";
    /** Код в <head> (счётчики, проверка домена) и свой CSS. */
    String headCode = "", css = "";
    /** Общие пожелания к сайту — для доработки. */
    String notes = "";
    String template = "";
    long created = System.currentTimeMillis(), updated;
    Look look = new Look();
    Block header, footer;
    final List<Page> pages = new ArrayList<>();

    Page home() {
        return pages.isEmpty() ? null : pages.get(0);
    }

    Page page(String id) {
        for (Page p : pages) if (p.id.equals(id)) return p;
        return null;
    }

    /** Блок по id (на любой странице, в шапке или подвале). */
    Block block(String id) {
        if (header != null && header.id.equals(id)) return header;
        if (footer != null && footer.id.equals(id)) return footer;
        for (Page p : pages) for (Block b : p.blocks) if (b.id.equals(id)) return b;
        return null;
    }

    Page pageOf(Block b) {
        for (Page p : pages) if (p.blocks.contains(b)) return p;
        return null;
    }

    /** Имя файла страницы: главная — index.html, остальные — slug.html. */
    String file(Page p) {
        if (p == home()) return "index.html";
        String s = slug(p);
        return s + ".html";
    }

    String slug(Page p) {
        String s = p.slug == null || p.slug.trim().isEmpty() ? Slug.of(p.title) : Slug.of(p.slug);
        if (s.isEmpty() || s.equals("index")) s = "page-" + p.id.substring(0, 4);
        // одинаковые адреса у разных страниц — добавить номер
        int same = 0;
        for (Page o : pages) {
            if (o == p) break;
            if (o != home() && (o.slug == null || o.slug.trim().isEmpty() ? Slug.of(o.title) : Slug.of(o.slug)).equals(s)) same++;
        }
        return same == 0 ? s : s + "-" + (same + 1);
    }

    List<Page> posts() {
        List<Page> l = new ArrayList<>();
        for (Page p : pages) if (p.post()) l.add(p);
        l.sort((a, b) -> b.date.compareTo(a.date));
        return l;
    }

    String toJson() {
        LinkedHashMap<String, Object> m = new LinkedHashMap<>();
        m.put("format", "neon-site");
        m.put("version", (long) VERSION);
        m.put("id", id);
        m.put("name", name);
        m.put("lang", lang);
        m.put("domain", domain);
        m.put("description", description);
        if (!favicon.isEmpty()) m.put("favicon", favicon);
        if (!ogImage.isEmpty()) m.put("ogImage", ogImage);
        if (!headCode.isEmpty()) m.put("headCode", headCode);
        if (!css.isEmpty()) m.put("css", css);
        if (!notes.isEmpty()) m.put("notes", notes);
        if (!template.isEmpty()) m.put("template", template);
        m.put("created", created);
        m.put("updated", updated);
        m.put("look", look.toMap());
        if (header != null) m.put("header", header.toMap());
        if (footer != null) m.put("footer", footer.toMap());
        List<Object> pl = new ArrayList<>();
        for (Page p : pages) pl.add(p.toMap());
        m.put("pages", pl);
        return Json.write(m);
    }

    @SuppressWarnings("unchecked")
    static Site fromJson(String s) {
        Object o = Json.parse(s);
        if (!(o instanceof Map)) throw new IllegalArgumentException("это не проект сайта");
        Map<String, Object> m = (Map<String, Object>) o;
        if (!m.containsKey("pages")) throw new IllegalArgumentException("в проекте нет страниц");
        Site st = new Site();
        st.id = Json.str(m, "id", st.id);
        st.name = Json.str(m, "name", st.name);
        st.lang = Json.str(m, "lang", "ru");
        st.domain = Json.str(m, "domain", "");
        st.description = Json.str(m, "description", "");
        st.favicon = Json.str(m, "favicon", "");
        st.ogImage = Json.str(m, "ogImage", "");
        st.headCode = Json.str(m, "headCode", "");
        st.css = Json.str(m, "css", "");
        st.notes = Json.str(m, "notes", "");
        st.template = Json.str(m, "template", "");
        st.created = Json.num(m, "created", st.created);
        st.updated = Json.num(m, "updated", 0);
        Object lk = m.get("look");
        st.look = Look.from(lk instanceof Map ? (Map<String, Object>) lk : null);
        Object h = m.get("header"), f = m.get("footer");
        if (h instanceof Map) st.header = Block.from((Map<String, Object>) h);
        if (f instanceof Map) st.footer = Block.from((Map<String, Object>) f);
        for (Object po : Json.list(m, "pages")) if (po instanceof Map) st.pages.add(Page.from((Map<String, Object>) po));
        return st;
    }

    /** Содержимое без отметки времени — чтобы сравнивать «изменилось ли что-то». */
    String state() {
        long u = updated;
        updated = 0;
        String j = toJson();
        updated = u;
        return j;
    }

    Site copy() {
        return fromJson(toJson());
    }
}
