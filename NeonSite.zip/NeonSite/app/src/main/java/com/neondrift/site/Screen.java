package com.neondrift.site;

import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Экран приложения: шапка с «назад», содержимое, обновление по сигналу от Hub. */
abstract class Screen extends LinearLayout {
    final MainActivity a;
    final Ui ui;
    final Hub hub;
    TextView titleView, subView;

    Screen(MainActivity a) {
        super(a);
        this.a = a;
        ui = a.ui;
        hub = a.hub;
        setOrientation(VERTICAL);
    }

    /** Шапка: назад, заголовок, подзаголовок; справа — дополнительные кнопки. */
    LinearLayout header(String title, String sub) {
        LinearLayout h = ui.row();
        h.setPadding(ui.dp(4), ui.dp(8), ui.dp(8), ui.dp(8));
        h.addView(ui.iconButton("back", Theme.TEXT, 44, 10, v -> a.back()));
        LinearLayout t = ui.col();
        titleView = ui.oneLine(title, 19, Theme.TEXT, true);
        t.addView(titleView);
        subView = ui.oneLine(sub == null ? "" : sub, 12.5f, Theme.MUTED, false);
        if (sub == null) subView.setVisibility(GONE);
        t.addView(subView, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(2), 0, 0));
        h.addView(t, Ui.lp(0, Ui.WRAP, 1f));
        addView(h);
        return h;
    }

    void setSub(String s) {
        if (subView == null) return;
        subView.setText(s);
        subView.setVisibility(s == null || s.isEmpty() ? GONE : VISIBLE);
    }

    /** Строка с иконкой, текстом и подписью — для списков и карточек. */
    LinearLayout tile(String icon, int color, String title, String sub, Runnable click) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(14), ui.dp(12), ui.dp(12), ui.dp(12));
        row.setBackground(Ui.ripple(Ui.round(Theme.SURFACE, ui.dp(16)), Ui.round(0xFFFFFFFF, ui.dp(16))));
        ImageView ic = new ImageView(a);
        ic.setImageDrawable(new Glyph(icon, color));
        ic.setPadding(ui.dp(9), ui.dp(9), ui.dp(9), ui.dp(9));
        ic.setBackground(Ui.oval(Theme.alpha(color, 40)));
        row.addView(ic, Ui.lp(ui.dp(42), ui.dp(42)));
        LinearLayout texts = ui.col();
        texts.addView(ui.oneLine(title, 15.5f, Theme.TEXT, true));
        if (sub != null && !sub.isEmpty()) {
            TextView s = ui.text(sub, 12.5f, Theme.MUTED, false);
            s.setMaxLines(2);
            texts.addView(s, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(3), 0, 0));
        }
        row.addView(texts, Ui.margins(0, Ui.WRAP, ui.dp(12), 0, 0, 0));
        ((LinearLayout.LayoutParams) texts.getLayoutParams()).weight = 1f;
        if (click != null) row.setOnClickListener(v -> click.run());
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    /** Данные поменялись — перерисовать. */
    void refresh() {
    }

    private long lastBuild;
    private boolean pendingBuild;

    /** Для экранов, которые пересобирают списки: не чаще ~2 раз в секунду, последний вызов не теряется. */
    boolean throttle() {
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastBuild < 400) {
            if (!pendingBuild) {
                pendingBuild = true;
                postDelayed(() -> {
                    pendingBuild = false;
                    refresh();
                }, 420);
            }
            return true;
        }
        lastBuild = now;
        return false;
    }

    void onShown() {
    }

    void onHidden() {
    }

    /** Экран убран из стопки насовсем. */
    void onRemoved() {
    }

    /** true — «назад» обработан самим экраном. */
    boolean back() {
        return false;
    }
}
