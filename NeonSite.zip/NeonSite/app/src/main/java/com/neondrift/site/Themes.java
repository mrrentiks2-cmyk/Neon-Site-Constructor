package com.neondrift.site;

/** Готовые палитры и пары шрифтов (все шрифты — с кириллицей). */
final class Themes {
    private Themes() {}

    static final class Palette {
        final String id, name, bg, surface, text, muted, primary, onPrimary, accent, border;
        final boolean dark;

        Palette(String id, String name, boolean dark, String bg, String surface, String text, String muted, String primary, String onPrimary,
                String accent, String border) {
            this.id = id;
            this.name = name;
            this.dark = dark;
            this.bg = bg;
            this.surface = surface;
            this.text = text;
            this.muted = muted;
            this.primary = primary;
            this.onPrimary = onPrimary;
            this.accent = accent;
            this.border = border;
        }
    }

    static final Palette[] PALETTES = {
            new Palette("snow", "Снег", false, "#FFFFFF", "#F4F5F8", "#14161C", "#5E6472", "#2B59FF", "#FFFFFF", "#FF7A1A", "#E3E6EC"),
            new Palette("graphite", "Графит", false, "#F7F7F5", "#ECECE8", "#111111", "#666662", "#111111", "#FFFFFF", "#E4572E", "#D9D9D3"),
            new Palette("coffee", "Кофе", false, "#FBF7F2", "#F1E8DD", "#2B1E16", "#7A6556", "#8B4A2B", "#FFFFFF", "#D9A441", "#E6D8C8"),
            new Palette("forest", "Лес", false, "#F5F8F4", "#E6EEE4", "#17251B", "#5B6E60", "#2F7D4F", "#FFFFFF", "#E2B23C", "#D3E0D1"),
            new Palette("sea", "Море", false, "#F2F9FB", "#E0F0F4", "#0F2A33", "#4F6D77", "#0E8AA8", "#FFFFFF", "#FFB703", "#CDE4EA"),
            new Palette("sunset", "Закат", false, "#FFF6F1", "#FFE8DC", "#2A1712", "#8A5F52", "#FF5A36", "#FFFFFF", "#7B2FF7", "#F5D3C4"),
            new Palette("lavender", "Лаванда", false, "#F8F6FF", "#EDE8FF", "#1E1838", "#6C6489", "#6C4CF5", "#FFFFFF", "#FF6FB5", "#DCD4FA"),
            new Palette("neon", "Неон", true, "#0B0A12", "#16131F", "#F3F0FF", "#A49CC0", "#FF2D95", "#FFFFFF", "#00E5FF", "#2A2440"),
            new Palette("night", "Ночь", true, "#0E1116", "#171B22", "#E8EDF4", "#8B96A8", "#4F8CFF", "#FFFFFF", "#3DDC97", "#262C36"),
            new Palette("gold", "Золото", true, "#0F0E0C", "#1A1815", "#F2EDE4", "#A59D8F", "#C9A45C", "#14110B", "#E9D8A6", "#2E2A23"),
    };

    static Palette palette(String id) {
        for (Palette p : PALETTES) if (p.id.equals(id)) return p;
        return PALETTES[0];
    }

    static final class Fonts {
        final String id, name, head, body;
        /** Параметр для Google Fonts (пусто — системные шрифты). */
        final String google;
        final int headWeight;

        Fonts(String id, String name, String head, String body, String google, int headWeight) {
            this.id = id;
            this.name = name;
            this.head = head;
            this.body = body;
            this.google = google;
            this.headWeight = headWeight;
        }
    }

    static final Fonts[] FONTS = {
            new Fonts("modern", "Современный", "Manrope", "Manrope", "family=Manrope:wght@400;500;600;700;800", 800),
            new Fonts("strict", "Строгий", "Inter", "Inter", "family=Inter:wght@400;500;600;700;800", 700),
            new Fonts("bold", "Яркий", "Unbounded", "Onest", "family=Unbounded:wght@500;700;800&family=Onest:wght@400;500;600;700", 700),
            new Fonts("elegant", "Элегантный", "Playfair Display", "Lora", "family=Playfair+Display:wght@500;600;700;800&family=Lora:wght@400;500;600", 700),
            new Fonts("friendly", "Дружелюбный", "Rubik", "Rubik", "family=Rubik:wght@400;500;600;700;800", 700),
            new Fonts("classic", "Классика", "PT Serif", "PT Sans", "family=PT+Serif:wght@400;700&family=PT+Sans:wght@400;700", 700),
            new Fonts("geometry", "Геометрия", "Montserrat", "Golos Text", "family=Montserrat:wght@500;600;700;800&family=Golos+Text:wght@400;500;600", 800),
            new Fonts("system", "Системный (без загрузки)", "", "", "", 700),
    };

    static Fonts fonts(String id) {
        for (Fonts f : FONTS) if (f.id.equals(id)) return f;
        return FONTS[0];
    }

    static final String[] RADIUS = {"none", "s", "m", "l", "xl"};
    static final String[] RADIUS_NAMES = {"Без скруглений", "Чуть-чуть", "Средние", "Крупные", "Очень крупные"};
    static final String[] BUTTONS = {"filled", "outline", "soft", "gradient"};
    static final String[] BUTTON_NAMES = {"Заливка", "Контур", "Мягкие", "Градиент"};
    static final String[] WIDTHS = {"narrow", "normal", "wide"};
    static final String[] WIDTH_NAMES = {"Узкая", "Обычная", "Широкая"};

    static int radiusPx(String r) {
        switch (r) {
            case "none": return 0;
            case "s": return 6;
            case "l": return 20;
            case "xl": return 28;
            default: return 12;
        }
    }

    static int widthPx(String w) {
        switch (w) {
            case "narrow": return 960;
            case "wide": return 1320;
            default: return 1160;
        }
    }
}
