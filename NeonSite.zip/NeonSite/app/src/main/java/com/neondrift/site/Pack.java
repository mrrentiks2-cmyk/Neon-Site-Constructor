package com.neondrift.site;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Архивы: готовый сайт, проект для Claude и обратный импорт проекта. Без Android — проверяется на компьютере. */
final class Pack {
    private Pack() {}

    /** Картинки, на которые ссылается проект (img/…). */
    static TreeSet<String> images(Site s) {
        TreeSet<String> out = new TreeSet<>();
        Object o = Json.parse(s.toJson());
        collect(o, out);
        return out;
    }

    @SuppressWarnings("unchecked")
    private static void collect(Object o, TreeSet<String> out) {
        if (o instanceof String) {
            String v = (String) o;
            if (v.startsWith("img/") && v.length() < 200 && !v.contains("..")) out.add(v);
        } else if (o instanceof Map) {
            for (Object x : ((Map<String, Object>) o).values()) collect(x, out);
        } else if (o instanceof List) {
            for (Object x : (List<Object>) o) collect(x, out);
        }
    }

    /** Готовый сайт: страницы, стили, скрипт, картинки — в корне архива (или в папке prefix/). */
    static void site(Site s, File projDir, ZipOutputStream z, String prefix) throws IOException {
        site(s, projDir, z, prefix, true);
    }

    static void site(Site s, File projDir, ZipOutputStream z, String prefix, boolean withImages) throws IOException {
        for (Map.Entry<String, String> e : Gen.site(s).entrySet()) text(z, prefix + e.getKey(), e.getValue());
        if (!withImages) return;
        for (String img : images(s)) {
            File f = new File(projDir, img);
            if (f.isFile()) file(z, prefix + img, f);
        }
    }

    static void siteZip(Site s, File projDir, OutputStream out) throws IOException {
        ZipOutputStream z = new ZipOutputStream(out);
        site(s, projDir, z, "");
        z.finish();
        z.flush();
    }

    /** Проект для Claude: описание, картинки, черновик сайта и инструкция. */
    static void claudeZip(Site s, File projDir, OutputStream out, String appVersion) throws IOException {
        ZipOutputStream z = new ZipOutputStream(out);
        text(z, "ДЛЯ_CLAUDE.md", ClaudeDoc.make(s, appVersion));
        text(z, "project.json", s.toJson());
        for (String img : images(s)) {
            File f = new File(projDir, img);
            if (f.isFile()) file(z, img, f);
        }
        site(s, projDir, z, "site/", false); // картинки уже лежат в img/ — не удваиваем архив
        z.finish();
        z.flush();
    }

    private static void text(ZipOutputStream z, String name, String body) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(body.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    private static void file(ZipOutputStream z, String name, File f) throws IOException {
        ZipEntry e = new ZipEntry(name);
        e.setTime(f.lastModified());
        z.putNextEntry(e);
        try (InputStream in = new FileInputStream(f)) {
            copy(in, z);
        }
        z.closeEntry();
    }

    static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    // ================================================================== импорт

    /**
     * Открыть архив проекта (наш «Проект для Claude» или просто project.json в zip): достаёт project.json и картинки в dir.
     * Возвращает сайт с новым id (чтобы не перезаписать существующий).
     */
    static Site importZip(InputStream in, File dir) throws IOException {
        String json = null;
        String root = null;
        File img = new File(dir, "img");
        if (!img.isDirectory() && !img.mkdirs()) throw new IOException("не удалось создать папку");
        try (ZipInputStream z = new ZipInputStream(in)) {
            ZipEntry e;
            int count = 0;
            long total = 0;
            while ((e = z.getNextEntry()) != null) {
                if (++count > 5000) throw new IOException("слишком много файлов в архиве");
                if (e.isDirectory()) continue;
                String name = e.getName().replace('\\', '/');
                if (name.contains("../") || name.startsWith("/")) continue;
                if (name.endsWith("project.json") && !name.contains("site/")) {
                    String r = name.substring(0, name.length() - "project.json".length());
                    if (json == null || r.length() < root.length()) {
                        json = new String(read(z, 4 * 1024 * 1024), StandardCharsets.UTF_8);
                        root = r;
                    }
                    continue;
                }
                int k = name.indexOf("img/");
                if (k >= 0 && !name.contains("site/img/")) {
                    String fn = name.substring(k + 4);
                    if (fn.isEmpty() || fn.contains("/") || !fn.matches("[\\w.\\-]+")) continue;
                    File out = new File(img, fn);
                    try (OutputStream o = new FileOutputStream(out)) {
                        byte[] buf = new byte[64 * 1024];
                        int n;
                        long size = 0;
                        while ((n = z.read(buf)) > 0) {
                            size += n;
                            total += n;
                            if (size > 40L * 1024 * 1024 || total > 600L * 1024 * 1024) throw new IOException("слишком большие файлы в архиве");
                            o.write(buf, 0, n);
                        }
                    }
                }
            }
        }
        if (json == null) throw new IOException("в архиве нет project.json — это не проект Neon Site");
        Site s = Site.fromJson(json);
        s.id = Site.newId();
        return s;
    }

    static byte[] read(InputStream in, int max) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[16 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) {
            b.write(buf, 0, n);
            if (b.size() > max) throw new IOException("файл слишком большой");
        }
        return b.toByteArray();
    }
}
