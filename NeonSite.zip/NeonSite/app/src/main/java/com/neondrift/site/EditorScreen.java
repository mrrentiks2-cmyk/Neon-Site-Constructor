package com.neondrift.site;

import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayDeque;

/**
 * Редактор: живой предпросмотр страницы. Нажатие на блок — выбрать, ещё раз — изменить.
 * Снизу — действия с выбранным блоком и разделы: блоки, страницы, стиль, сайт, «Готово».
 */
final class EditorScreen extends Screen implements Web.Bridge {
    Site site;
    Site.Page page;
    String selected = "";
    private final WebView web;
    private final Web.Client client;
    private final LinearLayout selBar;
    private final ImageView selIcon, hideBtn, upBtn, downBtn, copyBtn, delBtn;
    private final TextView selName, selSub;
    private final ImageView undoBtn, redoBtn, deviceBtn;
    private final ArrayDeque<String> undo = new ArrayDeque<>(), redo = new ArrayDeque<>();
    private String committed;
    private boolean loaded;
    private String loadedKey = "";
    private int restoreY;
    private int device;
    private String scrollTo;

    EditorScreen(MainActivity a) {
        super(a);
        site = hub.site;
        page = site.home();
        String last = hub.prefs.str("page." + site.id, "");
        if (site.page(last) != null) page = site.page(last);
        committed = site.state();
        device = hub.prefs.device();

        LinearLayout h = header(site.name, "");
        View.OnClickListener pages = v -> pagesPanel();
        titleView.setOnClickListener(pages);
        subView.setOnClickListener(pages);
        ((View) titleView.getParent()).setOnClickListener(pages);
        undoBtn = ui.iconButton("undo", Theme.TEXT, 42, 11, v -> undo());
        redoBtn = ui.iconButton("redo", Theme.TEXT, 42, 11, v -> redo());
        deviceBtn = ui.iconButton(device == 1 ? "desktop" : "phone", Theme.TEXT, 42, 11, v -> toggleDevice());
        h.addView(undoBtn);
        h.addView(redoBtn);
        h.addView(deviceBtn);
        h.addView(ui.iconButton("eye", Theme.TEXT, 42, 11, v -> {
            commit();
            a.push(new PreviewScreen(a, page));
        }));

        FrameLayout box = new FrameLayout(a);
        web = Web.make(a, this);
        client = new Web.Client(a, false);
        client.onFinished = () -> {
            loaded = true;
            if (restoreY > 0) {
                int y = restoreY;
                restoreY = 0;
                web.postDelayed(() -> web.scrollTo(0, y), 60);
            }
            if (scrollTo != null) {
                web.evaluateJavascript("neonSelect(" + Web.js(scrollTo) + ",true)", null);
                scrollTo = null;
            }
        };
        web.setWebViewClient(client);
        box.addView(web, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        addView(box, Ui.lp(Ui.MATCH, 0, 1f));

        // панель выбранного блока
        selBar = ui.row();
        selBar.setPadding(ui.dp(10), ui.dp(6), ui.dp(4), ui.dp(6));
        selBar.setBackgroundColor(Theme.SURFACE);
        selIcon = new ImageView(a);
        selIcon.setPadding(ui.dp(8), ui.dp(8), ui.dp(8), ui.dp(8));
        selIcon.setBackground(Ui.oval(Theme.alpha(Theme.ACCENT, 45)));
        selBar.addView(selIcon, Ui.lp(ui.dp(38), ui.dp(38)));
        LinearLayout names = ui.col();
        selName = ui.oneLine("", 14.5f, Theme.TEXT, true);
        selSub = ui.oneLine("", 12, Theme.MUTED, false);
        names.addView(selName);
        names.addView(selSub, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(2), 0, 0));
        names.setPadding(ui.dp(10), 0, ui.dp(4), 0);
        names.setOnClickListener(v -> editSelected());
        selBar.addView(names, Ui.lp(0, Ui.WRAP, 1f));
        selBar.addView(small("edit", v -> editSelected(), Theme.ACCENT));
        upBtn = small("up", v -> move(-1), Theme.TEXT);
        downBtn = small("down", v -> move(1), Theme.TEXT);
        copyBtn = small("copy", v -> duplicate(), Theme.TEXT);
        hideBtn = small("eye", v -> toggleHidden(), Theme.TEXT);
        delBtn = small("trash", v -> delete(), 0xFFFF6B6B);
        selBar.addView(upBtn);
        selBar.addView(downBtn);
        selBar.addView(copyBtn);
        selBar.addView(hideBtn);
        selBar.addView(delBtn);
        selBar.setVisibility(GONE);
        addView(selBar, Ui.lp(Ui.MATCH, Ui.WRAP));

        // нижнее меню
        LinearLayout nav = ui.row();
        nav.setBackgroundColor(Theme.BG);
        nav.setPadding(ui.dp(4), ui.dp(4), ui.dp(4), ui.dp(6));
        nav.addView(navButton("plus", "Блок", Theme.ACCENT, v -> addBlock()), Ui.lp(0, Ui.WRAP, 1f));
        nav.addView(navButton("file", "Страницы", Theme.TEXT, v -> {
            commit();
            a.push(new PagesScreen(a, this));
        }), Ui.lp(0, Ui.WRAP, 1f));
        nav.addView(navButton("palette", "Стиль", Theme.TEXT, v -> {
            commit();
            a.push(new LookScreen(a, page));
        }), Ui.lp(0, Ui.WRAP, 1f));
        nav.addView(navButton("settings", "Сайт", Theme.TEXT, v -> {
            commit();
            a.push(new SiteScreen(a));
        }), Ui.lp(0, Ui.WRAP, 1f));
        nav.addView(navButton("send", "Готово", Theme.ACCENT2, v -> {
            commit();
            a.push(new ExportScreen(a, this));
        }), Ui.lp(0, Ui.WRAP, 1f));
        addView(nav, Ui.lp(Ui.MATCH, Ui.WRAP));

        if (!hub.prefs.tipsShown("editor")) {
            hub.prefs.tipShown("editor");
            postDelayed(() -> a.toast("Нажмите на блок, чтобы выбрать его. Нажмите ещё раз — откроется редактирование."), 900);
        }
    }

    private ImageView small(String icon, View.OnClickListener l, int color) {
        ImageView v = ui.iconButton(icon, color, 40, 10, l);
        return v;
    }

    private View navButton(String icon, String label, int color, View.OnClickListener l) {
        LinearLayout c = ui.col();
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(0, ui.dp(6), 0, ui.dp(4));
        c.setBackground(Ui.ripple(null, Ui.round(0xFFFFFFFF, ui.dp(14))));
        ImageView ic = new ImageView(a);
        ic.setImageDrawable(new Glyph(icon, color));
        c.addView(ic, Ui.lp(ui.dp(24), ui.dp(24)));
        TextView t = ui.oneLine(label, 11.5f, color == Theme.TEXT ? Theme.MUTED : color, true);
        t.setGravity(Gravity.CENTER);
        c.addView(t, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(4), 0, 0));
        c.setOnClickListener(l);
        return c;
    }

    // ================================================================== показ

    @Override
    void onShown() {
        // вернулись с другого экрана: сайт мог измениться (блок, страницы, стиль)
        site = hub.site;
        if (page == null || !site.pages.contains(page)) page = site.home();
        if (!selected.isEmpty() && site.block(selected) == null) selected = "";
        commit();
        updateHeader();
        updateSel();
        render();
    }

    void updateHeader() {
        titleView.setText(site.name);
        setSub((page == site.home() ? "🏠 " : page.post() ? "📝 " : "") + page.title + " ▾" + (site.pages.size() > 1 ? "   · страница " + (site.pages.indexOf(page) + 1) + " из " + site.pages.size() : ""));
        undoBtn.setAlpha(undo.isEmpty() ? 0.35f : 1f);
        redoBtn.setAlpha(redo.isEmpty() ? 0.35f : 1f);
        deviceBtn.setImageDrawable(new Glyph(device == 1 ? "desktop" : "phone", Theme.TEXT));
    }

    /** Перерисовать предпросмотр. Если открыта та же страница — без перезагрузки, на том же месте. */
    void render() {
        String key = page.id + "|" + device;
        String html = Gen.page(site, page, Gen.preview(selected, device == 1 ? 1280 : 0));
        if (loaded && key.equals(loadedKey)) {
            web.evaluateJavascript("neonSwap(" + Web.js(html) + ")", null);
            if (scrollTo != null) {
                web.evaluateJavascript("neonSelect(" + Web.js(scrollTo) + ",true)", null);
                scrollTo = null;
            }
        } else {
            restoreY = key.equals(loadedKey) ? web.getScrollY() : 0;
            loaded = false;
            loadedKey = key;
            web.loadDataWithBaseURL(Web.BASE + site.file(page), html, "text/html", "utf-8", null);
        }
    }

    /** Открыть страницу (из списка страниц или по ссылке). */
    void showPage(Site.Page p, String blockId) {
        if (p == null) return;
        page = p;
        selected = blockId == null ? "" : blockId;
        scrollTo = blockId;
        hub.prefs.put("page." + site.id, p.id);
        if (a.top() != this) return; // перерисуем, когда вернёмся
        updateHeader();
        updateSel();
        render();
    }

    private void toggleDevice() {
        device = 1 - device;
        hub.prefs.put("device", device);
        updateHeader();
        render();
        a.toast(device == 1 ? "Вид на компьютере" : "Вид на телефоне");
    }

    // ================================================================== выбор блока

    @Override
    public void select(String id) {
        if (id.equals(selected) && !id.isEmpty()) {
            editSelected();
            return;
        }
        selected = id;
        updateSel();
    }

    private void updateSel() {
        Site.Block b = selected.isEmpty() ? null : site.block(selected);
        if (b == null) {
            selBar.setVisibility(GONE);
            return;
        }
        boolean global = b == site.header || b == site.footer;
        Blocks.Type t = Blocks.type(b.type);
        selIcon.setImageDrawable(new Glyph(t.icon, Theme.ACCENT));
        selName.setText(t.name + (b.hidden ? " · скрыт" : ""));
        String title = b.s("title").replace("*", "");
        selSub.setText(global ? "на всех страницах" : t.variantName(b.variant) + (title.isEmpty() ? "" : " · " + title));
        int idx = page.blocks.indexOf(b);
        upBtn.setVisibility(global ? GONE : VISIBLE);
        downBtn.setVisibility(global ? GONE : VISIBLE);
        copyBtn.setVisibility(global ? GONE : VISIBLE);
        delBtn.setVisibility(global ? GONE : VISIBLE);
        upBtn.setAlpha(idx > 0 ? 1f : 0.3f);
        downBtn.setAlpha(idx >= 0 && idx < page.blocks.size() - 1 ? 1f : 0.3f);
        hideBtn.setImageDrawable(new Glyph(b.hidden ? "eye" : "eye", b.hidden ? Theme.ACCENT : Theme.TEXT));
        hideBtn.setAlpha(b.hidden ? 1f : 0.85f);
        selBar.setVisibility(VISIBLE);
    }

    private void editSelected() {
        Site.Block b = site.block(selected);
        if (b == null) return;
        commit();
        a.push(new BlockScreen(a, b, b == site.header || b == site.footer ? null : page));
    }

    private void move(int d) {
        Site.Block b = site.block(selected);
        int i = page.blocks.indexOf(b), j = i + d;
        if (i < 0 || j < 0 || j >= page.blocks.size()) return;
        page.blocks.remove(i);
        page.blocks.add(j, b);
        changed(b.id);
    }

    private void duplicate() {
        Site.Block b = site.block(selected);
        int i = page.blocks.indexOf(b);
        if (i < 0) return;
        Site.Block c = b.copy();
        if (!c.anchor.isEmpty()) c.anchor = "";
        page.blocks.add(i + 1, c);
        selected = c.id;
        changed(c.id);
        a.toast("Блок скопирован");
    }

    private void toggleHidden() {
        Site.Block b = site.block(selected);
        if (b == null) return;
        b.hidden = !b.hidden;
        changed(null);
        a.toast(b.hidden ? "Блок скрыт: на сайт он не попадёт, но останется здесь" : "Блок снова виден");
    }

    private void delete() {
        Site.Block b = site.block(selected);
        int i = page.blocks.indexOf(b);
        if (i < 0) return;
        page.blocks.remove(i);
        selected = "";
        changed(null);
        a.toast("Блок удалён. Вернуть — кнопкой «Отменить» вверху");
    }

    /** Что-то поменяли прямо в редакторе: запомнить для «Отменить», сохранить, перерисовать. */
    private void changed(String scroll) {
        commit();
        updateSel();
        updateHeader();
        scrollTo = scroll;
        render();
    }

    // ================================================================== добавление

    private void addBlock() {
        commit();
        a.push(new CatalogScreen(a, (type, variant) -> {
            Site.Block nb = Blocks.make(type, variant);
            Site.Block cur = site.block(selected);
            int at = page.blocks.size();
            if (cur == site.header) at = 0;
            else if (cur != null && page.blocks.contains(cur)) at = page.blocks.indexOf(cur) + 1;
            // якорь для блоков, на которые обычно ссылаются
            if (!nb.anchor.isEmpty()) nb.anchor = freeAnchor(nb.anchor);
            page.blocks.add(at, nb);
            selected = nb.id;
            scrollTo = nb.id;
            a.toast("Добавлено: " + Blocks.type(type).name + ". Нажмите на него ещё раз, чтобы изменить");
        }));
    }

    String freeAnchor(String want) {
        String a0 = Slug.of(want);
        if (a0.isEmpty()) a0 = "block";
        String x = a0;
        int k = 2;
        while (anchorUsed(x)) x = a0 + "-" + (k++);
        return x;
    }

    private boolean anchorUsed(String x) {
        for (Site.Page p : site.pages) for (Site.Block b : p.blocks) if (x.equals(b.anchor)) return true;
        return false;
    }

    @Override
    public void add(String type, String variant) {
    }

    @Override
    public void template(String id) {
    }

    // ================================================================== отмена

    /** Зафиксировать состояние для «Отменить» (если что-то поменялось) и сохранить. */
    void commit() {
        String j = site.state();
        if (j.equals(committed)) return;
        undo.push(committed);
        while (undo.size() > 60) undo.removeLast();
        redo.clear();
        committed = j;
        hub.saveSoon();
        if (undoBtn != null) updateHeader();
    }

    private void undo() {
        commit();
        if (undo.isEmpty()) {
            a.toast("Отменять нечего");
            return;
        }
        redo.push(committed);
        restore(undo.pop());
        a.toast("Отменено");
    }

    private void redo() {
        commit();
        if (redo.isEmpty()) return;
        undo.push(committed);
        restore(redo.pop());
        a.toast("Возвращено");
    }

    private void restore(String json) {
        Site s = Site.fromJson(json);
        s.id = site.id;
        s.updated = System.currentTimeMillis();
        hub.site = s;
        site = s;
        committed = s.state();
        Site.Page p = page == null ? null : s.page(page.id);
        page = p != null ? p : s.home();
        if (s.block(selected) == null) selected = "";
        hub.saveSoon();
        updateHeader();
        updateSel();
        render();
    }

    // ================================================================== страницы

    private void pagesPanel() {
        commit();
        LinearLayout p = a.panel.open("Страницы");
        for (Site.Page q : site.pages) {
            String sub = site.file(q) + (q.post() ? " · запись" : "") + (!q.menu && !q.post() ? " · не в меню" : "") + " · " + q.blocks.size() + " "
                    + HomeScreen.plural(q.blocks.size(), "блок", "блока", "блоков");
            a.panel.option(p, (q == site.home() ? "🏠 " : q.post() ? "📝 " : "") + q.title, sub, q == page, () -> {
                a.panel.close();
                showPage(q, null);
            });
        }
        LinearLayout row = ui.row();
        row.addView(ui.button("+ Страница", false, v -> {
            a.panel.close();
            PagesScreen.addPage(a, this);
        }), Ui.lp(0, Ui.WRAP, 1f));
        LinearLayout.LayoutParams lp = Ui.lp(0, Ui.WRAP, 1f);
        lp.leftMargin = ui.dp(10);
        row.addView(ui.button("Управлять", false, v -> {
            a.panel.close();
            a.push(new PagesScreen(a, this));
        }), lp);
        p.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(14), 0, 0));
    }

    @Override
    boolean back() {
        commit();
        hub.saveSync();
        return false;
    }

    @Override
    void onRemoved() {
        hub.saveSync();
        hub.io.execute(() -> hub.main.post(() -> {
            Screen t = a.top();
            if (t instanceof HomeScreen) t.refresh();
        }));
        web.destroy();
    }

    @SuppressWarnings("unused")
    private static Typeface bold() {
        return Typeface.DEFAULT_BOLD;
    }
}
