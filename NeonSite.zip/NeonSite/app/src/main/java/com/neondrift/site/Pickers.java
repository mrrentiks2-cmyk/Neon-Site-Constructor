package com.neondrift.site;

import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;
import java.util.function.Consumer;

/** Выбор ссылки и цвета в выезжающей панели. */
final class Pickers {
    private Pickers() {}

    // ================================================================== ссылка

    /** Понятное описание ссылки: «Страница „Контакты“», «Блок „Цены“ на этой странице», «Телефон +7…». */
    static String describe(Site s, String link) {
        String l = link == null ? "" : link.trim();
        if (l.isEmpty()) return "Нет ссылки";
        if (l.startsWith("page:")) {
            String id = l.substring(5), a = "";
            int h = id.indexOf('#');
            if (h >= 0) {
                a = id.substring(h + 1);
                id = id.substring(0, h);
            }
            Site.Page p = s.page(id);
            if (p == null) return "⚠️ Страница удалена";
            if (a.isEmpty()) return "Страница «" + p.title + "»";
            Site.Block b = byAnchor(s, a);
            return "Страница «" + p.title + "» → " + (b == null ? "#" + a : blockName(b));
        }
        if (l.startsWith("#")) {
            Site.Block b = byAnchor(s, l.substring(1));
            return b == null ? "⚠️ Блок «" + l + "» не найден" : "Прокрутка к блоку: " + blockName(b);
        }
        if (l.startsWith("tel:")) return "Позвонить: " + l.substring(4);
        if (l.startsWith("mailto:")) return "Написать на почту: " + l.substring(7);
        if (l.contains("t.me/")) return "Telegram: @" + l.substring(l.indexOf("t.me/") + 5);
        if (l.contains("wa.me/")) return "WhatsApp: " + l.substring(l.indexOf("wa.me/") + 6);
        return l;
    }

    static String blockName(Site.Block b) {
        String t = b.s("title").replace("*", "");
        Blocks.Type ty = Blocks.type(b.type);
        return t.isEmpty() ? "«" + ty.name + "»" : "«" + t + "»";
    }

    /** «Цены „Сколько стоит“» или просто «Цифры», если заголовка нет. */
    static String blockLabel(Site.Block b) {
        String t = b.s("title").replace("*", "");
        Blocks.Type ty = Blocks.type(b.type);
        return t.isEmpty() || t.equals(ty.name) ? ty.name : ty.name + " «" + t + "»";
    }

    static Site.Block byAnchor(Site s, String a) {
        for (Site.Page p : s.pages) for (Site.Block b : p.blocks) if (a.equals(b.anchor)) return b;
        return null;
    }

    static void link(MainActivity a, Site s, Site.Page cur, String value, Consumer<String> set) {
        SidePanel panel = a.panel;
        LinearLayout p = panel.open("Куда ведёт ссылка");
        String v = value == null ? "" : value.trim();
        panel.section(p, "СТРАНИЦА САЙТА");
        for (Site.Page q : s.pages) {
            String l = "page:" + q.id;
            panel.option(p, (q == s.home() ? "🏠 " : q.post() ? "📝 " : "") + q.title, s.file(q), v.equals(l), () -> {
                panel.close();
                set.accept(l);
            });
        }
        panel.section(p, "БЛОК — ПРОКРУТИТЬ К НЕМУ");
        boolean anyBlock = false;
        for (Site.Page q : s.pages) {
            for (Site.Block b : q.blocks) {
                if (b.type.equals("divider")) continue;
                anyBlock = true;
                boolean here = q == cur;
                String target = b.anchor.isEmpty() ? null : here ? "#" + b.anchor : "page:" + q.id + "#" + b.anchor;
                boolean on = target != null && v.equals(target);
                String sub = (here ? "на этой странице" : "страница «" + q.title + "»") + (b.anchor.isEmpty() ? "" : " · #" + b.anchor);
                panel.option(p, blockLabel(b), sub, on, () -> {
                    panel.close();
                    if (b.anchor.isEmpty()) b.anchor = freeAnchor(s, b.type);
                    set.accept(here ? "#" + b.anchor : "page:" + q.id + "#" + b.anchor);
                });
            }
        }
        if (!anyBlock) panel.note(p, "На сайте пока нет блоков.");
        panel.section(p, "ДРУГОЕ");
        panel.option(p, "Адрес в интернете", "https://…", v.startsWith("http") && !v.contains("t.me/") && !v.contains("wa.me/"),
                () -> a.ask("Адрес в интернете", "https://example.com", v.startsWith("http") ? v : "https://", "Готово", x -> set.accept(x.contains("://") || x.startsWith("/") ? x : "https://" + x)));
        panel.option(p, "Позвонить", "Телефон: откроется набор номера", v.startsWith("tel:"),
                () -> a.ask("Номер телефона", "+7 900 123-45-67", v.startsWith("tel:") ? v.substring(4) : "+7", "Готово", x -> set.accept("tel:" + x.replaceAll("[^+\\d]", ""))));
        panel.option(p, "Написать на почту", "Откроется почтовое приложение", v.startsWith("mailto:"),
                () -> a.ask("Почта", "name@mail.ru", v.startsWith("mailto:") ? v.substring(7) : "", "Готово", x -> set.accept("mailto:" + x.trim())));
        panel.option(p, "Telegram", "Чат или канал", v.contains("t.me/"),
                () -> a.ask("Telegram", "@имя или ссылка t.me/…", v.contains("t.me/") ? "@" + v.substring(v.indexOf("t.me/") + 5) : "@", "Готово",
                        x -> set.accept("https://t.me/" + x.trim().replaceFirst("^https?://", "").replaceFirst("^t\\.me/", "").replaceFirst("^@", ""))));
        panel.option(p, "WhatsApp", "Чат по номеру телефона", v.contains("wa.me/"),
                () -> a.ask("WhatsApp", "Номер: +7 900 123-45-67", v.contains("wa.me/") ? "+" + v.substring(v.indexOf("wa.me/") + 6) : "+7", "Готово",
                        x -> set.accept("https://wa.me/" + x.replaceAll("\\D", ""))));
        panel.option(p, "Без ссылки", "Кнопка никуда не ведёт", v.isEmpty(), () -> {
            panel.close();
            set.accept("");
        });
    }

    /** Свободный якорь по типу блока: contacts, contacts-2… */
    static String freeAnchor(Site s, String type) {
        String base;
        switch (type) {
            case "pricing": base = "prices"; break;
            case "features": base = "services"; break;
            case "imagetext":
            case "text": base = "about"; break;
            case "gallery": base = "gallery"; break;
            case "reviews": base = "reviews"; break;
            default: base = type;
        }
        String x = base;
        int k = 2;
        while (byAnchor(s, x) != null) x = base + "-" + (k++);
        return x;
    }

    // ================================================================== цвет

    private static final String[] PRESETS = {
            "#FFFFFF", "#F7F7F5", "#F4F5F8", "#ECECE8", "#D9D9D3", "#9A9A94", "#5E6472", "#2B2B2B", "#14161C", "#0B0A12",
            "#FF2D95", "#E5484D", "#FF5A36", "#FF7A1A", "#FFB703", "#E2B23C", "#8CFF5A", "#3DDC97", "#2F7D4F", "#0E8AA8",
            "#00E5FF", "#4F8CFF", "#2B59FF", "#6C4CF5", "#9D6BFF", "#FF6FB5", "#8B4A2B", "#C9A45C", "#FBF7F2", "#FFF6F1"};

    static void color(MainActivity a, Site s, String value, Consumer<String> set) {
        SidePanel panel = a.panel;
        Ui ui = a.ui;
        LinearLayout p = panel.open("Цвет");
        int[] c = {Form.parse(value)};
        View big = new View(a);
        EditText hex = a.field(value, "#RRGGBB", false);
        hex.setAllCaps(true);
        LinearLayout top = ui.row();
        top.addView(big, Ui.lp(ui.dp(56), ui.dp(56)));
        LinearLayout.LayoutParams hl = Ui.lp(0, Ui.WRAP, 1f);
        hl.leftMargin = ui.dp(12);
        top.addView(hex, hl);
        p.addView(top, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(4), 0, ui.dp(4)));
        SeekBar[] sl = new SeekBar[3];
        boolean[] lock = {false};
        Runnable paint = () -> big.setBackground(Ui.stroke(c[0], 0x55FFFFFF, ui.dp(1), ui.dp(14)));
        Consumer<Integer> apply = col -> {
            c[0] = col | 0xFF000000;
            paint.run();
            String h = String.format(Locale.ROOT, "#%06X", c[0] & 0xFFFFFF);
            lock[0] = true;
            if (!hex.getText().toString().equalsIgnoreCase(h)) hex.setText(h);
            float[] hsv = new float[3];
            Color.colorToHSV(c[0], hsv);
            if (sl[0] != null) {
                sl[0].setProgress(Math.round(hsv[0]));
                sl[1].setProgress(Math.round(hsv[1] * 100));
                sl[2].setProgress(Math.round(hsv[2] * 100));
            }
            lock[0] = false;
        };
        paint.run();
        hex.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence x, int st, int n, int af) {
            }

            @Override
            public void onTextChanged(CharSequence x, int st, int b, int n) {
            }

            @Override
            public void afterTextChanged(Editable e) {
                if (lock[0]) return;
                String t = e.toString().trim();
                if (!t.startsWith("#")) t = "#" + t;
                if (t.matches("#[0-9a-fA-F]{6}")) {
                    c[0] = Form.parse(t);
                    paint.run();
                }
            }
        });
        panel.section(p, "ЦВЕТА САЙТА");
        Site.Look l = s.look;
        swatches(a, p, new String[]{l.bg, l.surface, l.text, l.muted, l.primary, l.accent, l.border}, apply);
        panel.section(p, "ГОТОВЫЕ");
        swatches(a, p, PRESETS, apply);
        panel.section(p, "ТОЧНЕЕ: ТОН, НАСЫЩЕННОСТЬ, ЯРКОСТЬ");
        float[] hsv = new float[3];
        Color.colorToHSV(c[0], hsv);
        int[] max = {360, 100, 100};
        int[] now = {Math.round(hsv[0]), Math.round(hsv[1] * 100), Math.round(hsv[2] * 100)};
        for (int i = 0; i < 3; i++) {
            sl[i] = panel.slider(p, max[i], now[i], Theme.ACCENT);
            sl[i].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar sb, int v, boolean user) {
                    if (!user || lock[0]) return;
                    int col = Color.HSVToColor(new float[]{sl[0].getProgress(), sl[1].getProgress() / 100f, sl[2].getProgress() / 100f});
                    c[0] = col;
                    paint.run();
                    lock[0] = true;
                    hex.setText(String.format(Locale.ROOT, "#%06X", col & 0xFFFFFF));
                    lock[0] = false;
                }

                @Override
                public void onStartTrackingTouch(SeekBar sb) {
                }

                @Override
                public void onStopTrackingTouch(SeekBar sb) {
                }
            });
        }
        TextView ok = ui.button("Готово", true, v -> {
            a.hideKeyboard();
            panel.close();
            set.accept(String.format(Locale.ROOT, "#%06X", c[0] & 0xFFFFFF));
        });
        p.addView(ok, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(16), 0, 0));
    }

    private static void swatches(MainActivity a, LinearLayout p, String[] colors, Consumer<Integer> pick) {
        Ui ui = a.ui;
        LinearLayout row = null;
        int per = 10;
        for (int i = 0; i < colors.length; i++) {
            if (i % per == 0) {
                row = ui.row();
                p.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(6)));
            }
            int col = Form.parse(colors[i]);
            View v = new View(a);
            v.setBackground(Ui.stroke(col, 0x44FFFFFF, ui.dp(1), ui.dp(8)));
            v.setOnClickListener(x -> pick.accept(col));
            LinearLayout.LayoutParams lp = Ui.lp(0, ui.dp(30), 1f);
            lp.rightMargin = ui.dp(5);
            row.addView(v, lp);
        }
        if (row != null) for (int k = colors.length % per; k > 0 && k < per; k++) row.addView(new View(a), Ui.lp(0, ui.dp(30), 1f));
    }
}
