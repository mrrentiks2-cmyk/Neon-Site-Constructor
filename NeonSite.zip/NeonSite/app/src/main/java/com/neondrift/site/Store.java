package com.neondrift.site;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Проекты на телефоне: files/projects/&lt;id&gt;/project.json и папка img/ с картинками. */
final class Store {
    /** Краткие сведения для списка проектов. */
    static final class Meta {
        String id, name, template;
        long updated;
        int pages, blocks;
        String bg, primary, accent, text;
        boolean dark;
    }

    private final File root;

    Store(Context c) {
        root = new File(c.getFilesDir(), "projects");
        if (!root.isDirectory()) root.mkdirs();
    }

    File dir(String id) {
        return new File(root, id);
    }

    File img(String id) {
        File f = new File(dir(id), "img");
        if (!f.isDirectory()) f.mkdirs();
        return f;
    }

    List<Meta> list() {
        List<Meta> out = new ArrayList<>();
        File[] ds = root.listFiles();
        if (ds == null) return out;
        for (File d : ds) {
            File f = new File(d, "project.json");
            if (!f.isFile()) continue;
            try {
                Site s = Site.fromJson(read(f));
                Meta m = new Meta();
                m.id = d.getName();
                m.name = s.name;
                m.template = s.template;
                m.updated = s.updated > 0 ? s.updated : f.lastModified();
                m.pages = s.pages.size();
                for (Site.Page p : s.pages) m.blocks += p.blocks.size();
                m.bg = s.look.bg;
                m.primary = s.look.primary;
                m.accent = s.look.accent;
                m.text = s.look.text;
                m.dark = s.look.dark;
                out.add(m);
            } catch (Exception e) {
                // повреждённый проект не прячем молча — показываем с пометкой
                Meta m = new Meta();
                m.id = d.getName();
                m.name = "Проект не читается (" + d.getName() + ")";
                m.updated = f.lastModified();
                m.bg = "#222222";
                m.primary = "#FF2D95";
                m.accent = "#00E5FF";
                m.text = "#FFFFFF";
                out.add(m);
            }
        }
        out.sort((a, b) -> Long.compare(b.updated, a.updated));
        return out;
    }

    Site load(String id) throws IOException {
        Site s = Site.fromJson(read(new File(dir(id), "project.json")));
        s.id = id; // папка — главный признак проекта
        return s;
    }

    /** Записать проект целиком: сначала во временный файл, потом подменить — так файл не бьётся при сбое. */
    void save(Site s) throws IOException {
        write(s.id, s.toJson());
    }

    synchronized void write(String id, String json) throws IOException {
        File d = dir(id);
        if (!d.isDirectory() && !d.mkdirs()) throw new IOException("не удалось создать папку проекта");
        File tmp = new File(d, "project.json.tmp"), f = new File(d, "project.json");
        try (OutputStream o = new FileOutputStream(tmp)) {
            o.write(json.getBytes(StandardCharsets.UTF_8));
            o.flush();
            ((FileOutputStream) o).getFD().sync();
        }
        if (!tmp.renameTo(f)) {
            f.delete();
            if (!tmp.renameTo(f)) throw new IOException("не удалось сохранить проект");
        }
    }

    void delete(String id) {
        rm(dir(id));
    }

    /** Копия проекта с картинками. */
    Site duplicate(String id) throws IOException {
        Site s = load(id);
        String nid = Site.newId();
        File from = img(id), to = img(nid);
        File[] fs = from.listFiles();
        if (fs != null) for (File f : fs) copy(f, new File(to, f.getName()));
        s.id = nid;
        s.name = s.name + " (копия)";
        s.created = System.currentTimeMillis();
        s.updated = s.created;
        save(s);
        return s;
    }

    /** Удалить картинки, на которые проект больше не ссылается (после замены фото). */
    int cleanImages(Site s) {
        java.util.Set<String> used = Pack.images(s);
        File[] fs = img(s.id).listFiles();
        int n = 0;
        if (fs == null) return 0;
        for (File f : fs) {
            if (!used.contains("img/" + f.getName()) && System.currentTimeMillis() - f.lastModified() > 60_000 && f.delete()) n++;
        }
        return n;
    }

    static String read(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) {
            return new String(Pack.read(in, 16 * 1024 * 1024), StandardCharsets.UTF_8);
        }
    }

    static void copy(File a, File b) throws IOException {
        try (InputStream in = new FileInputStream(a); OutputStream out = new FileOutputStream(b)) {
            Pack.copy(in, out);
        }
    }

    static void rm(File f) {
        File[] fs = f.listFiles();
        if (fs != null) for (File x : fs) rm(x);
        f.delete();
    }
}
