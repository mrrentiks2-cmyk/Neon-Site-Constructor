package com.neondrift.site;

import java.util.List;
import java.util.Map;

/** Файл «ДЛЯ_CLAUDE.md» в архиве проекта: что это за сайт, из чего он собран и что с ним сделать. */
final class ClaudeDoc {
    private ClaudeDoc() {}

    static String make(Site s, String appVersion) {
        StringBuilder sb = new StringBuilder(8 * 1024);
        sb.append("# Сайт «").append(s.name).append("» — проект из Neon Site\n\n");
        sb.append("Привет, Claude! Я собрал этот сайт в конструкторе Neon Site на телефоне. ")
                .append("Сделай из него готовый сайт: аккуратный, быстрый, адаптивный, который можно сразу выложить на хостинг.\n\n");

        sb.append("## Мои пожелания\n\n");
        boolean any = !s.notes.trim().isEmpty();
        if (any) sb.append(quote(s.notes.trim())).append("\n\n");
        int blockNotes = 0;
        for (Site.Page p : s.pages) for (Site.Block b : p.blocks) if (!b.notes.trim().isEmpty()) blockNotes++;
        if (s.header != null && !s.header.notes.trim().isEmpty()) blockNotes++;
        if (s.footer != null && !s.footer.notes.trim().isEmpty()) blockNotes++;
        if (blockNotes > 0) sb.append("Пожелания к отдельным блокам (").append(blockNotes).append(") — ниже, в списке страниц, с пометкой ✍️.\n\n");
        else if (!any) sb.append("Отдельных пожеланий нет — сделай хорошо по своему вкусу, сохранив структуру и тексты.\n\n");

        sb.append("## Что в архиве\n\n");
        sb.append("- `project.json` — полное описание сайта: страницы, блоки, все тексты, цвета, шрифты. Это главный источник правды.\n");
        sb.append("- `img/` — мои картинки (уже уменьшены для сайта).\n");
        sb.append("- `site/` — как сайт собрал сам конструктор: статические HTML + `assets/site.css` + `assets/site.js`. ")
                .append("Это рабочий черновик — можно взять за основу и улучшить или сверстать заново лучше. Картинки для него — в `img/` в корне архива (скопируй их в `site/img/`).\n");
        sb.append("- `ДЛЯ_CLAUDE.md` — этот файл.\n\n");

        sb.append("## О сайте\n\n");
        row(sb, "Название", s.name);
        row(sb, "Домен", s.domain.isEmpty() ? "пока нет" : s.domain);
        row(sb, "Язык", s.lang);
        row(sb, "Описание (для поисковиков)", s.description.isEmpty() ? "нет" : s.description);
        if (!s.headCode.trim().isEmpty()) row(sb, "Код в <head>", "есть (счётчики/проверки) — сохрани его");
        if (!s.css.trim().isEmpty()) row(sb, "Свой CSS", "есть — учти его");
        sb.append('\n');

        Site.Look l = s.look;
        Themes.Fonts f = Themes.fonts(l.fonts);
        sb.append("## Оформление\n\n");
        row(sb, "Тема", (l.dark ? "тёмная" : "светлая") + ", палитра «" + Themes.palette(l.palette).name + "»" + (paletteChanged(l) ? " (цвета изменены вручную)" : ""));
        row(sb, "Цвета", "фон " + l.bg + ", второй фон " + l.surface + ", текст " + l.text + ", приглушённый " + l.muted + ", основной " + l.primary
                + " (текст на нём " + l.onPrimary + "), акцент " + l.accent + ", линии " + l.border);
        row(sb, "Шрифты", f.head.isEmpty() ? "системные" : "заголовки — " + f.head + ", текст — " + f.body + " (Google Fonts)");
        row(sb, "Скругления", Themes.radiusPx(l.radius) + " px");
        row(sb, "Кнопки", name(Themes.BUTTONS, Themes.BUTTON_NAMES, l.buttons));
        row(sb, "Ширина содержимого", Themes.widthPx(l.width) + " px");
        row(sb, "Тени", l.shadows ? "да" : "нет");
        row(sb, "Появление блоков при прокрутке", l.animate ? "да" : "нет");
        sb.append('\n');

        sb.append("## Страницы и блоки\n\n");
        if (s.header != null) {
            sb.append("**Шапка (на всех страницах)** — ").append(Blocks.type("header").variantName(s.header.variant));
            if (s.header.hidden) sb.append(", скрыта");
            sb.append('\n');
            notes(sb, s.header, "");
            sb.append('\n');
        }
        int n = 0;
        for (Site.Page p : s.pages) {
            n++;
            sb.append("### ").append(n).append(". ").append(p.title).append(" — `").append(s.file(p)).append("`");
            if (p.post()) sb.append(" (запись блога").append(p.date.isEmpty() ? "" : ", " + p.date).append(")");
            if (!p.menu && !p.post()) sb.append(" (не в меню)");
            sb.append("\n\n");
            if (!p.seoTitle.isEmpty() || !p.seoDescription.isEmpty())
                sb.append("SEO: ").append(p.seoTitle.isEmpty() ? "" : "заголовок «" + p.seoTitle + "»").append(p.seoDescription.isEmpty() ? "" : " описание «" + p.seoDescription + "»").append("\n\n");
            int k = 0;
            for (Site.Block b : p.blocks) {
                k++;
                Blocks.Type t = Blocks.type(b.type);
                sb.append(k).append(". **").append(t.name).append("** — ").append(t.variantName(b.variant));
                String title = b.s("title");
                if (!title.isEmpty()) sb.append(": «").append(title.replace("*", "")).append("»");
                if (!b.anchor.isEmpty()) sb.append(" `#").append(b.anchor).append('`');
                if (b.hidden) sb.append(" _(скрыт — на сайт не попадает)_");
                if (!b.show.equals("all")) sb.append(b.show.equals("mobile") ? " _(только на телефонах)_" : " _(только на компьютерах)_");
                int items = b.v.get("items") instanceof List ? ((List<?>) b.v.get("items")).size() : 0;
                if (items > 0) sb.append(" — ").append(items).append(" шт.");
                sb.append('\n');
                notes(sb, b, "   ");
            }
            if (p.blocks.isEmpty()) sb.append("_пустая страница_\n");
            sb.append('\n');
        }
        if (s.footer != null) {
            sb.append("**Подвал (на всех страницах)** — ").append(Blocks.type("footer").variantName(s.footer.variant)).append('\n');
            notes(sb, s.footer, "");
            sb.append('\n');
        }

        List<Check.Issue> issues = Check.run(s);
        boolean head = false;
        for (Check.Issue i : issues) {
            if (i.level == Check.INFO && i.text.contains("есть пожелание")) continue;
            if (!head) {
                sb.append("## Что заметил конструктор\n\n");
                head = true;
            }
            sb.append("- ").append(i.level == Check.ERROR ? "❗ " : i.level == Check.WARN ? "⚠️ " : "").append(i.text).append('\n');
        }
        if (head) sb.append("\nЕсли где-то остался текст-образец или нет фото — оставь аккуратную заглушку и перечисли в ответе, что мне нужно заменить.\n\n");

        sb.append("## Что сделать\n\n");
        sb.append("1. Сохрани структуру страниц, порядок блоков и мои тексты (исправь только явные опечатки).\n");
        sb.append("2. Выполни пожелания выше — они важнее, чем то, как сейчас выглядит `site/`.\n");
        sb.append("3. Вёрстка — чистый HTML/CSS/JS без тяжёлых фреймворков; сайт должен открываться как статический (GitHub Pages, Netlify, обычный хостинг).\n");
        sb.append("4. Хорошо на телефоне (от 360 px) и на компьютере; доступность: alt у картинок, контраст, фокус у кнопок.\n");
        sb.append("5. SEO: title и description для каждой страницы, Open Graph, sitemap.xml и robots.txt (если указан домен).\n");
        sb.append("6. Формы: если указан обработчик — отправка через fetch; если почта — mailto, как сейчас.\n");
        sb.append("7. Отдай результат архивом или файлами с понятной структурой и коротко напиши, как выложить сайт.\n\n");

        sb.append("## Формат project.json (кратко)\n\n");
        sb.append("```\n{ format: \"neon-site\", version: 1, name, domain, lang, description, notes,\n");
        sb.append("  look: { palette, dark, bg, surface, text, muted, primary, onPrimary, accent, border, fonts, radius, buttons, shadows, width, animate },\n");
        sb.append("  header: Блок, footer: Блок,\n");
        sb.append("  pages: [ { id, title, slug, kind: page|post, date, cover, excerpt, menu, seoTitle, seoDescription, blocks: [Блок] } ] }\n");
        sb.append("Блок: { id, type, variant, v: { поля блока; списки — в v.items }, bg, bgColor, bgImage, pad: none|s|m|l, anchor, show, hidden, notes }\n");
        sb.append("```\n\n");
        sb.append("Ссылки внутри проекта: `page:<id>` — страница сайта, `page:<id>#якорь`, `#якорь` — блок на странице, а также обычные адреса, `tel:` и `mailto:`. ");
        sb.append("Картинки — пути вида `img/имя.jpg` относительно корня сайта. ");
        sb.append("В текстах простая разметка: `**жирный**`, `*курсив*`, `[ссылка](адрес)`, строки с «- » — список, «## » — подзаголовок.\n\n");
        sb.append("---\nСобрано в Neon Site ").append(appVersion).append(".\n");
        return sb.toString();
    }

    private static boolean paletteChanged(Site.Look l) {
        Themes.Palette p = Themes.palette(l.palette);
        return !(p.bg.equalsIgnoreCase(l.bg) && p.primary.equalsIgnoreCase(l.primary) && p.text.equalsIgnoreCase(l.text) && p.accent.equalsIgnoreCase(l.accent)
                && p.surface.equalsIgnoreCase(l.surface));
    }

    private static void notes(StringBuilder sb, Site.Block b, String indent) {
        if (b.notes.trim().isEmpty()) return;
        String[] lines = b.notes.trim().split("\n");
        sb.append(indent).append("- ✍️ ").append(lines[0]).append('\n');
        for (int i = 1; i < lines.length; i++) sb.append(indent).append("  ").append(lines[i]).append('\n');
    }

    private static void row(StringBuilder sb, String k, String v) {
        sb.append("- **").append(k).append(":** ").append(v).append('\n');
    }

    private static String quote(String t) {
        StringBuilder sb = new StringBuilder();
        for (String l : t.split("\n")) sb.append("> ").append(l).append('\n');
        return sb.toString().trim();
    }

    private static String name(String[] ids, String[] names, String id) {
        for (int i = 0; i < ids.length; i++) if (ids[i].equals(id)) return names[i];
        return id;
    }

    @SuppressWarnings("unused")
    private static String str(Map<String, Object> m, String k) {
        Object o = m.get(k);
        return o == null ? "" : String.valueOf(o);
    }
}
