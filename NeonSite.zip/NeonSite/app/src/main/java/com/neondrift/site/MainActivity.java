package com.neondrift.site;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/** Единственное окно: стопка экранов, выезжающая панель, всплывающие сообщения, выбор файлов. */
public class MainActivity extends Activity {
    Hub hub;
    Ui ui;
    SidePanel panel;
    private FrameLayout host;
    private TextView toastView;
    private final ArrayList<Screen> stack = new ArrayList<>();
    private final SparseArray<Runnable[]> perms = new SparseArray<>();
    private final SparseArray<Result> results = new SparseArray<>();
    private int nextReq = 100;

    interface Result {
        void done(List<Uri> uris);
    }

    interface Text {
        void done(String s);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        hub = Hub.get(this);
        Theme.load(this);
        ui = new Ui(this);
        hub.toaster = this::toast;
        getWindow().setStatusBarColor(Theme.BG);
        getWindow().setNavigationBarColor(Theme.BG);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Theme.BG);
        host = new FrameLayout(this);
        root.addView(host, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        panel = new SidePanel(this, ui);
        root.addView(panel, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        toastView = ui.text("", 14, Theme.TEXT, false);
        toastView.setBackground(Ui.round(0xF0221B35, ui.dp(14)));
        toastView.setPadding(ui.dp(16), ui.dp(12), ui.dp(16), ui.dp(12));
        toastView.setVisibility(View.GONE);
        toastView.setMaxLines(5);
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        tl.bottomMargin = ui.dp(96);
        tl.leftMargin = tl.rightMargin = ui.dp(16);
        root.addView(toastView, tl);
        setContentView(root);
        push(new HomeScreen(this));
        handle(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handle(i);
    }

    /** Архив проекта, открытый из файлов или присланный через «Поделиться». */
    private void handle(Intent i) {
        if (i == null) return;
        Uri u = null;
        if (Intent.ACTION_VIEW.equals(i.getAction())) u = i.getData();
        else if (Intent.ACTION_SEND.equals(i.getAction())) u = i.getParcelableExtra(Intent.EXTRA_STREAM);
        if (u != null) importProject(u);
    }

    @Override
    protected void onPause() {
        super.onPause();
        hub.saveSync();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!stack.isEmpty()) top().refresh();
    }

    // ================================================================== экраны

    Screen top() {
        return stack.get(stack.size() - 1);
    }

    void push(Screen s) {
        if (!stack.isEmpty()) top().onHidden();
        stack.add(s);
        show(s);
    }

    /** Заменить верхний экран (например, «Новый сайт» → редактор). */
    void replace(Screen s) {
        if (!stack.isEmpty()) {
            Screen t = stack.remove(stack.size() - 1);
            t.onHidden();
            t.onRemoved();
        }
        stack.add(s);
        show(s);
    }

    /** Закрыть экраны поверх target (без их «назад»). */
    void popTo(Screen target) {
        if (!stack.contains(target)) return;
        boolean changed = false;
        while (top() != target) {
            Screen s = stack.remove(stack.size() - 1);
            s.onHidden();
            s.onRemoved();
            changed = true;
        }
        if (changed) show(target);
    }

    void home() {
        while (stack.size() > 1) {
            Screen s = stack.remove(stack.size() - 1);
            s.onHidden();
            s.onRemoved();
        }
        show(stack.get(0));
    }

    private void show(Screen s) {
        hideKeyboard();
        host.removeAllViews();
        host.addView(s, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        s.setAlpha(0f);
        s.animate().alpha(1f).setDuration(120).start();
        s.onShown();
        s.refresh();
    }

    void back() {
        if (panel.isOpen()) {
            panel.close();
            return;
        }
        if (top().back()) return;
        if (stack.size() > 1) {
            Screen s = stack.remove(stack.size() - 1);
            s.onHidden();
            s.onRemoved();
            show(top());
        } else {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        back();
    }

    <T extends Screen> T find(Class<T> cls) {
        for (Screen s : stack) if (cls.isInstance(s)) return cls.cast(s);
        return null;
    }

    // ================================================================== сообщения и диалоги

    void toast(String text) {
        toastView.setText(text);
        toastView.setVisibility(View.VISIBLE);
        toastView.setAlpha(0f);
        toastView.animate().alpha(1f).setDuration(150).start();
        toastView.removeCallbacks(hideToast);
        toastView.postDelayed(hideToast, Math.max(2400, text.length() * 55L));
    }

    private final Runnable hideToast = () -> toastView.animate().alpha(0f).setDuration(200).withEndAction(() -> toastView.setVisibility(View.GONE)).start();

    /** Вопрос «да / нет» в панели. */
    void confirm(String title, String text, String ok, boolean danger, Runnable yes) {
        LinearLayout p = panel.open(title, true);
        if (text != null && !text.isEmpty()) {
            TextView t = ui.text(text, 14.5f, Theme.MUTED, false);
            t.setLineSpacing(0, 1.25f);
            p.addView(t, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(6), 0, ui.dp(18)));
        }
        LinearLayout row = ui.row();
        row.addView(ui.button("Отмена", false, v -> panel.close()), Ui.lp(0, Ui.WRAP, 1f));
        TextView go = ui.button(ok, true, v -> {
            panel.close();
            yes.run();
        });
        if (danger) go.setBackground(Ui.ripple(Ui.round(0xFFE5484D, ui.dp(14)), null));
        if (danger) go.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams lp = Ui.lp(0, Ui.WRAP, 1f);
        lp.leftMargin = ui.dp(10);
        row.addView(go, lp);
        p.addView(row, Ui.lp(Ui.MATCH, Ui.WRAP));
    }

    /** Ввести строку в панели. */
    void ask(String title, String hint, String value, String ok, Text done) {
        LinearLayout p = panel.open(title, true);
        EditText e = field(value, hint, false);
        e.setImeOptions(EditorInfo.IME_ACTION_DONE);
        p.addView(e, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(8), 0, ui.dp(16)));
        Runnable go = () -> {
            String v = e.getText().toString().trim();
            if (v.isEmpty()) {
                e.setError("Пусто");
                return;
            }
            hideKeyboard();
            panel.close();
            done.done(v);
        };
        e.setOnEditorActionListener((v, id, ev) -> {
            go.run();
            return true;
        });
        p.addView(ui.button(ok, true, v -> go.run()), Ui.lp(Ui.MATCH, Ui.WRAP));
        e.requestFocus();
        e.setSelection(e.getText().length());
        e.postDelayed(() -> {
            InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (im != null) im.showSoftInput(e, 0);
        }, 200);
    }

    LinearLayout panelContent() {
        return panel.content();
    }

    /** Поле ввода в стиле приложения. */
    EditText field(String value, String hint, boolean multi) {
        EditText e = new EditText(this);
        e.setText(value == null ? "" : value);
        e.setHint(hint == null ? "" : hint);
        e.setTextColor(Theme.TEXT);
        e.setHintTextColor(0xFF6E6688);
        e.setTextSize(15.5f);
        e.setBackground(Ui.stroke(Theme.SURFACE2, Theme.LINE, ui.dp(1), ui.dp(12)));
        e.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12));
        if (multi) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            e.setMinLines(3);
            e.setGravity(Gravity.TOP | Gravity.START);
            e.setSingleLine(false);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            e.setSingleLine(true);
        }
        return e;
    }

    void hideKeyboard() {
        View v = getCurrentFocus();
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (v != null && im != null) im.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    void copy(String label, String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(label, text));
        if (Build.VERSION.SDK_INT < 33) toast("Скопировано");
    }

    // ================================================================== файлы

    /** Выбрать картинку (или несколько) из галереи / файлов. */
    void pickImages(boolean many, Result done) {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        if (many) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        start(Intent.createChooser(i, many ? "Выберите фото" : "Выберите фото"), done);
    }

    /** Выбрать архив проекта. */
    void pickZip(Result done) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed", "application/json", "application/octet-stream"});
        start(i, done);
    }

    private void start(Intent i, Result done) {
        int req = nextReq++;
        results.put(req, done);
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            results.remove(req);
            toast("Нет приложения для выбора файлов");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        Result r = results.get(req);
        results.remove(req);
        if (r == null || res != RESULT_OK || data == null) return;
        List<Uri> out = new ArrayList<>();
        ClipData cd = data.getClipData();
        if (cd != null) for (int k = 0; k < cd.getItemCount(); k++) if (cd.getItemAt(k).getUri() != null) out.add(cd.getItemAt(k).getUri());
        if (out.isEmpty() && data.getData() != null) out.add(data.getData());
        if (!out.isEmpty()) r.done(out);
    }

    /** Загрузить картинки в проект (в фоне) и вернуть пути img/…; maxSide — ограничение размера (0 — обычное). */
    void importImages(List<Uri> uris, int maxSide, Text eachDone, Runnable allDone) {
        if (hub.site == null) return;
        File dir = hub.store.img(hub.site.id);
        toast(uris.size() > 1 ? "Добавляю " + uris.size() + " фото…" : "Добавляю фото…");
        hub.io.execute(() -> {
            int fail = 0;
            String err = null;
            for (Uri u : uris) {
                try {
                    String path = Images.put(this, u, dir, maxSide);
                    runOnUiThread(() -> eachDone.done(path));
                } catch (Exception e) {
                    fail++;
                    err = e.getMessage();
                }
            }
            final int f = fail;
            final String er = err;
            runOnUiThread(() -> {
                if (f > 0) toast("Не получилось добавить " + (f == 1 ? "фото" : f + " фото") + (er == null ? "" : ": " + er));
                if (allDone != null) allDone.run();
            });
        });
    }

    /** Открыть проект из архива. */
    void importProject(Uri u) {
        toast("Открываю проект…");
        hub.io.execute(() -> {
            String id = Site.newId();
            File dir = hub.store.dir(id);
            try (InputStream in = getContentResolver().openInputStream(u)) {
                if (in == null) throw new IOException("файл не открывается");
                Site s;
                String name = Images.displayName(this, u).toLowerCase(java.util.Locale.ROOT);
                if (name.endsWith(".json")) {
                    s = Site.fromJson(new String(Pack.read(in, 16 * 1024 * 1024), java.nio.charset.StandardCharsets.UTF_8));
                    s.id = Site.newId();
                    dir = hub.store.dir(s.id);
                } else {
                    s = Pack.importZip(in, dir);
                }
                s.id = dir.getName();
                s.updated = System.currentTimeMillis();
                hub.store.save(s);
                runOnUiThread(() -> {
                    toast("Проект «" + s.name + "» открыт");
                    home();
                    top().refresh();
                });
            } catch (Exception e) {
                Store.rm(dir);
                runOnUiThread(() -> toast("Не получилось открыть: " + e.getMessage()));
            }
        });
    }

    interface Writer {
        void write(OutputStream out) throws IOException;
    }

    interface Saved {
        void done(File shareFile, String where);
    }

    /**
     * Собрать файл: сначала во временную папку (чтобы им можно было поделиться), затем копия в «Загрузки/Neon Site».
     */
    void export(String name, String mime, Writer w, Saved done) {
        Runnable go = () -> hub.io.execute(() -> {
            File tmp = new File(Files.outDir(this), name);
            try {
                try (OutputStream o = new FileOutputStream(tmp)) {
                    w.write(o);
                }
                String where = toDownloads(tmp, name, mime);
                runOnUiThread(() -> done.done(tmp, where));
            } catch (Exception e) {
                runOnUiThread(() -> toast("Не получилось: " + e.getMessage()));
            }
        });
        if (Build.VERSION.SDK_INT < 29) ask(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, go, go);
        else go.run();
    }

    /** Копия в «Загрузки/Neon Site». Возвращает, куда легло (или null, если не получилось). */
    private String toDownloads(File f, String name, String mime) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Neon Site");
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) return null;
                try (OutputStream o = getContentResolver().openOutputStream(u); InputStream in = new FileInputStream(f)) {
                    if (o == null) return null;
                    Pack.copy(in, o);
                }
                return "Загрузки/Neon Site";
            } else {
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) return null;
                File d = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Neon Site");
                if (!d.isDirectory() && !d.mkdirs()) return null;
                File out = new File(d, name);
                int k = 2;
                while (out.exists()) out = new File(d, name.replaceFirst("(\\.[a-z]+)$", " (" + (k++) + ")$1"));
                Store.copy(f, out);
                return "Загрузки/Neon Site";
            }
        } catch (Exception e) {
            return null;
        }
    }

    void share(File f, String mime, String text) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_STREAM, Files.uri(this, f));
        i.putExtra(Intent.EXTRA_SUBJECT, f.getName());
        if (text != null) i.putExtra(Intent.EXTRA_TEXT, text);
        i.setClipData(ClipData.newRawUri(f.getName(), Files.uri(this, f)));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(i, "Отправить"));
        } catch (Exception e) {
            toast("Нечем поделиться");
        }
    }

    void openUrl(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            if (url.startsWith("tel:")) i = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
            startActivity(i);
        } catch (Exception e) {
            toast("Нет приложения, чтобы открыть: " + url);
        }
    }

    // ================================================================== разрешения

    void ask(String[] list, Runnable ok, Runnable no) {
        ArrayList<String> need = new ArrayList<>();
        for (String p : list) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        if (need.isEmpty()) {
            if (ok != null) ok.run();
            return;
        }
        int req = nextReq++;
        perms.put(req, new Runnable[]{ok, no});
        requestPermissions(need.toArray(new String[0]), req);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] list, int[] res) {
        Runnable[] cb = perms.get(req);
        perms.remove(req);
        if (cb == null) return;
        boolean all = res.length > 0;
        for (int r : res) if (r != PackageManager.PERMISSION_GRANTED) all = false;
        Runnable r = all ? cb[0] : cb[1];
        if (r != null) r.run();
    }

    // ================================================================== настройки

    void settings() {
        LinearLayout p = panel.open("Настройки");
        Prefs pr = hub.prefs;
        panel.section(p, "ЦВЕТ ПРИЛОЖЕНИЯ");
        LinearLayout chips = panel.chipRow(p);
        for (int i = 0; i < Theme.ACCENT_NAMES.length; i++) {
            int k = i;
            panel.chip(chips, Theme.ACCENT_NAMES[i], pr.accent() == i, () -> {
                pr.put("accent", k);
                Theme.load(this);
                recreate();
            });
        }
        panel.section(p, "КАК ЭТО РАБОТАЕТ");
        panel.note(p, "1. Создайте сайт из шаблона или с нуля.\n"
                + "2. Нажимайте на блоки в предпросмотре — меняйте тексты, фото, цвета, ссылки. «+ Блок» — добавить новый.\n"
                + "3. В «Пожеланиях» у блока и у всего сайта пишите, что хотите доработать — словами.\n"
                + "4. «Готово» → «Проект для Claude»: архив с описанием, картинками и черновиком сайта. Пришлите его в чат Claude — он сделает готовый код.\n"
                + "5. Или сразу заберите «Готовый сайт» — его можно выложить на любой хостинг.");
        panel.section(p, "О ПРИЛОЖЕНИИ");
        panel.note(p, "Neon Site " + version() + ". Проекты хранятся только на этом телефоне; архивы — в «Загрузки/Neon Site».");
    }

    String version() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }
}
