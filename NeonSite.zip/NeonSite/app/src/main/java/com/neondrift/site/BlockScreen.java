package com.neondrift.site;

import android.view.Gravity;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Редактирование одного блока: вариант, содержимое, список пунктов, фон и отступы, пожелания. Сверху — живой предпросмотр. */
final class BlockScreen extends Screen {
    private final Site.Block b;
    private final Site.Page page;
    private final Blocks.Type type;
    private final WebView web;
    private final LinearLayout body;
    private final ScrollView scroll;
    private final Form form;
    private boolean loaded;
    private final Set<Integer> open = new HashSet<>();

    BlockScreen(MainActivity a, Site.Block b, Site.Page page) {
        super(a);
        this.b = b;
        this.page = page;
        this.type = Blocks.type(b.type);
        LinearLayout h = header(type.name, page == null ? "На всех страницах" : "Страница «" + page.title + "»");
        h.addView(ui.iconButton("eye", Theme.TEXT, 42, 11, v -> togglePreview()));
        if (page != null) h.addView(ui.iconButton("trash", 0xFFFF6B6B, 42, 11, v -> a.confirm("Удалить блок?", "Его можно будет вернуть кнопкой «Отменить» в редакторе.", "Удалить", true, () -> {
            page.blocks.remove(b);
            a.back();
        })));

        web = Web.make(a, null);
        web.setWebViewClient(new Web.Client(a, false) {
            @Override
            public void onPageFinished(WebView view, String url) {
                loaded = true;
            }
        });
        web.setVisibility(hub.prefs.blockPreview() ? VISIBLE : GONE);
        int hgt = Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.30f);
        addView(web, Ui.lp(Ui.MATCH, hgt));
        View line = new View(a);
        line.setBackgroundColor(Theme.LINE);
        addView(line, Ui.lp(Ui.MATCH, ui.dp(1)));

        scroll = new ScrollView(a);
        scroll.setFillViewport(true);
        body = ui.col();
        body.setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(48));
        scroll.addView(body);
        addView(scroll, Ui.lp(Ui.MATCH, 0, 1f));
        form = new Form(a, body, this::changed);
        if (type.id.equals("gallery") || type.id.equals("faq") || type.id.equals("pricing")) {
            // у длинных списков сначала всё свёрнуто
        } else {
            int n = b.v.get("items") instanceof List ? ((List<?>) b.v.get("items")).size() : 0;
            for (int i = 0; i < Math.min(3, n); i++) open.add(i);
        }
        build();
        preview(true);
    }

    // ================================================================== предпросмотр

    private final Runnable later = () -> preview(false);

    private void changed() {
        hub.saveSoon();
        removeCallbacks(later);
        postDelayed(later, 280);
    }

    private void preview(boolean full) {
        if (web.getVisibility() != VISIBLE) return;
        Gen.Opt o = Gen.preview("", hub.prefs.device() == 1 ? 1280 : 0);
        o.only = b.id;
        Site.Page p = page != null ? page : hub.site.home();
        String html = Gen.page(hub.site, p, o);
        if (!full && loaded) web.evaluateJavascript("neonSwap(" + Web.js(html) + ")", null);
        else {
            loaded = false;
            web.loadDataWithBaseURL(Web.BASE + "block.html", html, "text/html", "utf-8", null);
        }
    }

    private boolean wantPreview() {
        return hub.prefs.blockPreview();
    }

    private void togglePreview() {
        boolean on = web.getVisibility() != VISIBLE;
        web.setVisibility(on ? VISIBLE : GONE);
        hub.prefs.put("blockPreview", on);
        if (on) preview(true);
    }

    // ================================================================== форма

    /** Пересобрать форму (после смены варианта, добавления пункта и т. п.), сохранив прокрутку. */
    void rebuild() {
        int y = scroll.getScrollY();
        build();
        scroll.post(() -> scroll.scrollTo(0, y));
        preview(false);
    }

    private void build() {
        body.removeAllViews();
        if (type.variants.length > 1) {
            form.section("ВИД");
            form.choice(null, type.variants, type.variantNames, b.variant, v -> {
                b.variant = v;
                if (b.type.equals("hero") && v.equals("full") && b.s("height").equals("tall")) b.v.put("height", "screen");
                post(this::rebuild);
            });
        }
        form.section("СОДЕРЖИМОЕ");
        Blocks.Field itemsField = null;
        for (Blocks.Field f : type.fields) {
            if (f.kind.equals(Blocks.ITEMS)) {
                itemsField = f;
                continue;
            }
            if (!f.visible(b.variant, b.v)) continue;
            field(f, b.v, true);
        }
        if (itemsField != null) items(itemsField);
        if (b.type.equals("posts")) form.note("Записи — это страницы с типом «Запись блога». Добавить: «Страницы» → «+ Страница» → «Запись блога».");
        if (b.type.equals("form")) form.note("Без сервера форма открывает почту посетителя с готовым письмом. Чтобы заявки приходили сами, "
                + "заведите бесплатный обработчик (например, Formspree), выберите «На свой адрес обработчика» и вставьте его адрес.");
        if (b.type.equals("header")) form.note("Меню из страниц появляется, когда у сайта 2 и больше страниц. На одностраничном сайте добавьте свои пункты — ссылки на блоки.");

        section();
        notes();
    }

    /** Поле блока (или пункта списка). top — поле самого блока (для зависимостей и пересборки). */
    private void field(Blocks.Field f, Map<String, Object> m, boolean top) {
        String val = m.get(f.key) == null ? "" : String.valueOf(m.get(f.key));
        switch (f.kind) {
            case Blocks.TEXT:
                form.text(f.label, f.hint, val, false, v -> m.put(f.key, v));
                break;
            case Blocks.LONG:
                form.text(f.label, f.hint.isEmpty() ? "**жирный**, строки с «- » — список" : f.hint, val, true, v -> m.put(f.key, v));
                break;
            case Blocks.IMAGE:
                form.image(f.label, f.hint, val, f.key.equals("logoImage") ? 600 : f.key.equals("photo") ? 900 : 0, v -> {
                    m.put(f.key, v);
                    if (!top) post(this::rebuild); // обновить миниатюру в заголовке пункта
                });
                break;
            case Blocks.LINK:
                form.link(f.label, val, page, v -> m.put(f.key, v));
                break;
            case Blocks.CHOICE:
                form.choice(f.label, f.opts, f.optNames, val.isEmpty() && f.opts.length > 0 ? f.opts[0] : val, v -> {
                    m.put(f.key, v);
                    if (top && dependsOn(f.key)) post(this::rebuild);
                });
                break;
            case Blocks.BOOL:
                form.bool(f.label, f.hint, Boolean.TRUE.equals(m.get(f.key)) || "true".equals(val), v -> m.put(f.key, v));
                break;
            case Blocks.NUM:
                int n;
                try {
                    n = val.isEmpty() ? f.min : (int) Double.parseDouble(val);
                } catch (NumberFormatException e) {
                    n = f.min;
                }
                form.num(f.label, n, f.min, f.max == 0 ? 100 : f.max, v -> m.put(f.key, (long) v));
                break;
            case Blocks.ICON:
                form.icon(f.label, val, v -> m.put(f.key, v));
                break;
            case Blocks.COLOR:
                form.color(f.label, val.isEmpty() ? "#000000" : val, v -> m.put(f.key, v));
                break;
            default:
                break;
        }
    }

    private boolean dependsOn(String key) {
        for (Blocks.Field f : type.fields) if (key.equals(f.depKey)) return true;
        return false;
    }

    // ================================================================== список пунктов

    private void items(Blocks.Field f) {
        List<Map<String, Object>> list = b.items();
        form.section((f.label + " · " + list.size()).toUpperCase(java.util.Locale.ROOT));
        for (int i = 0; i < list.size(); i++) item(f, list, i);
        LinearLayout row = ui.row();
        TextView add = ui.button("+ Добавить " + type.itemName, false, v -> {
            Map<String, Object> it = new LinkedHashMap<>(Blocks.newItem(b.type));
            list.add(it);
            open.add(list.size() - 1);
            changed();
            rebuild();
            scroll.postDelayed(() -> scroll.fullScroll(View.FOCUS_DOWN), 120);
        });
        row.addView(add, Ui.lp(0, Ui.WRAP, 1f));
        if (b.type.equals("gallery")) {
            LinearLayout.LayoutParams lp = Ui.lp(0, Ui.WRAP, 1f);
            lp.leftMargin = ui.dp(8);
            row.addView(ui.button("+ Несколько фото", true, v -> a.pickImages(true, uris -> {
                // пустые ячейки галереи заполняются первыми
                a.importImages(uris, 0, path -> {
                    Map<String, Object> slot = null;
                    for (Map<String, Object> it : list) {
                        Object im = it.get("image");
                        if (im == null || String.valueOf(im).isEmpty()) {
                            slot = it;
                            break;
                        }
                    }
                    if (slot == null) {
                        slot = new LinkedHashMap<>(Blocks.newItem("gallery"));
                        list.add(slot);
                    }
                    slot.put("image", path);
                    changed();
                }, this::rebuild);
            })), lp);
        }
        body.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(4), 0, ui.dp(6)));
    }

    private void item(Blocks.Field f, List<Map<String, Object>> list, int i) {
        Map<String, Object> it = list.get(i);
        boolean isOpen = open.contains(i);
        LinearLayout card = ui.col();
        card.setBackground(Ui.stroke(Theme.SURFACE, isOpen ? Theme.alpha(Theme.ACCENT, 120) : Theme.LINE, ui.dp(1), ui.dp(16)));
        LinearLayout head = ui.row();
        head.setPadding(ui.dp(10), ui.dp(6), ui.dp(2), ui.dp(6));
        // миниатюра или номер
        String img = firstImage(f, it);
        if (img != null && !img.isEmpty()) {
            ImageView th = new ImageView(a);
            th.setClipToOutline(true);
            th.setOutlineProvider(Ui.rounded(ui.dp(8)));
            form.thumb(th, img);
            head.addView(th, Ui.lp(ui.dp(40), ui.dp(40)));
        } else {
            TextView num = ui.text(String.valueOf(i + 1), 13, Theme.ACCENT, true);
            num.setGravity(Gravity.CENTER);
            num.setBackground(Ui.oval(Theme.alpha(Theme.ACCENT, 34)));
            head.addView(num, Ui.lp(ui.dp(30), ui.dp(30)));
        }
        TextView title = ui.oneLine(summary(f, it, i), 14.5f, Theme.TEXT, isOpen);
        title.setPadding(ui.dp(10), 0, ui.dp(4), 0);
        head.addView(title, Ui.lp(0, Ui.WRAP, 1f));
        head.addView(tiny("up", i > 0, v -> swap(list, i, i - 1)));
        head.addView(tiny("down", i < list.size() - 1, v -> swap(list, i, i + 1)));
        head.addView(tiny("copy", true, v -> {
            list.add(i + 1, Json.deep(it));
            shiftOpen(i + 1, 1);
            open.add(i + 1);
            changed();
            rebuild();
        }));
        head.addView(tiny("trash", true, v -> {
            list.remove(i);
            shiftOpen(i, -1);
            changed();
            rebuild();
        }));
        head.setOnClickListener(v -> {
            if (open.contains(i)) open.remove(i);
            else open.add(i);
            rebuild();
        });
        card.addView(head);
        if (isOpen) {
            LinearLayout inner = ui.col();
            inner.setPadding(ui.dp(12), ui.dp(2), ui.dp(12), ui.dp(6));
            LinearLayout saved = form.root;
            form.root = inner;
            for (Blocks.Field sf : f.sub) {
                if (b.type.equals("features") && b.variant.equals("numbered") && (sf.key.equals("icon") || sf.key.equals("image"))) continue;
                field(sf, it, false);
            }
            form.root = saved;
            card.addView(inner);
        }
        body.addView(card, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(8)));
    }

    private ImageView tiny(String icon, boolean enabled, View.OnClickListener l) {
        ImageView v = ui.iconButton(icon, Theme.TEXT, 36, 9, l);
        v.setAlpha(enabled ? 0.9f : 0.25f);
        v.setEnabled(enabled);
        return v;
    }

    private void swap(List<Map<String, Object>> list, int i, int j) {
        Map<String, Object> x = list.get(i);
        list.set(i, list.get(j));
        list.set(j, x);
        boolean oi = open.contains(i), oj = open.contains(j);
        open.remove(i);
        open.remove(j);
        if (oi) open.add(j);
        if (oj) open.add(i);
        changed();
        rebuild();
    }

    /** Номера раскрытых пунктов после вставки/удаления. */
    private void shiftOpen(int from, int d) {
        Set<Integer> n = new HashSet<>();
        for (int k : open) {
            if (k < from) n.add(k);
            else if (d < 0 && k == from) continue;
            else n.add(k + d);
        }
        open.clear();
        open.addAll(n);
    }

    private static String firstImage(Blocks.Field f, Map<String, Object> it) {
        for (Blocks.Field sf : f.sub) {
            if (sf.kind.equals(Blocks.IMAGE)) {
                Object o = it.get(sf.key);
                if (o != null && !String.valueOf(o).isEmpty()) return String.valueOf(o);
            }
        }
        return null;
    }

    private String summary(Blocks.Field f, Map<String, Object> it, int i) {
        for (String k : new String[]{"title", "name", "q", "num", "text", "caption"}) {
            Object o = it.get(k);
            if (o != null && !String.valueOf(o).trim().isEmpty()) {
                String s = String.valueOf(o).trim().replace('\n', ' ').replace("*", "");
                if (k.equals("num") && it.get("label") != null) s += " " + it.get("label");
                if (k.equals("name") && it.get("price") != null && !String.valueOf(it.get("price")).isEmpty()) s += " — " + it.get("price");
                return s;
            }
        }
        Object icon = it.get("icon");
        if (icon != null && !String.valueOf(icon).isEmpty()) return String.valueOf(icon);
        return b.type.equals("gallery") ? "Фото " + (i + 1) : "Пункт " + (i + 1);
    }

    // ================================================================== фон, отступы, пожелания

    private static final String[] BG = {"auto", "surface", "primary", "accent", "dark", "light", "color", "image"};
    private static final String[] BG_NAMES = {"Обычный", "Второй фон", "Основной цвет", "Акцент", "Тёмный", "Светлый", "Свой цвет", "Картинка"};

    private void section() {
        boolean header = b.type.equals("header");
        if (header) {
            form.section("ПОКАЗ");
            form.bool("Скрыть шапку", "На всех страницах", b.hidden, v -> b.hidden = v);
            return;
        }
        form.section("ФОН И ОТСТУПЫ");
        form.choice("Фон", BG, BG_NAMES, b.bg, v -> {
            b.bg = v;
            post(this::rebuild);
        });
        if (b.bg.equals("color")) form.color("Цвет фона", b.bgColor.isEmpty() ? hub.site.look.surface : b.bgColor, v -> b.bgColor = v);
        if (b.bg.equals("image")) form.image("Фоновая картинка", "Поверх неё — затемнение, текст станет белым", b.bgImage, 0, v -> b.bgImage = v);
        if (b.type.equals("footer")) {
            form.bool("Скрыть подвал", "На всех страницах", b.hidden, v -> b.hidden = v);
            return;
        }
        form.choice("Отступы сверху и снизу", new String[]{"none", "s", "m", "l"}, new String[]{"Без отступов", "Маленькие", "Средние", "Большие"}, b.pad, v -> b.pad = v);
        form.choice("Где показывать", new String[]{"all", "mobile", "desktop"}, new String[]{"Везде", "Только на телефонах", "Только на компьютерах"}, b.show, v -> b.show = v);
        form.text("Якорь для ссылок", "например: prices — тогда ссылка «#prices» прокрутит сюда", b.anchor, false, v -> b.anchor = Slug.of(v));
        form.bool("Скрыть блок", "Останется в редакторе, но на сайт не попадёт", b.hidden, v -> b.hidden = v);
    }

    private void notes() {
        form.section("ПОЖЕЛАНИЯ ДЛЯ CLAUDE");
        form.note("Опишите словами, что доработать в этом блоке: «сделай фон с лёгкой текстурой», «добавь таймер до даты», «кнопка должна вести в WhatsApp». "
                + "Это попадёт в «Проект для Claude».");
        form.text(null, "Что изменить или добавить…", b.notes, true, v -> b.notes = v);
    }

    @Override
    void onShown() {
        // вернулись, например, после выбора файла — предпросмотр мог устареть
        if (loaded) preview(false);
    }

    private boolean keyboard;

    /** Открылась клавиатура (экран заметно сжался) — убрать предпросмотр, чтобы было где печатать; закрылась — вернуть. */
    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (ow != w || oh == 0) return;
        boolean kb = h < oh * 0.8f ? true : h > oh * 1.2f ? false : keyboard;
        if (kb == keyboard) return;
        keyboard = kb;
        post(() -> {
            boolean want = !keyboard && wantPreview();
            web.setVisibility(want ? VISIBLE : GONE);
            if (want) preview(false);
        });
    }

    @Override
    boolean back() {
        a.hideKeyboard();
        hub.saveSoon();
        return false;
    }

    @Override
    void onRemoved() {
        removeCallbacks(later);
        web.destroy();
    }
}
