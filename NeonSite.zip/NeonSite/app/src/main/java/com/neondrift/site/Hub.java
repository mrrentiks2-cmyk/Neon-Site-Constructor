package com.neondrift.site;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** То, что живёт дольше экрана: настройки, проекты, открытый сайт, фоновые задачи. */
final class Hub {
    private static Hub inst;

    static synchronized Hub get(Context c) {
        if (inst == null) inst = new Hub(c.getApplicationContext());
        return inst;
    }

    final Context app;
    final Prefs prefs;
    final Store store;
    final Handler main = new Handler(Looper.getMainLooper());
    /** Один фоновый поток: запись проекта, картинки, архивы — по очереди, без гонок. */
    final ExecutorService io = Executors.newSingleThreadExecutor();

    /** Открытый в редакторе сайт. */
    Site site;

    private Hub(Context c) {
        app = c;
        prefs = new Prefs(c);
        store = new Store(c);
        Theme.load(c);
    }

    File dir() {
        return store.dir(site.id);
    }

    private final Runnable saveNow = this::saveSync;
    private String lastSaved = "";

    /** Сохранить чуть позже (несколько изменений подряд — одна запись). */
    void saveSoon() {
        main.removeCallbacks(saveNow);
        main.postDelayed(saveNow, 700);
    }

    /** Сохранить сейчас (в фоне). Снимок делается здесь, на главном потоке, — пишется уже готовая строка. */
    void saveSync() {
        main.removeCallbacks(saveNow);
        if (site == null) return;
        final Site s = site;
        String body = s.state();
        if (body.equals(lastSaved)) return;
        lastSaved = body;
        s.updated = System.currentTimeMillis();
        final String json = s.toJson(), id = s.id;
        io.execute(() -> {
            try {
                store.write(id, json);
            } catch (Exception e) {
                lastSaved = "";
                main.post(() -> toast("Не удалось сохранить: " + e.getMessage()));
            }
        });
    }

    interface Toaster {
        void toast(String s);
    }

    Toaster toaster;

    void toast(String s) {
        if (toaster != null) toaster.toast(s);
    }

    void open(Site s) {
        site = s;
        lastSaved = s.state();
    }
}
