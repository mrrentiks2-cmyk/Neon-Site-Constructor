package com.neondrift.site;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Помощник для сборки интерфейса кодом. */
final class Ui {
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    final Context c;
    final float density;

    Ui(Context c) {
        this.c = c;
        density = c.getResources().getDisplayMetrics().density;
    }

    int dp(float v) {
        return Math.round(v * density);
    }

    TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    TextView oneLine(String s, float sp, int color, boolean bold) {
        TextView t = text(s, sp, color, bold);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }

    TextView label(String s) {
        TextView t = text(s, 11, Theme.MUTED, true);
        t.setLetterSpacing(0.16f);
        return t;
    }

    LinearLayout row() {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    LinearLayout col() {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    static LinearLayout.LayoutParams lp(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    static LinearLayout.LayoutParams margins(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, t, r, b);
        return p;
    }

    static GradientDrawable round(int fill, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius);
        return g;
    }

    static GradientDrawable stroke(int fill, int stroke, int width, float radius) {
        GradientDrawable g = round(fill, radius);
        g.setStroke(width, stroke);
        return g;
    }

    static GradientDrawable oval(int fill) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        return g;
    }

    static Drawable ripple(Drawable content, Drawable mask) {
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, mask);
    }

    /** Круглая иконка-кнопка с безграничной волной при нажатии. */
    ImageView iconButton(String icon, int color, int sizeDp, int padDp, View.OnClickListener l) {
        ImageView v = new ImageView(c);
        v.setImageDrawable(new Glyph(icon, color));
        int pad = dp(padDp);
        v.setPadding(pad, pad, pad, pad);
        v.setBackground(new RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), null, null));
        v.setOnClickListener(l);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        v.setContentDescription(icon);
        return v;
    }

    TextView button(String s, boolean primary, View.OnClickListener l) {
        TextView b = text(s, 15, primary ? Theme.BG : Theme.TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(18), dp(13), dp(18), dp(13));
        Drawable bg = primary
                ? round(Theme.ACCENT, dp(14))
                : stroke(Theme.SURFACE, Theme.LINE, dp(1), dp(14));
        b.setBackground(ripple(bg, null));
        b.setOnClickListener(l);
        return b;
    }

    TextView chip(String s, boolean on, View.OnClickListener l) {
        TextView t = text(s, 14, on ? Theme.TEXT : Theme.MUTED, on);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        styleChip(t, on);
        t.setOnClickListener(l);
        return t;
    }

    void styleChip(TextView t, boolean on) {
        t.setBackground(ripple(stroke(on ? Theme.alpha(Theme.ACCENT, 50) : Theme.SURFACE2,
                on ? Theme.ACCENT : Theme.LINE, dp(1), dp(100)), null));
        t.setTextColor(on ? Theme.TEXT : Theme.MUTED);
        t.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
    }

    static ViewOutlineProvider rounded(final float r) {
        return new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), r);
            }
        };
    }
}
