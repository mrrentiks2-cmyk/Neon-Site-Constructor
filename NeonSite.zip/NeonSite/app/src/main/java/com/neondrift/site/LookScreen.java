package com.neondrift.site;

import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Стиль сайта: палитра, цвета, шрифты, скругления, кнопки, ширина, тени и анимация — с живым предпросмотром. */
final class LookScreen extends Screen {
    private final Site.Page page;
    private final WebView web;
    private final LinearLayout body;
    private final ScrollView scroll;
    private final Form form;
    private boolean loaded;

    LookScreen(MainActivity a, Site.Page page) {
        super(a);
        this.page = page;
        header("Стиль сайта", "Цвета, шрифты, кнопки — для всех страниц");
        web = Web.make(a, null);
        web.setWebViewClient(new Web.Client(a, false) {
            @Override
            public void onPageFinished(WebView view, String url) {
                loaded = true;
            }
        });
        addView(web, Ui.lp(Ui.MATCH, Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.34f)));
        View line = new View(a);
        line.setBackgroundColor(Theme.LINE);
        addView(line, Ui.lp(Ui.MATCH, ui.dp(1)));
        scroll = new ScrollView(a);
        body = ui.col();
        body.setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(48));
        scroll.addView(body);
        addView(scroll, Ui.lp(Ui.MATCH, 0, 1f));
        form = new Form(a, body, this::changed);
        build();
        preview(true);
    }

    private final Runnable later = () -> preview(false);

    private void changed() {
        hub.saveSoon();
        removeCallbacks(later);
        postDelayed(later, 200);
    }

    private void preview(boolean full) {
        Gen.Opt o = Gen.preview("", hub.prefs.device() == 1 ? 1280 : 0);
        String html = Gen.page(hub.site, page, o);
        if (!full && loaded) web.evaluateJavascript("neonSwap(" + Web.js(html) + ")", null);
        else {
            loaded = false;
            web.loadDataWithBaseURL(Web.BASE + hub.site.file(page), html, "text/html", "utf-8", null);
        }
    }

    private boolean wantPreview() {
        return true;
    }

    private void rebuild() {
        int y = scroll.getScrollY();
        build();
        scroll.post(() -> scroll.scrollTo(0, y));
    }

    private void build() {
        body.removeAllViews();
        Site.Look l = hub.site.look;
        form.section("ПАЛИТРА");
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = ui.row();
        hs.addView(row);
        for (Themes.Palette p : Themes.PALETTES) {
            row.addView(paletteCard(p, p.id.equals(l.palette)), Ui.margins(ui.dp(84), Ui.WRAP, 0, 0, ui.dp(8), 0));
        }
        body.addView(hs, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(4)));

        form.section("ЦВЕТА");
        form.note("Можно поменять любой цвет палитры — например, основной цвет под ваш логотип.");
        form.color("Основной (кнопки, ссылки)", l.primary, v -> {
            l.primary = v;
            l.onPrimary = Gen.luma(v) > 0.62 ? "#111111" : "#FFFFFF";
        });
        form.color("Акцент (подсветки, свечение)", l.accent, v -> l.accent = v);
        form.color("Фон", l.bg, v -> {
            l.bg = v;
            l.dark = Gen.luma(v) < 0.4;
        });
        form.color("Второй фон (полосы, карточки)", l.surface, v -> l.surface = v);
        form.color("Текст", l.text, v -> l.text = v);
        form.color("Приглушённый текст", l.muted, v -> l.muted = v);
        form.color("Линии и рамки", l.border, v -> l.border = v);
        form.color("Текст на основном цвете", l.onPrimary, v -> l.onPrimary = v);

        form.section("ШРИФТЫ");
        for (Themes.Fonts f : Themes.FONTS) {
            boolean on = f.id.equals(l.fonts);
            LinearLayout r = ui.row();
            r.setPadding(ui.dp(14), ui.dp(11), ui.dp(12), ui.dp(11));
            r.setBackground(Ui.ripple(Ui.stroke(on ? Theme.alpha(Theme.ACCENT, 40) : Theme.SURFACE, on ? Theme.ACCENT : Theme.LINE, ui.dp(1), ui.dp(14)),
                    Ui.round(0xFFFFFFFF, ui.dp(14))));
            LinearLayout t = ui.col();
            t.addView(ui.text(f.name, 15.5f, Theme.TEXT, true));
            t.addView(ui.text(f.head.isEmpty() ? "Шрифты устройства посетителя — сайт грузится быстрее" : f.head.equals(f.body) ? f.head : f.head + " + " + f.body,
                    12.5f, Theme.MUTED, false), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(3), 0, 0));
            r.addView(t, Ui.lp(0, Ui.WRAP, 1f));
            if (on) r.addView(new android.widget.ImageView(a) {{
                setImageDrawable(new Glyph("check", Theme.ACCENT));
            }}, Ui.lp(ui.dp(22), ui.dp(22)));
            r.setOnClickListener(v -> {
                l.fonts = f.id;
                changed();
                rebuild();
            });
            body.addView(r, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(6)));
        }
        form.note("Шрифты подгружаются из Google Fonts — в предпросмотре нужен интернет.");

        form.section("ФОРМА");
        form.choice("Скругления", Themes.RADIUS, Themes.RADIUS_NAMES, l.radius, v -> l.radius = v);
        form.choice("Кнопки", Themes.BUTTONS, Themes.BUTTON_NAMES, l.buttons, v -> l.buttons = v);
        form.choice("Ширина содержимого", Themes.WIDTHS, Themes.WIDTH_NAMES, l.width, v -> l.width = v);
        form.bool("Тени", "Мягкие тени у карточек и фото", l.shadows, v -> l.shadows = v);
        form.bool("Появление при прокрутке", "Блоки плавно проявляются (в редакторе — выключено)", l.animate, v -> l.animate = v);

        form.section("СВОЙ CSS");
        form.note("Для тех, кто знает CSS: добавится в конец стилей сайта.");
        form.code(null, ".hero-text h1 { letter-spacing: -0.04em; }", hub.site.css, v -> hub.site.css = v);
    }

    private View paletteCard(Themes.Palette p, boolean on) {
        LinearLayout c = ui.col();
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(8));
        c.setBackground(Ui.stroke(on ? Theme.alpha(Theme.ACCENT, 40) : Theme.SURFACE, on ? Theme.ACCENT : Theme.LINE, ui.dp(on ? 2 : 1), ui.dp(14)));
        // маленькая «страница» в цветах палитры
        LinearLayout sw = ui.col();
        sw.setPadding(ui.dp(8), ui.dp(8), ui.dp(8), ui.dp(8));
        GradientDrawable g = Ui.round(Form.parse(p.bg), ui.dp(10));
        g.setStroke(ui.dp(1), 0x33FFFFFF);
        sw.setBackground(g);
        View t1 = new View(a);
        t1.setBackground(Ui.round(Form.parse(p.text), ui.dp(3)));
        sw.addView(t1, Ui.lp(ui.dp(40), ui.dp(6)));
        View t2 = new View(a);
        t2.setBackground(Ui.round(Form.parse(p.muted), ui.dp(3)));
        sw.addView(t2, Ui.margins(ui.dp(28), ui.dp(4), 0, ui.dp(5), 0, 0));
        LinearLayout dots = ui.row();
        View b1 = new View(a);
        b1.setBackground(Ui.round(Form.parse(p.primary), ui.dp(4)));
        dots.addView(b1, Ui.lp(ui.dp(24), ui.dp(10)));
        View b2 = new View(a);
        b2.setBackground(Ui.oval(Form.parse(p.accent)));
        dots.addView(b2, Ui.margins(ui.dp(10), ui.dp(10), ui.dp(6), 0, 0, 0));
        sw.addView(dots, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(8), 0, 0));
        c.addView(sw, Ui.lp(Ui.MATCH, ui.dp(58)));
        TextView n = ui.oneLine(p.name + (p.dark ? " ◐" : ""), 12.5f, on ? Theme.TEXT : Theme.MUTED, on);
        n.setGravity(Gravity.CENTER);
        c.addView(n, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(6), 0, 0));
        c.setOnClickListener(v -> {
            hub.site.look.palette(p);
            changed();
            rebuild();
        });
        return c;
    }

    private boolean keyboard;

    /** Открылась клавиатура (экран заметно сжался) — убрать предпросмотр, чтобы было где печатать; закрылась — вернуть. */
    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (ow != w || oh == 0) return;
        boolean kb = h < oh * 0.8f ? true : h > oh * 1.2f ? false : keyboard;
        if (kb == keyboard) return;
        keyboard = kb;
        post(() -> {
            boolean want = !keyboard && wantPreview();
            web.setVisibility(want ? VISIBLE : GONE);
            if (want) preview(false);
        });
    }

    @Override
    boolean back() {
        a.hideKeyboard();
        return false;
    }

    @Override
    void onRemoved() {
        removeCallbacks(later);
        web.destroy();
    }
}
