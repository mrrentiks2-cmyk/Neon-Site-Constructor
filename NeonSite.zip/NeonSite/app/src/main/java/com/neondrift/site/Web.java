package com.neondrift.site;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Встроенный браузер для предпросмотра. Сайт «живёт» по адресу https://site.neon/ — этот адрес никуда не ходит:
 * страницы, стили и картинки проекта отдаются прямо из приложения. Шрифты и карты грузятся из интернета как обычно.
 */
final class Web {
    private Web() {}

    static final String HOST = "site.neon";
    static final String BASE = "https://" + HOST + "/";

    /** Сообщения со страницы предпросмотра. */
    interface Bridge {
        void select(String blockId);

        void add(String type, String variant);

        void template(String id);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    static WebView make(MainActivity a, Bridge bridge) {
        WebView w = new WebView(a);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        w.setBackgroundColor(Theme.BG);
        w.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        if (bridge != null) w.addJavascriptInterface(new Js(a, bridge), "NeonEdit");
        return w;
    }

    /** Мост из страницы в приложение: вызовы приходят не на главном потоке — переносим. */
    static final class Js {
        private final MainActivity a;
        private final Bridge b;

        Js(MainActivity a, Bridge b) {
            this.a = a;
            this.b = b;
        }

        @JavascriptInterface
        public void select(String id) {
            a.runOnUiThread(() -> b.select(id == null ? "" : id));
        }

        @JavascriptInterface
        public void add(String type, String variant) {
            a.runOnUiThread(() -> b.add(type, variant));
        }

        @JavascriptInterface
        public void template(String id) {
            a.runOnUiThread(() -> b.template(id));
        }
    }

    /** Строка как литерал JavaScript (для evaluateJavascript). */
    static String js(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 16).append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case ' ': sb.append("\\u2028"); break;
                case ' ': sb.append("\\u2029"); break;
                case '<': sb.append("\\u003c"); break;
                default:
                    if (c < 0x20) sb.append(String.format(Locale.ROOT, "\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.append('"').toString();
    }

    /**
     * Отдаёт картинки проекта, а в режиме «весь сайт» — ещё и страницы, стили, скрипт.
     * Переходы наружу (почта, телефон, другие сайты) — в системные приложения.
     */
    static class Client extends WebViewClient {
        final MainActivity a;
        /** Сайт целиком: можно ходить по страницам. */
        final boolean live;
        /** Снимок сайта для режима «весь сайт» (чтобы фоновый поток не читал сайт, который сейчас правят). */
        volatile Site snapshot;
        volatile int width;
        Runnable onFinished;

        Client(MainActivity a, boolean live) {
            this.a = a;
            this.live = live;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (!HOST.equals(u.getHost())) return null;
            String path = u.getPath() == null ? "" : u.getPath();
            while (path.startsWith("/")) path = path.substring(1);
            try {
                path = java.net.URLDecoder.decode(path, "UTF-8");
            } catch (Exception ignored) {
            }
            Hub hub = a.hub;
            if (path.startsWith("img/") && !path.contains("..") && hub.site != null) {
                File f = new File(hub.dir(), path);
                if (f.isFile()) {
                    try {
                        WebResourceResponse r = new WebResourceResponse(mime(path), null, new FileInputStream(f));
                        Map<String, String> h = new HashMap<>();
                        h.put("Cache-Control", "no-cache");
                        r.setResponseHeaders(h);
                        return r;
                    } catch (IOException e) {
                        return notFound();
                    }
                }
                return notFound();
            }
            if (live && snapshot != null) {
                Site s = snapshot;
                if (path.equals("assets/site.css")) return text("text/css", Gen.css(s));
                if (path.equals("assets/site.js")) return text("application/javascript", Gen.js());
                Gen.Opt o = new Gen.Opt();
                o.width = width;
                if (path.isEmpty()) path = "index.html";
                for (Site.Page p : s.pages) if (s.file(p).equals(path)) return text("text/html", Gen.page(s, p, o));
                WebResourceResponse r = text("text/html", Gen.notFound(s, o));
                r.setStatusCodeAndReasonPhrase(404, "Not Found");
                return r;
            }
            return notFound();
        }

        private static WebResourceResponse text(String type, String body) {
            return new WebResourceResponse(type, "utf-8", new ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8)));
        }

        private static WebResourceResponse notFound() {
            WebResourceResponse r = new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            r.setStatusCodeAndReasonPhrase(404, "Not Found");
            return r;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            if (!req.isForMainFrame()) return false;
            Uri u = req.getUrl();
            String scheme = u.getScheme() == null ? "" : u.getScheme();
            if (HOST.equals(u.getHost())) return !live; // в редакторе никуда не уходим
            if (scheme.equals("mailto") || scheme.equals("tel") || scheme.equals("sms")) {
                a.openUrl(u.toString());
                return true;
            }
            if (live && (scheme.equals("http") || scheme.equals("https"))) {
                a.openUrl(u.toString());
                return true;
            }
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (onFinished != null) onFinished.run();
        }
    }

    static String mime(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".gif")) return "image/gif";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".ico")) return "image/x-icon";
        return "image/jpeg";
    }
}
