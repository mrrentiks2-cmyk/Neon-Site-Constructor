package com.neondrift.site;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Каталог блоков: какие бывают, какие у них поля и варианты, с каким текстом они появляются. */
final class Blocks {
    private Blocks() {}

    // виды полей
    static final String TEXT = "text", LONG = "long", IMAGE = "image", LINK = "link", CHOICE = "choice", BOOL = "bool", NUM = "num",
            ICON = "icon", ITEMS = "items", COLOR = "color";

    static final class Field {
        final String key, label, kind;
        String hint = "";
        String[] opts = {}, optNames = {};
        List<Field> sub;
        int min, max;
        /** Показывать только для этих вариантов блока (пусто — для всех). */
        String[] only = {};
        /** Показывать, только когда другое поле равно значению. */
        String depKey, depValue;

        Field(String key, String label, String kind) {
            this.key = key;
            this.label = label;
            this.kind = kind;
        }

        Field hint(String h) {
            hint = h;
            return this;
        }

        Field opts(String[] values, String[] names) {
            opts = values;
            optNames = names;
            return this;
        }

        Field range(int a, int b) {
            min = a;
            max = b;
            return this;
        }

        Field when(String... variants) {
            only = variants;
            return this;
        }

        Field dep(String key, String value) {
            depKey = key;
            depValue = value;
            return this;
        }

        /** Нужно ли это поле при текущем варианте и значениях. */
        boolean visible(String variant, Map<String, Object> values) {
            if (only.length > 0 && !Arrays.asList(only).contains(variant)) return false;
            if (depKey != null) {
                Object o = values.get(depKey);
                String v = o == null ? "" : String.valueOf(o);
                if (!v.equals(depValue)) return false;
            }
            return true;
        }
    }

    static final class Type {
        final String id, name, icon, desc;
        final String[] variants, variantNames;
        final List<Field> fields = new ArrayList<>();
        /** Шапка и подвал — общие для всех страниц. */
        boolean global;
        /** Название одного пункта списка («карточка», «фото», «вопрос»). */
        String itemName = "пункт";

        Type(String id, String name, String icon, String desc, String[] variants, String[] variantNames) {
            this.id = id;
            this.name = name;
            this.icon = icon;
            this.desc = desc;
            this.variants = variants;
            this.variantNames = variantNames;
        }

        Type add(Field... f) {
            fields.addAll(Arrays.asList(f));
            return this;
        }

        Field field(String key) {
            for (Field f : fields) if (f.key.equals(key)) return f;
            return null;
        }

        String variantName(String v) {
            for (int i = 0; i < variants.length; i++) if (variants[i].equals(v)) return variantNames[i];
            return variantNames.length > 0 ? variantNames[0] : "";
        }
    }

    static Field f(String key, String label, String kind) {
        return new Field(key, label, kind);
    }

    static Field items(String label, Field... sub) {
        Field f = new Field("items", label, ITEMS);
        f.sub = Arrays.asList(sub);
        return f;
    }

    static final String[] ALIGN = {"left", "center"}, ALIGN_NAMES = {"Слева", "По центру"};
    static final String[] COLS = {"2", "3", "4"}, COLS_NAMES = {"2 в ряд", "3 в ряд", "4 в ряд"};

    static final String[] ICONS = {"⚡", "🎯", "💎", "🚀", "🛠️", "📦", "🎨", "📸", "☕", "🍰", "🥐", "🏠", "🔧", "🚚", "💬", "⭐", "❤️", "✅", "🕒", "📍",
            "💡", "🔒", "🌿", "🎁", "🎵", "📚", "✈️", "🏆", "👥", "💳", "📞", "✉️", "🧩", "📈", "🛡️", "🌍", "🔥", "🍕", "🎓", "🧘"};

    static final List<Type> TYPES = new ArrayList<>();

    static {
        TYPES.add(new Type("header", "Шапка и меню", "menu", "Название, меню из страниц, кнопка",
                new String[]{"left", "center"}, new String[]{"Логотип слева", "Логотип по центру"}).add(
                f("logo", "Название или логотип текстом", TEXT),
                f("logoImage", "Логотип картинкой", IMAGE).hint("Если есть — показывается вместо текста"),
                f("autoMenu", "Меню из страниц сайта", BOOL),
                items("Свои пункты меню", f("text", "Текст", TEXT), f("link", "Ссылка", LINK)),
                f("button", "Кнопка справа", TEXT),
                f("buttonLink", "Ссылка кнопки", LINK),
                f("sticky", "Закреплять при прокрутке", BOOL),
                f("transparent", "Прозрачная поверх обложки", BOOL)));
        TYPES.get(0).global = true;
        TYPES.get(0).itemName = "пункт меню";

        TYPES.add(new Type("hero", "Обложка", "image", "Главный экран: большой заголовок, текст, кнопки",
                new String[]{"center", "split", "minimal", "full"}, new String[]{"По центру", "Текст и картинка", "Только текст", "Картинка на весь экран"}).add(
                f("eyebrow", "Надзаголовок", TEXT).hint("Маленькая строка над заголовком"),
                f("title", "Заголовок", TEXT),
                f("text", "Текст", LONG),
                f("button", "Кнопка", TEXT), f("buttonLink", "Ссылка кнопки", LINK),
                f("button2", "Вторая кнопка", TEXT), f("button2Link", "Ссылка второй кнопки", LINK),
                f("image", "Картинка", IMAGE).when("split", "full", "center").hint("Для «По центру» — фоном за текстом"),
                f("overlay", "Затемнение картинки, %", NUM).range(0, 90).when("full", "center"),
                f("height", "Высота", CHOICE).opts(new String[]{"auto", "tall", "screen"}, new String[]{"По содержимому", "Высокая", "Во весь экран"})));

        TYPES.add(new Type("text", "Текст", "text", "Заголовок и абзацы, списки, ссылки",
                new String[]{"normal", "two", "lead", "quote"}, new String[]{"Обычный", "Две колонки", "Крупный", "Цитата"}).add(
                f("title", "Заголовок", TEXT),
                f("text", "Текст", LONG).hint("**жирный**, *курсив*, [ссылка](https://…), строки с «- » — список"),
                f("author", "Автор цитаты", TEXT).when("quote"),
                f("align", "Выравнивание", CHOICE).opts(ALIGN, ALIGN_NAMES).when("normal", "two", "lead")));

        TYPES.add(new Type("imagetext", "Картинка и текст", "image", "Фото с одной стороны, текст с другой",
                new String[]{"left", "right"}, new String[]{"Картинка слева", "Картинка справа"}).add(
                f("image", "Картинка", IMAGE),
                f("eyebrow", "Надзаголовок", TEXT),
                f("title", "Заголовок", TEXT),
                f("text", "Текст", LONG),
                f("button", "Кнопка", TEXT), f("buttonLink", "Ссылка кнопки", LINK),
                f("shape", "Форма картинки", CHOICE).opts(new String[]{"rounded", "rect", "circle", "arch"}, new String[]{"Скруглённая", "Прямоугольная", "Круг", "Арка"})));

        TYPES.add(new Type("features", "Преимущества / услуги", "grid", "Карточки с иконкой, заголовком и текстом",
                new String[]{"cards", "plain", "numbered", "side"}, new String[]{"Карточки", "Без рамок", "С номерами (этапы)", "Иконка сбоку"}).add(
                f("title", "Заголовок", TEXT),
                f("text", "Подзаголовок", LONG),
                f("columns", "Колонки", CHOICE).opts(COLS, COLS_NAMES),
                items("Карточки", f("icon", "Значок", ICON), f("image", "Или картинка", IMAGE), f("title", "Заголовок", TEXT), f("text", "Текст", LONG),
                        f("link", "Ссылка (необязательно)", LINK))));
        TYPES.get(TYPES.size() - 1).itemName = "карточку";

        TYPES.add(new Type("gallery", "Галерея", "grid", "Фотографии сеткой, открываются на весь экран",
                new String[]{"grid", "masonry", "row"}, new String[]{"Ровная сетка", "Плитка разной высоты", "Лента с прокруткой"}).add(
                f("title", "Заголовок", TEXT),
                f("text", "Текст", LONG),
                f("columns", "Колонки", CHOICE).opts(COLS, COLS_NAMES),
                f("lightbox", "Открывать фото на весь экран", BOOL),
                items("Фотографии", f("image", "Фото", IMAGE), f("caption", "Подпись", TEXT))));
        TYPES.get(TYPES.size() - 1).itemName = "фото";

        TYPES.add(new Type("cta", "Призыв к действию", "send", "Короткий текст и заметная кнопка",
                new String[]{"band", "card"}, new String[]{"Полоса", "Карточка"}).add(
                f("title", "Заголовок", TEXT), f("text", "Текст", LONG),
                f("button", "Кнопка", TEXT), f("buttonLink", "Ссылка кнопки", LINK),
                f("button2", "Вторая кнопка", TEXT), f("button2Link", "Ссылка второй кнопки", LINK)));

        TYPES.add(new Type("pricing", "Цены", "chart", "Тарифы карточками или прайс-лист",
                new String[]{"cards", "list"}, new String[]{"Карточки тарифов", "Прайс-лист"}).add(
                f("title", "Заголовок", TEXT), f("text", "Подзаголовок", LONG),
                items("Тарифы / позиции", f("name", "Название", TEXT), f("price", "Цена", TEXT), f("period", "За что (мес., час, шт.)", TEXT),
                        f("text", "Что входит (каждое с новой строки)", LONG), f("button", "Кнопка", TEXT), f("link", "Ссылка кнопки", LINK),
                        f("featured", "Выделить", BOOL))));
        TYPES.get(TYPES.size() - 1).itemName = "позицию";

        TYPES.add(new Type("faq", "Вопросы и ответы", "info", "Раскрывающиеся вопросы",
                new String[]{"list", "split"}, new String[]{"Список", "Заголовок сбоку"}).add(
                f("title", "Заголовок", TEXT), f("text", "Текст", LONG),
                items("Вопросы", f("q", "Вопрос", TEXT), f("a", "Ответ", LONG))));
        TYPES.get(TYPES.size() - 1).itemName = "вопрос";

        TYPES.add(new Type("reviews", "Отзывы", "chat", "Отзывы клиентов с фото и оценкой",
                new String[]{"cards", "quote"}, new String[]{"Карточки", "Крупная цитата"}).add(
                f("title", "Заголовок", TEXT),
                items("Отзывы", f("text", "Текст отзыва", LONG), f("name", "Имя", TEXT), f("role", "Кто это (город, должность)", TEXT),
                        f("photo", "Фото", IMAGE), f("stars", "Звёзды (0–5)", NUM).range(0, 5))));
        TYPES.get(TYPES.size() - 1).itemName = "отзыв";

        TYPES.add(new Type("stats", "Цифры", "chart", "Факты в цифрах: годы, клиенты, проекты",
                new String[]{"plain", "cards"}, new String[]{"Крупные цифры", "В карточках"}).add(
                f("title", "Заголовок", TEXT),
                items("Цифры", f("num", "Число", TEXT), f("label", "Подпись", TEXT))));
        TYPES.get(TYPES.size() - 1).itemName = "цифру";

        TYPES.add(new Type("team", "Команда", "users", "Люди с фото, именем и ролью",
                new String[]{"cards", "round"}, new String[]{"Карточки", "Круглые фото"}).add(
                f("title", "Заголовок", TEXT), f("text", "Текст", LONG),
                f("columns", "Колонки", CHOICE).opts(COLS, COLS_NAMES),
                items("Люди", f("photo", "Фото", IMAGE), f("name", "Имя", TEXT), f("role", "Роль", TEXT), f("text", "О человеке", LONG))));
        TYPES.get(TYPES.size() - 1).itemName = "человека";

        TYPES.add(new Type("contacts", "Контакты", "phone", "Адрес, телефон, почта, мессенджеры, карта",
                new String[]{"cards", "split"}, new String[]{"Карточки", "С картой"}).add(
                f("title", "Заголовок", TEXT), f("text", "Текст", LONG),
                f("address", "Адрес", TEXT), f("phone", "Телефон", TEXT), f("email", "Почта", TEXT), f("hours", "Часы работы", TEXT),
                f("telegram", "Telegram (@имя или ссылка)", TEXT), f("whatsapp", "WhatsApp (номер)", TEXT), f("vk", "ВКонтакте (ссылка)", TEXT),
                f("map", "Показать карту", BOOL).when("split")));

        TYPES.add(new Type("form", "Форма заявки", "edit", "Имя, телефон, сообщение — заявка на почту",
                new String[]{"card", "split"}, new String[]{"Карточка", "Текст и форма"}).add(
                f("title", "Заголовок", TEXT), f("text", "Текст", LONG),
                f("fName", "Поле «Имя»", BOOL), f("fPhone", "Поле «Телефон»", BOOL), f("fEmail", "Поле «Почта»", BOOL), f("fMessage", "Поле «Сообщение»", BOOL),
                f("button", "Текст кнопки", TEXT),
                f("sendTo", "Куда отправлять", CHOICE).opts(new String[]{"email", "url"}, new String[]{"На почту (откроется почта)", "На свой адрес обработчика"}),
                f("email", "Почта для заявок", TEXT).dep("sendTo", "email"),
                f("action", "Адрес обработчика (Formspree и т. п.)", TEXT).dep("sendTo", "url").hint("Сюда уйдут данные формы методом POST"),
                f("success", "Сообщение после отправки", TEXT),
                f("consent", "Мелкий текст под кнопкой", TEXT)));

        TYPES.add(new Type("video", "Видео", "video", "YouTube, ВК Видео или Rutube по ссылке",
                new String[]{"wide", "split"}, new String[]{"Широкое", "Видео и текст"}).add(
                f("title", "Заголовок", TEXT), f("text", "Текст", LONG),
                f("url", "Ссылка на видео", TEXT).hint("youtube.com, youtu.be, vk.com/video…, rutube.ru/video/…")));

        TYPES.add(new Type("posts", "Записи блога", "list", "Список записей сайта с обложками",
                new String[]{"grid", "list"}, new String[]{"Карточки", "Списком"}).add(
                f("title", "Заголовок", TEXT), f("count", "Сколько показывать", NUM).range(1, 60), f("more", "Текст ссылки", TEXT)));

        TYPES.add(new Type("divider", "Отступ / линия", "minus", "Пустое место или разделительная линия",
                new String[]{"space", "line", "dots"}, new String[]{"Пустое место", "Линия", "Точки"}).add(
                f("size", "Размер", CHOICE).opts(new String[]{"s", "m", "l"}, new String[]{"Маленький", "Средний", "Большой"})));

        TYPES.add(new Type("html", "Свой код", "code", "HTML-код: виджеты, счётчики, встраивания",
                new String[]{"normal"}, new String[]{"Код"}).add(
                f("code", "HTML-код", LONG).hint("Выполняется только на готовом сайте")));

        TYPES.add(new Type("footer", "Подвал", "collapse", "Низ сайта: о компании, меню, контакты",
                new String[]{"columns", "simple"}, new String[]{"Колонки", "Одной строкой"}).add(
                f("logo", "Название", TEXT), f("text", "Пара слов о вас", LONG), f("autoMenu", "Меню из страниц", BOOL),
                f("phone", "Телефон", TEXT), f("email", "Почта", TEXT),
                f("telegram", "Telegram", TEXT), f("whatsapp", "WhatsApp", TEXT), f("vk", "ВКонтакте", TEXT), f("youtube", "YouTube", TEXT),
                f("copyright", "Копирайт", TEXT), f("small", "Мелкий текст (реквизиты, политика)", LONG)));
        TYPES.get(TYPES.size() - 1).global = true;
    }

    static Type type(String id) {
        for (Type t : TYPES) if (t.id.equals(id)) return t;
        return TYPES.get(2); // текст
    }

    /** Блоки для каталога «Добавить блок» (без шапки и подвала — они общие). */
    static List<Type> addable() {
        List<Type> l = new ArrayList<>();
        for (Type t : TYPES) if (!t.global) l.add(t);
        return l;
    }

    // ================================================================== начальное содержимое

    static Map<String, Object> item(Object... kv) {
        LinkedHashMap<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) m.put((String) kv[i], kv[i + 1]);
        return m;
    }

    /** Новый блок с понятным примером текста — сразу выглядит как надо, остаётся поменять слова. */
    static Site.Block make(String type, String variant) {
        Type t = type(type);
        Site.Block b = new Site.Block(t.id, variant == null || variant.isEmpty() ? t.variants[0] : variant);
        LinkedHashMap<String, Object> v = b.v;
        switch (t.id) {
            case "header":
                v.put("logo", "Название");
                v.put("autoMenu", true);
                v.put("button", "Связаться");
                v.put("buttonLink", "#contacts");
                v.put("sticky", true);
                v.put("transparent", false);
                v.put("items", new ArrayList<>());
                break;
            case "hero":
                v.put("eyebrow", "Добро пожаловать");
                v.put("title", "Крупный заголовок о главном");
                v.put("text", "Одно-два предложения: чем вы занимаетесь и почему стоит выбрать вас.");
                v.put("button", "Оставить заявку");
                v.put("buttonLink", "#contacts");
                v.put("button2", "Подробнее");
                v.put("button2Link", "#about");
                v.put("image", "");
                v.put("overlay", 45L);
                v.put("height", b.variant.equals("full") ? "screen" : "tall");
                break;
            case "text":
                v.put("title", b.variant.equals("quote") ? "" : "О нас");
                v.put("text", b.variant.equals("quote") ? "Делайте то, что любите, и делайте это хорошо — остальное приложится."
                        : "Расскажите о себе: как всё начиналось, что для вас важно и что получает человек, который к вам обратился.\n\nВторой абзац — подробности, факты, *немного личного*. Хорошо работают короткие абзацы и списки:\n- первое преимущество\n- второе преимущество\n- третье преимущество");
                v.put("author", b.variant.equals("quote") ? "Имя Фамилия" : "");
                v.put("align", b.variant.equals("quote") || b.variant.equals("lead") ? "center" : "left");
                break;
            case "imagetext":
                v.put("image", "");
                v.put("eyebrow", "О нас");
                v.put("title", "Заголовок рядом с картинкой");
                v.put("text", "Расскажите подробнее: что вы делаете, для кого и почему у вас получается хорошо. Пара абзацев — в самый раз.");
                v.put("button", "Подробнее");
                v.put("buttonLink", "#contacts");
                v.put("shape", "rounded");
                break;
            case "features":
                v.put("title", b.variant.equals("numbered") ? "Как мы работаем" : "Почему выбирают нас");
                v.put("text", "Коротко о главном — в трёх пунктах.");
                v.put("columns", "3");
                List<Object> fl = new ArrayList<>();
                if (b.variant.equals("numbered")) {
                    fl.add(item("icon", "", "image", "", "title", "Заявка", "text", "Вы оставляете заявку на сайте или звоните.", "link", ""));
                    fl.add(item("icon", "", "image", "", "title", "Обсуждение", "text", "Уточняем задачу, сроки и стоимость.", "link", ""));
                    fl.add(item("icon", "", "image", "", "title", "Результат", "text", "Делаем работу и сдаём в срок.", "link", ""));
                } else {
                    fl.add(item("icon", "⚡", "image", "", "title", "Быстро", "text", "Делаем в срок и держим в курсе на каждом этапе.", "link", ""));
                    fl.add(item("icon", "💎", "image", "", "title", "Качественно", "text", "Отвечаем за результат и даём гарантию.", "link", ""));
                    fl.add(item("icon", "💬", "image", "", "title", "На связи", "text", "Отвечаем на вопросы быстро и понятно.", "link", ""));
                }
                v.put("items", fl);
                break;
            case "gallery":
                v.put("title", "Галерея");
                v.put("text", "");
                v.put("columns", "3");
                v.put("lightbox", true);
                List<Object> gl = new ArrayList<>();
                for (int i = 0; i < 6; i++) gl.add(item("image", "", "caption", ""));
                v.put("items", gl);
                break;
            case "cta":
                v.put("title", "Готовы начать?");
                v.put("text", "Оставьте заявку — ответим в течение часа и всё расскажем.");
                v.put("button", "Оставить заявку");
                v.put("buttonLink", "#contacts");
                v.put("button2", "");
                v.put("button2Link", "");
                break;
            case "pricing":
                v.put("title", "Цены");
                v.put("text", "Без скрытых платежей.");
                List<Object> pl = new ArrayList<>();
                if (b.variant.equals("list")) {
                    pl.add(item("name", "Консультация", "price", "1 500 ₽", "period", "час", "text", "", "button", "", "link", "", "featured", false));
                    pl.add(item("name", "Базовая услуга", "price", "от 5 000 ₽", "period", "", "text", "", "button", "", "link", "", "featured", false));
                    pl.add(item("name", "Комплексная услуга", "price", "от 15 000 ₽", "period", "", "text", "", "button", "", "link", "", "featured", false));
                } else {
                    pl.add(item("name", "Старт", "price", "3 000 ₽", "period", "мес.", "text", "Основное\nПоддержка в рабочее время", "button", "Выбрать", "link", "#contacts", "featured", false));
                    pl.add(item("name", "Оптимальный", "price", "6 000 ₽", "period", "мес.", "text", "Всё из «Старта»\nПриоритетная поддержка\nЕжемесячный отчёт", "button", "Выбрать", "link", "#contacts", "featured", true));
                    pl.add(item("name", "Максимум", "price", "12 000 ₽", "period", "мес.", "text", "Всё из «Оптимального»\nЛичный менеджер\nВыезд специалиста", "button", "Выбрать", "link", "#contacts", "featured", false));
                }
                v.put("items", pl);
                break;
            case "faq":
                v.put("title", "Частые вопросы");
                v.put("text", "");
                List<Object> ql = new ArrayList<>();
                ql.add(item("q", "Сколько это стоит?", "a", "Стоимость зависит от задачи — назовём точную цену после короткого разговора."));
                ql.add(item("q", "Сколько времени займёт?", "a", "Обычно от нескольких дней до пары недель. Сроки фиксируем заранее."));
                ql.add(item("q", "Как с вами связаться?", "a", "Оставьте заявку на сайте или напишите в мессенджер — ответим быстро."));
                v.put("items", ql);
                break;
            case "reviews":
                v.put("title", "Отзывы");
                List<Object> rl = new ArrayList<>();
                rl.add(item("text", "Всё сделали быстро и аккуратно. Обязательно обращусь ещё!", "name", "Анна", "role", "клиент", "photo", "", "stars", 5L));
                rl.add(item("text", "Понятные цены, вежливое общение и отличный результат.", "name", "Сергей", "role", "клиент", "photo", "", "stars", 5L));
                rl.add(item("text", "Рекомендую друзьям — ни разу не подвели.", "name", "Мария", "role", "клиент", "photo", "", "stars", 5L));
                v.put("items", rl);
                break;
            case "stats":
                v.put("title", "");
                List<Object> sl = new ArrayList<>();
                sl.add(item("num", "10+", "label", "лет опыта"));
                sl.add(item("num", "500", "label", "довольных клиентов"));
                sl.add(item("num", "24/7", "label", "на связи"));
                v.put("items", sl);
                break;
            case "team":
                v.put("title", "Команда");
                v.put("text", "");
                v.put("columns", "3");
                List<Object> tl = new ArrayList<>();
                tl.add(item("photo", "", "name", "Имя Фамилия", "role", "Основатель", "text", ""));
                tl.add(item("photo", "", "name", "Имя Фамилия", "role", "Мастер", "text", ""));
                tl.add(item("photo", "", "name", "Имя Фамилия", "role", "Менеджер", "text", ""));
                v.put("items", tl);
                break;
            case "contacts":
                v.put("title", "Контакты");
                v.put("text", "Приходите в гости или напишите нам.");
                v.put("address", "г. Город, ул. Улица, 1");
                v.put("phone", "+7 900 000-00-00");
                v.put("email", "hello@example.com");
                v.put("hours", "Ежедневно 10:00–20:00");
                v.put("telegram", "");
                v.put("whatsapp", "");
                v.put("vk", "");
                v.put("map", b.variant.equals("split"));
                b.anchor = "contacts";
                break;
            case "form":
                v.put("title", "Оставьте заявку");
                v.put("text", "Перезвоним в течение 15 минут в рабочее время.");
                v.put("fName", true);
                v.put("fPhone", true);
                v.put("fEmail", false);
                v.put("fMessage", true);
                v.put("button", "Отправить");
                v.put("sendTo", "email");
                v.put("email", "hello@example.com");
                v.put("action", "");
                v.put("success", "Спасибо! Мы скоро свяжемся с вами.");
                v.put("consent", "Нажимая кнопку, вы соглашаетесь на обработку персональных данных.");
                b.anchor = "form";
                break;
            case "video":
                v.put("title", "Видео");
                v.put("text", "");
                v.put("url", "");
                break;
            case "posts":
                v.put("title", "Последние записи");
                v.put("count", 6L);
                v.put("more", "Читать");
                break;
            case "divider":
                v.put("size", "m");
                b.pad = "none";
                break;
            case "html":
                v.put("code", "<p style=\"text-align:center\">Здесь будет ваш код</p>");
                break;
            case "footer":
                v.put("logo", "Название");
                v.put("text", "Пара слов о том, чем вы занимаетесь.");
                v.put("autoMenu", true);
                v.put("phone", "+7 900 000-00-00");
                v.put("email", "hello@example.com");
                v.put("telegram", "");
                v.put("whatsapp", "");
                v.put("vk", "");
                v.put("youtube", "");
                v.put("copyright", "© " + java.util.Calendar.getInstance().get(java.util.Calendar.YEAR) + " Название");
                v.put("small", "");
                b.bg = "surface";
                b.pad = "m";
                break;
            default:
                break;
        }
        return b;
    }

    /** Пустой пункт для «Добавить» в списке. */
    static Map<String, Object> newItem(String type) {
        switch (type) {
            case "header": return item("text", "Пункт", "link", "#");
            case "features": return item("icon", "✅", "image", "", "title", "Заголовок", "text", "Короткое описание.", "link", "");
            case "gallery": return item("image", "", "caption", "");
            case "pricing": return item("name", "Название", "price", "1 000 ₽", "period", "", "text", "", "button", "Выбрать", "link", "#contacts", "featured", false);
            case "faq": return item("q", "Вопрос?", "a", "Ответ.");
            case "reviews": return item("text", "Текст отзыва.", "name", "Имя", "role", "", "photo", "", "stars", 5L);
            case "stats": return item("num", "100", "label", "подпись");
            case "team": return item("photo", "", "name", "Имя Фамилия", "role", "Роль", "text", "");
            default: return item("title", "Пункт", "text", "");
        }
    }
}
