package com.neondrift.site;

import android.webkit.WebChromeClient;
import android.webkit.WebView;

/** Сайт целиком, как его увидят посетители: переходы по страницам, меню, анимации, галерея. */
final class PreviewScreen extends Screen {
    private WebView web;
    private Web.Client client;
    private int device;

    PreviewScreen(MainActivity a, Site.Page start) {
        super(a);
        Site snap = hub.site.copy();
        device = hub.prefs.device();
        android.widget.LinearLayout h = header("Как увидят посетители", snap.file(start));
        h.addView(ui.iconButton(device == 1 ? "desktop" : "phone", Theme.TEXT, 42, 11, v -> {
            device = 1 - device;
            client.width = device == 1 ? 1280 : 0;
            ((android.widget.ImageView) v).setImageDrawable(new Glyph(device == 1 ? "desktop" : "phone", Theme.TEXT));
            web.reload();
        }));
        h.addView(ui.iconButton("refresh", Theme.TEXT, 42, 11, v -> web.reload()));
        web = Web.make(a, null);
        client = new Web.Client(a, true);
        client.snapshot = snap;
        client.width = device == 1 ? 1280 : 0;
        client.onFinished = () -> {
            String u = web.getUrl();
            if (u != null && u.startsWith(Web.BASE)) setSub(u.substring(Web.BASE.length()).isEmpty() ? "index.html" : u.substring(Web.BASE.length()));
        };
        web.setWebViewClient(client);
        web.setWebChromeClient(new WebChromeClient());
        addView(web, Ui.lp(Ui.MATCH, 0, 1f));
        web.loadUrl(Web.BASE + snap.file(start));
    }

    @Override
    boolean back() {
        if (web.canGoBack()) {
            web.goBack();
            return true;
        }
        return false;
    }

    @Override
    void onRemoved() {
        web.destroy();
    }
}
