package com.neondrift.site;

import android.webkit.WebView;

/** «Новый сайт»: галерея шаблонов (настоящие уменьшенные страницы), выбор — и сразу в редактор. */
final class TemplatesScreen extends Screen implements Web.Bridge {
    private final WebView web;
    private boolean busy;

    TemplatesScreen(MainActivity a) {
        super(a);
        header("Новый сайт", "Выберите основу — всё можно поменять");
        web = Web.make(a, this);
        web.setWebViewClient(new Web.Client(a, false));
        web.getSettings().setBuiltInZoomControls(false);
        web.getSettings().setSupportZoom(false);
        addView(web, Ui.lp(Ui.MATCH, 0, 1f));
        web.loadDataWithBaseURL(Web.BASE, Gen.templates(), "text/html", "utf-8", null);
    }

    @Override
    public void template(String id) {
        if (busy) return;
        int k = 0;
        for (int i = 0; i < Templates.IDS.length; i++) if (Templates.IDS[i].equals(id)) k = i;
        Site s = Templates.make(id);
        String def = id.equals("blank") ? "Мой сайт" : s.name;
        a.ask("Как назовём сайт?", "Название (можно поменять потом)", def, "Создать", name -> {
            busy = true;
            s.name = name;
            if (s.header != null && (s.header.s("logo").equals(def) || s.header.s("logo").equals("Название"))) s.header.v.put("logo", name);
            if (s.footer != null && (s.footer.s("logo").equals(def) || s.footer.s("logo").equals("Название"))) s.footer.v.put("logo", name);
            if (s.footer != null) s.footer.v.put("copyright", s.footer.s("copyright").replace(def, name));
            s.created = s.updated = System.currentTimeMillis();
            try {
                hub.store.save(s);
                hub.open(s);
                a.replace(new EditorScreen(a));
            } catch (Exception e) {
                busy = false;
                a.toast("Не получилось создать: " + e.getMessage());
            }
        });
        a.panel.note(a.panelContent(), "Шаблон: " + Templates.NAMES[k] + ". " + Templates.DESCS[k] + ".");
    }

    @Override
    public void select(String blockId) {
    }

    @Override
    public void add(String type, String variant) {
    }

    @Override
    void onRemoved() {
        web.destroy();
    }
}
