package com.neondrift.site;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Генератор сайта: из проекта — готовые HTML-страницы, общий CSS и небольшой JS.
 * Тот же код рисует предпросмотр в редакторе (с выбором блока касанием), поэтому что видите — то и получите.
 */
final class Gen {
    private Gen() {}

    static final class Opt {
        /** Режим редактора: блоки выбираются касанием, ссылки не уводят, без анимаций. */
        boolean preview;
        String selected = "";
        /** Ширина «экрана» в предпросмотре (0 — как у устройства; 1280 — компьютер). */
        int width;
        /** Только один блок (экран редактирования блока). */
        String only;
        /** Стили и скрипт внутрь страницы (для предпросмотра) или отдельными файлами (готовый сайт). */
        boolean inline;
    }

    static Opt preview(String selected, int width) {
        Opt o = new Opt();
        o.preview = true;
        o.inline = true;
        o.selected = selected == null ? "" : selected;
        o.width = width;
        return o;
    }

    // ================================================================== сайт целиком

    /** Все текстовые файлы готового сайта: путь → содержимое. Картинки (img/…) копирует экспорт. */
    static Map<String, String> site(Site s) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        Opt o = new Opt();
        for (Site.Page p : s.pages) out.put(s.file(p), page(s, p, o));
        out.put("404.html", notFound(s, o));
        out.put("assets/site.css", css(s));
        out.put("assets/site.js", js());
        String dom = domain(s);
        StringBuilder robots = new StringBuilder("User-agent: *\nAllow: /\n");
        if (!dom.isEmpty()) {
            robots.append("Sitemap: ").append(dom).append("/sitemap.xml\n");
            StringBuilder sm = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n");
            for (Site.Page p : s.pages) {
                String f = s.file(p);
                sm.append("  <url><loc>").append(esc(dom + "/" + (f.equals("index.html") ? "" : f))).append("</loc></url>\n");
            }
            sm.append("</urlset>\n");
            out.put("sitemap.xml", sm.toString());
        }
        out.put("robots.txt", robots.toString());
        return out;
    }

    static String domain(Site s) {
        String d = s.domain == null ? "" : s.domain.trim();
        if (d.isEmpty()) return "";
        if (!d.startsWith("http")) d = "https://" + d;
        return d.replaceAll("/+$", "");
    }

    // ================================================================== страница

    /** Страница, которую сейчас собираем: нужна, чтобы «#якорь» с другой страницы вёл туда, где этот якорь есть. */
    private static final ThreadLocal<Site.Page> CUR = new ThreadLocal<>();

    static String page(Site s, Site.Page p, Opt o) {
        Site.Page prev = CUR.get();
        CUR.set(p);
        try {
            return pageImpl(s, p, o);
        } finally {
            CUR.set(prev);
        }
    }

    private static String pageImpl(Site s, Site.Page p, Opt o) {
        Themes.Fonts f = Themes.fonts(s.look.fonts);
        StringBuilder sb = new StringBuilder(32 * 1024);
        String title = p == s.home() ? (p.seoTitle.isEmpty() ? s.name : p.seoTitle)
                : (p.seoTitle.isEmpty() ? p.title + " — " + s.name : p.seoTitle);
        String desc = !p.seoDescription.isEmpty() ? p.seoDescription : p.post() && !p.excerpt.isEmpty() ? p.excerpt : s.description;
        sb.append("<!DOCTYPE html>\n<html lang=\"").append(esc(s.lang.isEmpty() ? "ru" : s.lang)).append("\" class=\"no-js\"").append(o.preview && !o.selected.isEmpty() ? " data-sel=\"" + esc(o.selected) + "\"" : "").append(">\n<head>\n<meta charset=\"utf-8\">\n");
        sb.append("<meta name=\"viewport\" content=\"").append(o.width > 0 ? "width=" + o.width : "width=device-width, initial-scale=1").append("\">\n");
        sb.append("<title>").append(esc(title)).append("</title>\n");
        if (!desc.isEmpty()) sb.append("<meta name=\"description\" content=\"").append(esc(desc)).append("\">\n");
        sb.append("<meta property=\"og:title\" content=\"").append(esc(title)).append("\">\n");
        if (!desc.isEmpty()) sb.append("<meta property=\"og:description\" content=\"").append(esc(desc)).append("\">\n");
        String og = !p.cover.isEmpty() ? p.cover : s.ogImage;
        if (!og.isEmpty()) {
            String dom = domain(s);
            sb.append("<meta property=\"og:image\" content=\"").append(esc(dom.isEmpty() ? og : dom + "/" + og)).append("\">\n");
        }
        sb.append("<meta name=\"theme-color\" content=\"").append(esc(s.look.bg)).append("\">\n");
        if (!s.favicon.isEmpty()) sb.append("<link rel=\"icon\" href=\"").append(esc(s.favicon)).append("\">\n");
        if (!f.google.isEmpty()) {
            sb.append("<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\"><link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\n");
            sb.append("<link rel=\"stylesheet\" data-fonts href=\"https://fonts.googleapis.com/css2?").append(esc(f.google)).append("&amp;display=swap\">\n");
        }
        sb.append("<script>document.documentElement.className='js'</script>\n");
        if (o.inline) sb.append("<style>\n").append(css(s)).append(o.preview ? EDIT_CSS : "").append("</style>\n");
        else sb.append("<link rel=\"stylesheet\" href=\"assets/site.css\">\n");
        if (!o.preview && !s.headCode.trim().isEmpty()) sb.append(s.headCode).append('\n');
        sb.append("</head>\n<body class=\"").append(o.preview ? "edit" : "").append("\">\n");

        if (o.only != null) {
            Site.Block b = s.block(o.only);
            if (b != null) block(sb, s, p, b, o, false);
        } else {
            boolean overHero = false;
            if (!p.noHeader && s.header != null && !s.header.hidden) {
                Site.Block first = firstVisible(p);
                overHero = s.header.b("transparent") && !p.post() && first != null;
                header(sb, s, p, s.header, o, overHero && darkBlock(s, first));
            }
            sb.append("<main id=\"main\">\n");
            if (p.post()) postHead(sb, s, p, o);
            for (Site.Block b : p.blocks) {
                if (b.hidden && !o.preview) continue;
                block(sb, s, p, b, o, overHero && b == firstVisible(p));
            }
            if (p.blocks.isEmpty() && o.preview) {
                sb.append("<section class=\"sec empty-page\"><div class=\"container\"><p>Пустая страница — добавьте блок кнопкой «+».</p></div></section>\n");
            }
            sb.append("</main>\n");
            if (!p.noFooter && s.footer != null && !s.footer.hidden) footer(sb, s, p, s.footer, o);
        }
        if (o.inline && o.preview) sb.append("<script>\nwindow.neonSiteInit=function(){\n").append(js()).append("};neonSiteInit();\n").append(EDIT_JS).append("</script>\n");
        else if (o.inline) sb.append("<script>\n").append(js()).append("</script>\n");
        else sb.append("<script src=\"assets/site.js\" defer></script>\n");
        if (o.preview && !o.selected.isEmpty()) sb.append("<script>neonSelect('").append(esc(o.selected)).append("',false)</script>\n");
        sb.append("</body>\n</html>\n");
        return sb.toString();
    }

    private static Site.Block firstVisible(Site.Page p) {
        for (Site.Block b : p.blocks) if (!b.hidden) return b;
        return null;
    }

    /** Тёмный ли блок (для прозрачной шапки поверх него — светлый текст). */
    static boolean darkBlock(Site s, Site.Block b) {
        if (b == null) return false;
        if (b.bg.equals("image") || b.bg.equals("dark") || b.bg.equals("primary")) return true;
        if (b.bg.equals("color")) return luma(b.bgColor) < 0.5;
        if (b.type.equals("hero") && (b.variant.equals("full") || b.variant.equals("center") && !b.s("image").isEmpty())) return true;
        return s.look.dark && (b.bg.equals("auto") || b.bg.equals("bg") || b.bg.equals("surface"));
    }

    static String notFound(Site s, Opt o) {
        Site.Page p = new Site.Page();
        p.title = "Страница не найдена";
        p.menu = false;
        Site.Block b = Blocks.make("hero", "minimal");
        b.v.put("eyebrow", "Ошибка 404");
        b.v.put("title", "Такой страницы нет");
        b.v.put("text", "Возможно, её удалили или в адресе опечатка.");
        b.v.put("button", "На главную");
        b.v.put("buttonLink", "index.html");
        b.v.put("button2", "");
        b.v.put("height", "tall");
        p.blocks.add(b);
        return page(s, p, o);
    }

    // ================================================================== блоки

    private static void block(StringBuilder sb, Site s, Site.Page p, Site.Block b, Opt o, boolean underHeader) {
        String cls = "sec t-" + b.type + " v-" + (b.variant.isEmpty() ? "default" : b.variant) + " pad-" + b.pad + bgClass(b);
        if (b.show.equals("mobile")) cls += " only-mobile";
        else if (b.show.equals("desktop")) cls += " only-desktop";
        if (underHeader) cls += " under-hdr";
        if (b.hidden) cls += " is-hidden";
        sb.append("<section class=\"").append(cls).append("\"");
        if (!b.anchor.isEmpty()) sb.append(" id=\"").append(esc(b.anchor)).append("\"");
        if (o.preview) sb.append(" data-block=\"").append(b.id).append("\"");
        String bgStyle = bgStyle(b);
        if (!bgStyle.isEmpty()) sb.append(" style=\"").append(esc(bgStyle)).append("\"");
        sb.append(">\n");
        if (o.preview && b.hidden) sb.append("<div class=\"edit-badge\">Скрыт на сайте</div>");
        switch (b.type) {
            case "header": headerInner(sb, s, p, b, o); break;
            case "hero": hero(sb, s, b, o); break;
            case "text": text(sb, s, b, o); break;
            case "imagetext": imageText(sb, s, b, o); break;
            case "features": features(sb, s, b, o); break;
            case "gallery": gallery(sb, s, b, o); break;
            case "cta": cta(sb, s, b, o); break;
            case "pricing": pricing(sb, s, b, o); break;
            case "faq": faq(sb, s, b, o); break;
            case "reviews": reviews(sb, s, b, o); break;
            case "stats": stats(sb, s, b, o); break;
            case "team": team(sb, s, b, o); break;
            case "contacts": contacts(sb, s, b, o); break;
            case "form": form(sb, s, b, o); break;
            case "video": video(sb, s, b, o); break;
            case "posts": posts(sb, s, p, b, o); break;
            case "divider": divider(sb, b); break;
            case "html": html(sb, b, o); break;
            case "footer": footerInner(sb, s, p, b, o); break;
            default: break;
        }
        sb.append("</section>\n");
    }

    private static String bgClass(Site.Block b) {
        switch (b.bg) {
            case "surface": return " bg-surface";
            case "primary": return " bg-primary";
            case "accent": return " bg-accent";
            case "dark": return " bg-dark";
            case "light": return " bg-light";
            case "color": return luma(b.bgColor) < 0.5 ? " bg-custom on-dark" : " bg-custom";
            case "image": return " bg-image on-dark";
            case "bg": return " bg-page";
            default: return "";
        }
    }

    private static String bgStyle(Site.Block b) {
        if (b.bg.equals("color") && !b.bgColor.isEmpty()) return "background:" + b.bgColor;
        if (b.bg.equals("image") && !b.bgImage.isEmpty()) return "background-image:url('" + b.bgImage.replace("'", "%27") + "')";
        return "";
    }

    // ------------------------------------------------------------------ шапка

    private static void header(StringBuilder sb, Site s, Site.Page p, Site.Block b, Opt o, boolean light) {
        String cls = "hdr v-" + b.variant + (b.b("sticky") ? " sticky" : "") + (b.b("transparent") ? " over" : "") + (light ? " light" : "");
        sb.append("<header class=\"").append(cls).append("\"");
        if (o.preview) sb.append(" data-block=\"").append(b.id).append("\"");
        sb.append(">\n");
        headerInner(sb, s, p, b, o);
        sb.append("</header>\n");
    }

    private static void headerInner(StringBuilder sb, Site s, Site.Page p, Site.Block b, Opt o) {
        sb.append("<div class=\"container hdr-in\">");
        sb.append("<a class=\"logo\" href=\"").append(esc(s.file(s.home()) == null ? "index.html" : "index.html")).append("\">");
        if (!b.s("logoImage").isEmpty()) sb.append("<img src=\"").append(esc(b.s("logoImage"))).append("\" alt=\"").append(esc(b.s("logo"))).append("\">");
        else sb.append(esc(b.s("logo").isEmpty() ? s.name : b.s("logo")));
        sb.append("</a>");
        StringBuilder nav = new StringBuilder();
        if (b.b("autoMenu") && menuPages(s) > 1) {
            for (Site.Page q : s.pages) {
                if (!q.menu || q.post()) continue;
                nav.append("<a href=\"").append(esc(s.file(q))).append("\"").append(q == p ? " class=\"cur\" aria-current=\"page\"" : "").append(">")
                        .append(esc(q.title)).append("</a>");
            }
        }
        for (Map<String, Object> it : b.items()) {
            String t = str(it, "text");
            if (t.isEmpty()) continue;
            nav.append("<a href=\"").append(esc(href(s, str(it, "link")))).append("\"").append(target(str(it, "link"))).append(">").append(esc(t)).append("</a>");
        }
        boolean hasNav = nav.length() > 0;
        boolean hasBtn = !b.s("button").isEmpty();
        if (hasNav || hasBtn) {
            sb.append("<nav class=\"nav\" id=\"nav\">").append(nav);
            if (hasBtn) sb.append(btn(s, b.s("button"), b.s("buttonLink"), "btn btn-1 btn-sm nav-btn"));
            sb.append("</nav>");
            sb.append("<button class=\"burger\" aria-label=\"Меню\" aria-expanded=\"false\" aria-controls=\"nav\"><span></span><span></span><span></span></button>");
        }
        sb.append("</div>\n");
    }

    // ------------------------------------------------------------------ обложка

    private static void hero(StringBuilder sb, Site s, Site.Block b, Opt o) {
        String img = b.s("image");
        String h = b.s("height");
        String v = b.variant;
        boolean imageBg = v.equals("full") || v.equals("center") && !img.isEmpty();
        StringBuilder text = new StringBuilder();
        if (!b.s("eyebrow").isEmpty()) text.append("<div class=\"eyebrow\">").append(esc(b.s("eyebrow"))).append("</div>");
        text.append("<h1>").append(inline(b.s("title"))).append("</h1>");
        if (!b.s("text").isEmpty()) text.append("<div class=\"lead\">").append(md(s, b.s("text"))).append("</div>");
        text.append(buttons(s, b));
        if (imageBg) {
            int ov = Math.max(0, Math.min(90, b.n("overlay", 45)));
            sb.append("<div class=\"hero-bg").append(img.isEmpty() ? " glow" : "").append("\"");
            if (!img.isEmpty()) sb.append(" style=\"background-image:url('").append(esc(img.replace("'", "%27"))).append("')\"");
            sb.append("></div><div class=\"hero-shade\" style=\"opacity:").append(img.isEmpty() ? 0 : ov / 100f).append("\"></div>");
            sb.append("<div class=\"container hero-in h-").append(esc(h)).append(v.equals("full") ? " bottom" : " center").append("\"><div class=\"hero-text reveal\">")
                    .append(text).append("</div></div>\n");
            return;
        }
        if (v.equals("split")) {
            sb.append("<div class=\"container hero-in h-").append(esc(h)).append("\"><div class=\"split\"><div class=\"hero-text reveal\">").append(text).append("</div>");
            sb.append("<div class=\"hero-img reveal\">").append(picture(s, img, "hero", o, "4/5")).append("</div></div></div>\n");
            return;
        }
        if (v.equals("center")) {
            sb.append("<div class=\"blob b1\"></div><div class=\"blob b2\"></div>");
            sb.append("<div class=\"container hero-in center h-").append(esc(h)).append("\"><div class=\"hero-text reveal\">").append(text).append("</div></div>\n");
            return;
        }
        // minimal
        sb.append("<div class=\"container hero-in h-").append(esc(h)).append("\"><div class=\"hero-text big reveal\">").append(text).append("</div></div>\n");
    }

    private static String buttons(Site s, Site.Block b) {
        StringBuilder sb = new StringBuilder();
        if (!b.s("button").isEmpty()) sb.append(btn(s, b.s("button"), b.s("buttonLink"), "btn btn-1"));
        if (!b.s("button2").isEmpty()) sb.append(btn(s, b.s("button2"), b.s("button2Link"), "btn btn-2"));
        return sb.length() == 0 ? "" : "<div class=\"btns\">" + sb + "</div>";
    }

    private static String btn(Site s, String text, String link, String cls) {
        return "<a class=\"" + cls + "\" href=\"" + esc(href(s, link)) + "\"" + target(link) + ">" + esc(text) + "</a>";
    }

    // ------------------------------------------------------------------ текст

    private static void text(StringBuilder sb, Site s, Site.Block b, Opt o) {
        String align = b.s("align").equals("center") ? " center" : "";
        sb.append("<div class=\"container\"><div class=\"prose reveal").append(align).append(" tv-").append(esc(b.variant)).append("\">");
        if (b.variant.equals("quote")) {
            sb.append("<blockquote><div class=\"qmark\">“</div>").append(md(s, b.s("text")));
            if (!b.s("author").isEmpty()) sb.append("<cite>— ").append(esc(b.s("author"))).append("</cite>");
            sb.append("</blockquote>");
        } else {
            if (!b.s("title").isEmpty()) sb.append("<h2>").append(inline(b.s("title"))).append("</h2>");
            sb.append("<div class=\"body\">").append(md(s, b.s("text"))).append("</div>");
        }
        sb.append("</div></div>\n");
    }

    private static void imageText(StringBuilder sb, Site s, Site.Block b, Opt o) {
        String shape = b.s("shape").isEmpty() ? "rounded" : b.s("shape");
        sb.append("<div class=\"container\"><div class=\"split it-").append(b.variant.equals("right") ? "right" : "left").append("\">");
        sb.append("<div class=\"it-img reveal shape-").append(esc(shape)).append("\">")
                .append(picture(s, b.s("image"), "", o, shape.equals("circle") ? "1/1" : shape.equals("arch") ? "4/5" : "4/3")).append("</div>");
        sb.append("<div class=\"it-text reveal\">");
        if (!b.s("eyebrow").isEmpty()) sb.append("<div class=\"eyebrow\">").append(esc(b.s("eyebrow"))).append("</div>");
        if (!b.s("title").isEmpty()) sb.append("<h2>").append(inline(b.s("title"))).append("</h2>");
        sb.append("<div class=\"body\">").append(md(s, b.s("text"))).append("</div>");
        sb.append(buttons(s, b));
        sb.append("</div></div></div>\n");
    }

    private static void head(StringBuilder sb, Site s, Site.Block b, boolean left) {
        if (b.s("title").isEmpty() && b.s("text").isEmpty()) return;
        sb.append("<div class=\"sec-head reveal").append(left ? " left" : "").append("\">");
        if (!b.s("title").isEmpty()) sb.append("<h2>").append(inline(b.s("title"))).append("</h2>");
        if (!b.s("text").isEmpty()) sb.append("<div class=\"lead\">").append(md(s, b.s("text"))).append("</div>");
        sb.append("</div>");
    }

    private static String cols(Site.Block b, String def) {
        String c = b.s("columns");
        return c.matches("[1-6]") ? c : def;
    }

    // ------------------------------------------------------------------ преимущества

    private static void features(StringBuilder sb, Site s, Site.Block b, Opt o) {
        sb.append("<div class=\"container\">");
        head(sb, s, b, false);
        List<Map<String, Object>> items = b.items();
        sb.append("<div class=\"grid fv-").append(esc(b.variant)).append("\" style=\"--cols:").append(cols(b, "3")).append("\">");
        int i = 0;
        for (Map<String, Object> it : items) {
            i++;
            String link = str(it, "link");
            String tag = link.isEmpty() ? "div" : "a";
            sb.append("<").append(tag).append(" class=\"feat reveal").append(b.variant.equals("cards") ? " card" : "").append("\"");
            if (!link.isEmpty()) sb.append(" href=\"").append(esc(href(s, link))).append("\"").append(target(link));
            sb.append(">");
            if (b.variant.equals("numbered")) sb.append("<div class=\"num\">").append(i < 10 ? "0" : "").append(i).append("</div>");
            else if (!str(it, "image").isEmpty()) sb.append("<div class=\"feat-img\">").append(picture(s, str(it, "image"), "", o, "16/10")).append("</div>");
            else if (!str(it, "icon").isEmpty()) sb.append("<div class=\"ico\">").append(esc(str(it, "icon"))).append("</div>");
            sb.append("<div class=\"feat-t\">");
            if (!str(it, "title").isEmpty()) sb.append("<h3>").append(inline(str(it, "title"))).append("</h3>");
            if (!str(it, "text").isEmpty()) sb.append("<div class=\"muted\">").append(md(s, str(it, "text"))).append("</div>");
            if (!link.isEmpty()) sb.append("<span class=\"more\">Подробнее →</span>");
            sb.append("</div></").append(tag).append(">");
        }
        sb.append("</div></div>\n");
    }

    // ------------------------------------------------------------------ галерея

    private static final String[] RATIOS = {"4/5", "1/1", "4/3", "3/4", "16/10", "5/4"};

    private static void gallery(StringBuilder sb, Site s, Site.Block b, Opt o) {
        sb.append("<div class=\"container\">");
        head(sb, s, b, false);
        boolean lb = b.b("lightbox") || !b.v.containsKey("lightbox");
        sb.append("<div class=\"gal gv-").append(esc(b.variant)).append("\" style=\"--cols:").append(cols(b, "3")).append("\"")
                .append(lb ? " data-lightbox" : "").append(">");
        int i = 0;
        for (Map<String, Object> it : b.items()) {
            String img = str(it, "image"), cap = str(it, "caption");
            String ratio = b.variant.equals("masonry") ? RATIOS[i % RATIOS.length] : b.variant.equals("row") ? "4/5" : "4/3";
            sb.append("<figure class=\"reveal\">");
            if (!img.isEmpty() && lb) sb.append("<a href=\"").append(esc(img)).append("\" class=\"lb\" data-cap=\"").append(esc(cap)).append("\">");
            sb.append(picture(s, img, "", o, b.variant.equals("masonry") && !img.isEmpty() ? "" : ratio));
            if (!img.isEmpty() && lb) sb.append("</a>");
            if (!cap.isEmpty()) sb.append("<figcaption>").append(esc(cap)).append("</figcaption>");
            sb.append("</figure>");
            i++;
        }
        sb.append("</div></div>\n");
    }

    // ------------------------------------------------------------------ призыв

    private static void cta(StringBuilder sb, Site s, Site.Block b, Opt o) {
        if (b.variant.equals("card")) {
            sb.append("<div class=\"container\"><div class=\"cta-card reveal\"><div>");
            if (!b.s("title").isEmpty()) sb.append("<h2>").append(inline(b.s("title"))).append("</h2>");
            if (!b.s("text").isEmpty()) sb.append("<div class=\"lead\">").append(md(s, b.s("text"))).append("</div>");
            sb.append("</div>").append(buttons(s, b)).append("</div></div>\n");
            return;
        }
        sb.append("<div class=\"container\"><div class=\"cta-band reveal\">");
        if (!b.s("title").isEmpty()) sb.append("<h2>").append(inline(b.s("title"))).append("</h2>");
        if (!b.s("text").isEmpty()) sb.append("<div class=\"lead\">").append(md(s, b.s("text"))).append("</div>");
        sb.append(buttons(s, b)).append("</div></div>\n");
    }

    // ------------------------------------------------------------------ цены

    private static void pricing(StringBuilder sb, Site s, Site.Block b, Opt o) {
        sb.append("<div class=\"container\">");
        head(sb, s, b, false);
        if (b.variant.equals("list")) {
            sb.append("<div class=\"price-list reveal\">");
            for (Map<String, Object> it : b.items()) {
                sb.append("<div class=\"pl-row\"><div class=\"pl-name\">").append(esc(str(it, "name")));
                if (!str(it, "text").isEmpty()) sb.append("<small>").append(esc(str(it, "text").replace('\n', ' '))).append("</small>");
                sb.append("</div><div class=\"pl-dots\"></div><div class=\"pl-price\">").append(esc(str(it, "price")));
                if (!str(it, "period").isEmpty()) sb.append(" <small>/ ").append(esc(str(it, "period"))).append("</small>");
                sb.append("</div></div>");
            }
            sb.append("</div></div>\n");
            return;
        }
        List<Map<String, Object>> items = b.items();
        sb.append("<div class=\"grid prices\" style=\"--cols:").append(Math.max(1, Math.min(4, items.size()))).append("\">");
        for (Map<String, Object> it : items) {
            boolean feat = bool(it, "featured");
            sb.append("<div class=\"card price reveal").append(feat ? " featured" : "").append("\">");
            if (feat) sb.append("<div class=\"badge\">Популярный</div>");
            sb.append("<h3>").append(esc(str(it, "name"))).append("</h3>");
            sb.append("<div class=\"amount\">").append(esc(str(it, "price")));
            if (!str(it, "period").isEmpty()) sb.append("<small> / ").append(esc(str(it, "period"))).append("</small>");
            sb.append("</div>");
            String lines = str(it, "text").trim();
            if (!lines.isEmpty()) {
                sb.append("<ul class=\"checks\">");
                for (String l : lines.split("\n")) if (!l.trim().isEmpty()) sb.append("<li>").append(inline(l.trim().replaceFirst("^[-•✓]\\s*", ""))).append("</li>");
                sb.append("</ul>");
            }
            if (!str(it, "button").isEmpty()) sb.append(btn(s, str(it, "button"), str(it, "link"), feat ? "btn btn-1 wide" : "btn btn-2 wide"));
            sb.append("</div>");
        }
        sb.append("</div></div>\n");
    }

    // ------------------------------------------------------------------ вопросы

    private static void faq(StringBuilder sb, Site s, Site.Block b, Opt o) {
        boolean split = b.variant.equals("split");
        sb.append("<div class=\"container\"><div class=\"").append(split ? "faq-split" : "faq-one").append("\">");
        head(sb, s, b, split);
        sb.append("<div class=\"faq reveal\">");
        boolean first = true;
        for (Map<String, Object> it : b.items()) {
            sb.append("<details").append(first && o.preview ? " open" : "").append("><summary>").append(esc(str(it, "q"))).append("<i></i></summary><div class=\"ans\">")
                    .append(md(s, str(it, "a"))).append("</div></details>");
            first = false;
        }
        sb.append("</div></div></div>\n");
    }

    // ------------------------------------------------------------------ отзывы

    private static void reviews(StringBuilder sb, Site s, Site.Block b, Opt o) {
        sb.append("<div class=\"container\">");
        head(sb, s, b, false);
        boolean quote = b.variant.equals("quote");
        sb.append("<div class=\"").append(quote ? "quotes" : "grid reviews").append("\" style=\"--cols:3\">");
        for (Map<String, Object> it : b.items()) {
            sb.append("<div class=\"review reveal").append(quote ? "" : " card").append("\">");
            long stars = num(it, "stars", 0);
            if (stars > 0) sb.append("<div class=\"stars\" aria-label=\"").append(stars).append(" из 5\">").append("★★★★★".substring(0, (int) Math.min(5, stars)))
                    .append("<span>").append("★★★★★".substring(0, (int) (5 - Math.min(5, stars)))).append("</span></div>");
            sb.append("<div class=\"rv-text\">").append(md(s, str(it, "text"))).append("</div>");
            sb.append("<div class=\"who\">").append(avatar(str(it, "photo"), str(it, "name"))).append("<div><b>").append(esc(str(it, "name"))).append("</b>");
            if (!str(it, "role").isEmpty()) sb.append("<span>").append(esc(str(it, "role"))).append("</span>");
            sb.append("</div></div></div>");
        }
        sb.append("</div>");
        if (quote && b.items().size() > 1) sb.append("<div class=\"q-nav\"><button class=\"q-prev\" aria-label=\"Назад\">←</button><button class=\"q-next\" aria-label=\"Дальше\">→</button></div>");
        sb.append("</div>\n");
    }

    private static String avatar(String photo, String name) {
        if (!photo.isEmpty()) return "<img class=\"ava\" src=\"" + esc(photo) + "\" alt=\"\" loading=\"lazy\">";
        String ini = initials(name);
        return "<span class=\"ava ini\" style=\"--h:" + (Math.abs(name.hashCode()) % 360) + "\">" + esc(ini) + "</span>";
    }

    static String initials(String name) {
        String[] w = name.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String x : w) {
            if (x.isEmpty()) continue;
            sb.appendCodePoint(x.codePointAt(0));
            if (sb.length() >= 2) break;
        }
        return sb.toString().toUpperCase(Locale.ROOT);
    }

    // ------------------------------------------------------------------ цифры, команда

    private static void stats(StringBuilder sb, Site s, Site.Block b, Opt o) {
        sb.append("<div class=\"container\">");
        head(sb, s, b, false);
        List<Map<String, Object>> items = b.items();
        sb.append("<div class=\"grid stats n").append(items.size()).append(" sv-").append(esc(b.variant)).append("\" style=\"--cols:").append(Math.max(1, Math.min(4, items.size()))).append("\">");
        for (Map<String, Object> it : items) {
            sb.append("<div class=\"stat reveal").append(b.variant.equals("cards") ? " card" : "").append("\"><div class=\"big\">").append(esc(str(it, "num")))
                    .append("</div><div class=\"muted\">").append(esc(str(it, "label"))).append("</div></div>");
        }
        sb.append("</div></div>\n");
    }

    private static void team(StringBuilder sb, Site s, Site.Block b, Opt o) {
        sb.append("<div class=\"container\">");
        head(sb, s, b, false);
        boolean round = b.variant.equals("round");
        sb.append("<div class=\"grid team").append(round ? " round" : "").append("\" style=\"--cols:").append(cols(b, "3")).append("\">");
        for (Map<String, Object> it : b.items()) {
            sb.append("<div class=\"person reveal\">");
            String ph = str(it, "photo");
            if (!ph.isEmpty()) sb.append("<div class=\"ph\"><img src=\"").append(esc(ph)).append("\" alt=\"").append(esc(str(it, "name"))).append("\" loading=\"lazy\"></div>");
            else sb.append("<div class=\"ph none\" style=\"--h:").append(Math.abs(str(it, "name").hashCode()) % 360).append("\"><span>")
                    .append(esc(initials(str(it, "name")))).append("</span></div>");
            sb.append("<h3>").append(esc(str(it, "name"))).append("</h3>");
            if (!str(it, "role").isEmpty()) sb.append("<div class=\"role\">").append(esc(str(it, "role"))).append("</div>");
            if (!str(it, "text").isEmpty()) sb.append("<div class=\"muted\">").append(md(s, str(it, "text"))).append("</div>");
            sb.append("</div>");
        }
        sb.append("</div></div>\n");
    }

    // ------------------------------------------------------------------ контакты

    private static void contacts(StringBuilder sb, Site s, Site.Block b, Opt o) {
        boolean split = b.variant.equals("split");
        sb.append("<div class=\"container\">");
        if (!split) head(sb, s, b, false);
        sb.append("<div class=\"").append(split ? "split contacts-split" : "contacts-cards").append("\">");
        sb.append("<div class=\"reveal\">");
        if (split) head(sb, s, b, true);
        sb.append("<div class=\"cinfo").append(split ? "" : " grid").append("\"").append(split ? "" : " style=\"--cols:" + Math.min(4, contactCount(b)) + "\"").append(">");
        String addr = b.s("address"), phone = b.s("phone"), email = b.s("email"), hours = b.s("hours");
        if (!addr.isEmpty()) {
            sb.append(cItem("📍", "Адрес", esc(addr) + "<br><a href=\"https://yandex.ru/maps/?text=" + esc(enc(addr)) + "\" target=\"_blank\" rel=\"noopener\">Открыть на карте →</a>", split));
        }
        if (!phone.isEmpty()) sb.append(cItem("📞", "Телефон", "<a href=\"tel:" + esc(phone.replaceAll("[^+\\d]", "")) + "\">" + esc(phone) + "</a>", split));
        if (!email.isEmpty()) sb.append(cItem("✉️", "Почта", "<a href=\"mailto:" + esc(email) + "\">" + esc(email) + "</a>", split));
        if (!hours.isEmpty()) sb.append(cItem("🕒", "Часы работы", esc(hours), split));
        sb.append("</div>");
        String soc = socials(b);
        if (!soc.isEmpty()) sb.append("<div class=\"socials\">").append(soc).append("</div>");
        sb.append("</div>");
        if (split) {
            sb.append("<div class=\"map reveal\">");
            if (b.b("map") && !addr.isEmpty()) {
                if (o.preview) sb.append("<div class=\"map-ph\">🗺️<span>Карта: ").append(esc(addr)).append("</span><small>появится на готовом сайте</small></div>");
                else sb.append("<iframe src=\"https://yandex.ru/map-widget/v1/?text=").append(esc(enc(addr))).append("&amp;z=16\" loading=\"lazy\" title=\"Карта\" allowfullscreen></iframe>");
            } else sb.append(picture(s, "", "", o, "4/3"));
            sb.append("</div>");
        }
        sb.append("</div></div>\n");
    }

    private static int contactCount(Site.Block b) {
        int n = 0;
        for (String k : new String[]{"address", "phone", "email", "hours"}) if (!b.s(k).isEmpty()) n++;
        return Math.max(1, n);
    }

    private static String cItem(String ico, String label, String html, boolean split) {
        return "<div class=\"citem" + (split ? "" : " card") + "\"><div class=\"ico sm\">" + ico + "</div><div><div class=\"clabel\">" + label + "</div><div class=\"cval\">" + html
                + "</div></div></div>";
    }

    static String socials(Site.Block b) {
        StringBuilder sb = new StringBuilder();
        String tg = b.s("telegram"), wa = b.s("whatsapp"), vk = b.s("vk"), yt = b.s("youtube");
        if (!tg.isEmpty()) sb.append(soc(tg.startsWith("http") ? tg : "https://t.me/" + tg.replaceFirst("^@", "").replaceFirst("^t\\.me/", ""), "Telegram"));
        if (!wa.isEmpty()) sb.append(soc(wa.startsWith("http") ? wa : "https://wa.me/" + wa.replaceAll("\\D", ""), "WhatsApp"));
        if (!vk.isEmpty()) sb.append(soc(vk.startsWith("http") ? vk : "https://vk.com/" + vk.replaceFirst("^@", "").replaceFirst("^vk\\.com/", ""), "ВКонтакте"));
        if (!yt.isEmpty()) sb.append(soc(yt.startsWith("http") ? yt : "https://youtube.com/" + yt, "YouTube"));
        return sb.toString();
    }

    private static String soc(String url, String name) {
        return "<a class=\"soc\" href=\"" + esc(url) + "\" target=\"_blank\" rel=\"noopener\">" + esc(name) + "</a>";
    }

    // ------------------------------------------------------------------ форма

    private static void form(StringBuilder sb, Site s, Site.Block b, Opt o) {
        boolean split = b.variant.equals("split");
        sb.append("<div class=\"container\"><div class=\"").append(split ? "split form-split" : "form-card-wrap").append("\">");
        if (split) {
            sb.append("<div class=\"reveal\">");
            head(sb, s, b, true);
            sb.append("</div>");
        }
        String mode = b.s("sendTo").equals("url") && !b.s("action").isEmpty() ? "url" : "email";
        sb.append("<form class=\"card form reveal\" data-mode=\"").append(mode).append("\" data-to=\"").append(esc(mode.equals("url") ? b.s("action") : b.s("email")))
                .append("\" data-subject=\"").append(esc("Заявка с сайта «" + s.name + "»")).append("\" novalidate>");
        if (!split) {
            if (!b.s("title").isEmpty()) sb.append("<h2>").append(inline(b.s("title"))).append("</h2>");
            if (!b.s("text").isEmpty()) sb.append("<div class=\"lead\">").append(md(s, b.s("text"))).append("</div>");
        }
        if (b.b("fName")) sb.append(input("name", "Имя", "text", "name", true));
        if (b.b("fPhone")) sb.append(input("phone", "Телефон", "tel", "tel", true));
        if (b.b("fEmail")) sb.append(input("email", "Почта", "email", "email", !b.b("fPhone")));
        if (b.b("fMessage")) sb.append("<label class=\"fld\"><span>Сообщение</span><textarea name=\"message\" rows=\"4\"></textarea></label>");
        sb.append("<button class=\"btn btn-1 wide\" type=\"submit\">").append(esc(b.s("button").isEmpty() ? "Отправить" : b.s("button"))).append("</button>");
        if (!b.s("consent").isEmpty()) sb.append("<p class=\"consent\">").append(esc(b.s("consent"))).append("</p>");
        sb.append("<div class=\"ok\" hidden>").append(esc(b.s("success").isEmpty() ? "Спасибо! Мы свяжемся с вами." : b.s("success"))).append("</div>");
        sb.append("</form></div></div>\n");
    }

    private static String input(String name, String label, String type, String auto, boolean req) {
        return "<label class=\"fld\"><span>" + label + (req ? " *" : "") + "</span><input name=\"" + name + "\" type=\"" + type + "\" autocomplete=\"" + auto + "\""
                + (req ? " required" : "") + "></label>";
    }

    // ------------------------------------------------------------------ видео

    private static final Pattern YT = Pattern.compile("(?:youtube\\.com/(?:watch\\?(?:.*&)?v=|embed/|shorts/|live/)|youtu\\.be/)([A-Za-z0-9_-]{6,})");
    private static final Pattern VK = Pattern.compile("vk(?:video)?\\.(?:com|ru)/.*?video(-?\\d+)_(\\d+)");
    private static final Pattern RT = Pattern.compile("rutube\\.ru/(?:video|play/embed)/([a-f0-9]{16,})");

    /** Адрес для встраивания видео или null. */
    static String embed(String url) {
        if (url == null) return null;
        Matcher m = YT.matcher(url);
        if (m.find()) return "https://www.youtube-nocookie.com/embed/" + m.group(1);
        m = VK.matcher(url);
        if (m.find()) return "https://vk.com/video_ext.php?oid=" + m.group(1) + "&id=" + m.group(2) + "&hd=2";
        m = RT.matcher(url);
        if (m.find()) return "https://rutube.ru/play/embed/" + m.group(1);
        return null;
    }

    private static void video(StringBuilder sb, Site s, Site.Block b, Opt o) {
        boolean split = b.variant.equals("split");
        sb.append("<div class=\"container\">");
        if (!split) head(sb, s, b, false);
        sb.append("<div class=\"").append(split ? "split" : "").append("\">");
        if (split) {
            sb.append("<div class=\"reveal\">");
            head(sb, s, b, true);
            sb.append("</div>");
        }
        String url = b.s("url").trim(), e = embed(url);
        sb.append("<div class=\"video reveal\">");
        if (e != null && !o.preview) sb.append("<iframe src=\"").append(esc(e)).append("\" loading=\"lazy\" allow=\"autoplay; encrypted-media; picture-in-picture; fullscreen\" allowfullscreen title=\"Видео\"></iframe>");
        else if (e != null) sb.append("<div class=\"vph\">▶<span>Видео появится на готовом сайте</span></div>");
        else if (!url.isEmpty()) sb.append("<a class=\"vph\" href=\"").append(esc(url)).append("\" target=\"_blank\" rel=\"noopener\">▶<span>Смотреть видео</span></a>");
        else sb.append("<div class=\"vph\">▶<span>Вставьте ссылку на видео</span></div>");
        sb.append("</div></div></div>\n");
    }

    // ------------------------------------------------------------------ записи

    private static void posts(StringBuilder sb, Site s, Site.Page cur, Site.Block b, Opt o) {
        sb.append("<div class=\"container\">");
        head(sb, s, b, false);
        List<Site.Page> ps = s.posts();
        int n = Math.max(1, b.n("count", 6));
        boolean list = b.variant.equals("list");
        sb.append("<div class=\"").append(list ? "post-list" : "grid posts").append("\" style=\"--cols:3\">");
        int i = 0;
        for (Site.Page p : ps) {
            if (i++ >= n) break;
            sb.append("<a class=\"post reveal").append(list ? "" : " card").append("\" href=\"").append(esc(s.file(p))).append("\">");
            if (!list) sb.append("<div class=\"cover\">").append(p.cover.isEmpty() ? "<div class=\"ph-grad\" style=\"--h:" + Math.abs(p.title.hashCode()) % 360 + "\"><span>"
                    + esc(initials(p.title)) + "</span></div>" : "<img src=\"" + esc(p.cover) + "\" alt=\"\" loading=\"lazy\">").append("</div>");
            sb.append("<div class=\"post-t\">");
            if (!p.date.isEmpty()) sb.append("<time datetime=\"").append(esc(p.date)).append("\">").append(esc(date(p.date))).append("</time>");
            sb.append("<h3>").append(esc(p.title)).append("</h3>");
            if (!p.excerpt.isEmpty()) sb.append("<p class=\"muted\">").append(esc(p.excerpt)).append("</p>");
            sb.append("<span class=\"more\">").append(esc(b.s("more").isEmpty() ? "Читать" : b.s("more"))).append(" →</span></div></a>");
        }
        if (ps.isEmpty()) sb.append("<p class=\"muted\">Записей пока нет. Добавьте страницу с типом «Запись блога».</p>");
        sb.append("</div></div>\n");
    }

    private static void postHead(StringBuilder sb, Site s, Site.Page p, Opt o) {
        Site.Page list = null;
        for (Site.Page q : s.pages) for (Site.Block b : q.blocks) if (b.type.equals("posts") && list == null) list = q;
        sb.append("<section class=\"sec post-head pad-m\"><div class=\"container\"><div class=\"prose\">");
        sb.append("<a class=\"back\" href=\"").append(esc(list == null ? "index.html" : s.file(list))).append("\">← Все записи</a>");
        if (!p.date.isEmpty()) sb.append("<time datetime=\"").append(esc(p.date)).append("\">").append(esc(date(p.date))).append("</time>");
        sb.append("<h1>").append(esc(p.title)).append("</h1>");
        if (!p.excerpt.isEmpty()) sb.append("<div class=\"lead\">").append(esc(p.excerpt)).append("</div>");
        sb.append("</div>");
        if (!p.cover.isEmpty()) sb.append("<div class=\"post-cover\"><img src=\"").append(esc(p.cover)).append("\" alt=\"\"></div>");
        sb.append("</div></section>\n");
    }

    private static final String[] MONTHS = {"января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"};

    static String date(String iso) {
        Matcher m = Pattern.compile("(\\d{4})-(\\d{1,2})-(\\d{1,2})").matcher(iso);
        if (!m.find()) return iso;
        int mon = Integer.parseInt(m.group(2));
        return Integer.parseInt(m.group(3)) + " " + (mon >= 1 && mon <= 12 ? MONTHS[mon - 1] : "") + " " + m.group(1);
    }

    // ------------------------------------------------------------------ прочее

    private static void divider(StringBuilder sb, Site.Block b) {
        String size = b.s("size").isEmpty() ? "m" : b.s("size");
        sb.append("<div class=\"container dv dv-").append(esc(size)).append(" dv-").append(esc(b.variant)).append("\">");
        if (b.variant.equals("line")) sb.append("<hr>");
        else if (b.variant.equals("dots")) sb.append("<span>• • •</span>");
        sb.append("</div>\n");
    }

    private static void html(StringBuilder sb, Site.Block b, Opt o) {
        String code = b.s("code");
        sb.append("<div class=\"container custom-code\">");
        if (o.preview) {
            sb.append(code.replaceAll("(?is)<script.*?</script>", "").replaceAll("(?is)<iframe", "<iframe data-off"));
            if (code.toLowerCase(Locale.ROOT).contains("<script")) sb.append("<div class=\"edit-note\">Скрипты из этого блока работают на готовом сайте</div>");
        } else sb.append(code);
        sb.append("</div>\n");
    }

    // ------------------------------------------------------------------ подвал

    private static void footer(StringBuilder sb, Site s, Site.Page p, Site.Block b, Opt o) {
        sb.append("<footer class=\"ftr fv-").append(esc(b.variant)).append(bgClass(b)).append("\"");
        if (o.preview) sb.append(" data-block=\"").append(b.id).append("\"");
        String st = bgStyle(b);
        if (!st.isEmpty()) sb.append(" style=\"").append(esc(st)).append("\"");
        sb.append(">\n");
        footerInner(sb, s, p, b, o);
        sb.append("</footer>\n");
    }

    private static void footerInner(StringBuilder sb, Site s, Site.Page p, Site.Block b, Opt o) {
        StringBuilder menu = new StringBuilder();
        if (b.b("autoMenu")) {
            if (menuPages(s) > 1) {
                for (Site.Page q : s.pages) if (q.menu && !q.post()) menu.append("<a href=\"").append(esc(s.file(q))).append("\">").append(esc(q.title)).append("</a>");
            } else if (s.header != null) {
                for (Map<String, Object> it : s.header.items()) {
                    if (str(it, "text").isEmpty()) continue;
                    menu.append("<a href=\"").append(esc(href(s, str(it, "link")))).append("\"").append(target(str(it, "link"))).append(">").append(esc(str(it, "text"))).append("</a>");
                }
            }
        }
        StringBuilder contact = new StringBuilder();
        if (!b.s("phone").isEmpty()) contact.append("<a href=\"tel:").append(esc(b.s("phone").replaceAll("[^+\\d]", ""))).append("\">").append(esc(b.s("phone"))).append("</a>");
        if (!b.s("email").isEmpty()) contact.append("<a href=\"mailto:").append(esc(b.s("email"))).append("\">").append(esc(b.s("email"))).append("</a>");
        String soc = socials(b);
        String name = b.s("logo").isEmpty() ? s.name : b.s("logo");
        if (b.variant.equals("simple")) {
            sb.append("<div class=\"container ftr-row\"><div class=\"logo\">").append(esc(name)).append("</div>");
            if (menu.length() > 0) sb.append("<nav class=\"fnav\">").append(menu).append("</nav>");
            if (!soc.isEmpty()) sb.append("<div class=\"socials\">").append(soc).append("</div>");
            sb.append("</div>");
        } else {
            sb.append("<div class=\"container ftr-cols\"><div class=\"fc-about\"><div class=\"logo\">").append(esc(name)).append("</div>");
            if (!b.s("text").isEmpty()) sb.append("<div class=\"muted\">").append(md(s, b.s("text"))).append("</div>");
            sb.append("</div>");
            if (menu.length() > 0) sb.append("<div><div class=\"fh\">Разделы</div><nav class=\"fnav col\">").append(menu).append("</nav></div>");
            if (contact.length() > 0 || !soc.isEmpty()) {
                sb.append("<div><div class=\"fh\">Контакты</div><div class=\"fnav col\">").append(contact).append("</div>");
                if (!soc.isEmpty()) sb.append("<div class=\"socials\">").append(soc).append("</div>");
                sb.append("</div>");
            }
            sb.append("</div>");
        }
        if (!b.s("copyright").isEmpty() || !b.s("small").isEmpty()) {
            sb.append("<div class=\"container ftr-bottom\">");
            if (!b.s("copyright").isEmpty()) sb.append("<span>").append(esc(b.s("copyright"))).append("</span>");
            if (!b.s("small").isEmpty()) sb.append("<div class=\"small\">").append(md(s, b.s("small"))).append("</div>");
            sb.append("</div>");
        }
    }

    // ================================================================== картинки

    private static final String PH_SVG = "<svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M4 5h16a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm1 2v8.6l4-4 3.5 3.5L15 12.6l4 4V7H5zm10.5 1.5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3z\"/></svg>";

    /** Картинка или заглушка (пока фото не выбрано). ratio — соотношение сторон рамки («4/3»), пусто — естественное. */
    static String picture(Site s, String img, String cls, Opt o, String ratio) {
        String style = ratio.isEmpty() ? "" : " style=\"aspect-ratio:" + ratio + "\"";
        if (img == null || img.isEmpty()) {
            return "<div class=\"ph" + (cls.isEmpty() ? "" : " " + cls) + "\"" + style + ">" + PH_SVG + (o.preview ? "<span>Нажмите, чтобы выбрать фото</span>" : "") + "</div>";
        }
        return "<div class=\"pic" + (cls.isEmpty() ? "" : " " + cls) + "\"" + style + "><img src=\"" + esc(img) + "\" alt=\"\" loading=\"lazy\" decoding=\"async\"></div>";
    }

    // ================================================================== ссылки и текст

    /** Ссылка из проекта → адрес на сайте. «page:id» → файл страницы, «@ник» → Telegram, телефон → tel:, почта → mailto:. */
    static String href(Site s, String link) {
        if (link == null) return "#";
        String l = link.trim();
        if (l.isEmpty()) return "#";
        if (l.startsWith("page:")) {
            String id = l.substring(5), anchor = "";
            int h = id.indexOf('#');
            if (h >= 0) {
                anchor = id.substring(h);
                id = id.substring(0, h);
            }
            Site.Page p = s.page(id);
            return p == null ? "#" : s.file(p) + anchor;
        }
        if (l.startsWith("#") && l.length() > 1) {
            Site.Page cur = CUR.get();
            String a = l.substring(1);
            if (cur != null && !hasAnchor(cur, a) && !(s.header != null && a.equals(s.header.anchor)) && !(s.footer != null && a.equals(s.footer.anchor))) {
                for (Site.Page q : s.pages) if (hasAnchor(q, a)) return s.file(q) + l;
            }
            return l;
        }
        if (l.startsWith("#") || l.startsWith("http://") || l.startsWith("https://") || l.startsWith("mailto:") || l.startsWith("tel:") || l.startsWith("/")
                || l.endsWith(".html")) return l;
        if (l.startsWith("@")) return "https://t.me/" + l.substring(1);
        if (l.matches("\\+?[\\d\\s()\\-]{6,}")) return "tel:" + l.replaceAll("[^+\\d]", "");
        if (l.matches("[^@\\s]+@[^@\\s]+\\.[^@\\s]+")) return "mailto:" + l;
        if (l.matches("(www\\.)?[\\w.-]+\\.[a-zа-я]{2,}(/.*)?")) return "https://" + l;
        return l;
    }

    private static boolean hasAnchor(Site.Page p, String a) {
        for (Site.Block b : p.blocks) if (a.equals(b.anchor)) return true;
        return false;
    }

    /** Сколько страниц в меню (кроме записей блога). */
    static int menuPages(Site s) {
        int n = 0;
        for (Site.Page q : s.pages) if (q.menu && !q.post()) n++;
        return n;
    }

    private static String target(String link) {
        return link != null && (link.startsWith("http") || link.startsWith("@") || link.matches("(www\\.)?[\\w.-]+\\.[a-z]{2,}(/.*)?")) ? " target=\"_blank\" rel=\"noopener\"" : "";
    }

    static String esc(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&': sb.append("&amp;"); break;
                case '<': sb.append("&lt;"); break;
                case '>': sb.append("&gt;"); break;
                case '"': sb.append("&quot;"); break;
                default: sb.append(c);
            }
        }
        return sb.toString();
    }

    static String enc(String s) {
        try {
            return java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20");
        } catch (java.io.UnsupportedEncodingException e) {
            return s;
        }
    }

    private static final Pattern LINK_MD = Pattern.compile("\\[([^\\]]+)\\]\\(([^)\\s]+)\\)");

    /** Строка без абзацев: **жирный**, *курсив*, [ссылка](адрес). */
    static String inline(String t) {
        String e = esc(t);
        e = e.replaceAll("\\*\\*(.+?)\\*\\*", "<strong>$1</strong>");
        e = e.replaceAll("(?<![\\w*])\\*(?!\\s)(.+?)(?<!\\s)\\*(?![\\w*])", "<em>$1</em>");
        Matcher m = LINK_MD.matcher(e);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String url = m.group(2);
            boolean ext = url.startsWith("http");
            m.appendReplacement(sb, Matcher.quoteReplacement("<a href=\"" + url + "\"" + (ext ? " target=\"_blank\" rel=\"noopener\"" : "") + ">" + m.group(1) + "</a>"));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** Простая разметка: абзацы, переносы, списки «- » и «1. », подзаголовки «## ». */
    static String md(Site s, String text) {
        if (text == null || text.trim().isEmpty()) return "";
        String[] lines = text.replace("\r", "").split("\n", -1);
        StringBuilder out = new StringBuilder();
        StringBuilder para = new StringBuilder();
        String list = null;
        for (String raw : lines) {
            String l = raw.trim();
            boolean ul = l.matches("^[-•*]\\s+.*"), ol = l.matches("^\\d+[.)]\\s+.*"), h = l.startsWith("## ") || l.startsWith("### ");
            if (l.isEmpty() || ul || ol || h) {
                if (para.length() > 0) {
                    out.append("<p>").append(para).append("</p>");
                    para.setLength(0);
                }
            }
            if (!ul && !ol && list != null) {
                out.append("</").append(list).append(">");
                list = null;
            }
            if (l.isEmpty()) continue;
            if (h) {
                out.append("<h3>").append(inline(l.replaceFirst("^#+\\s+", ""))).append("</h3>");
            } else if (ul || ol) {
                String want = ul ? "ul" : "ol";
                if (!want.equals(list)) {
                    if (list != null) out.append("</").append(list).append(">");
                    out.append("<").append(want).append(">");
                    list = want;
                }
                out.append("<li>").append(inline(l.replaceFirst(ul ? "^[-•*]\\s+" : "^\\d+[.)]\\s+", ""))).append("</li>");
            } else {
                if (para.length() > 0) para.append("<br>");
                para.append(inline(l));
            }
        }
        if (para.length() > 0) out.append("<p>").append(para).append("</p>");
        if (list != null) out.append("</").append(list).append(">");
        return out.toString();
    }

    private static String str(Map<String, Object> m, String k) {
        Object o = m.get(k);
        return o == null ? "" : String.valueOf(o);
    }

    private static boolean bool(Map<String, Object> m, String k) {
        Object o = m.get(k);
        return o instanceof Boolean ? (Boolean) o : "true".equals(o);
    }

    private static long num(Map<String, Object> m, String k, long def) {
        Object o = m.get(k);
        if (o instanceof Number) return ((Number) o).longValue();
        try {
            return o == null ? def : Long.parseLong(String.valueOf(o).trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    // ================================================================== цвета

    static int[] rgb(String hex) {
        String h = hex == null ? "" : hex.trim().replace("#", "");
        if (h.length() == 3) h = "" + h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
        if (h.length() < 6) return new int[]{128, 128, 128};
        try {
            return new int[]{Integer.parseInt(h.substring(0, 2), 16), Integer.parseInt(h.substring(2, 4), 16), Integer.parseInt(h.substring(4, 6), 16)};
        } catch (NumberFormatException e) {
            return new int[]{128, 128, 128};
        }
    }

    static String hex(int r, int g, int b) {
        return String.format(Locale.ROOT, "#%02X%02X%02X", clamp(r), clamp(g), clamp(b));
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }

    /** Смесь цветов: t = доля второго. */
    static String mix(String a, String b, double t) {
        int[] x = rgb(a), y = rgb(b);
        return hex((int) Math.round(x[0] + (y[0] - x[0]) * t), (int) Math.round(x[1] + (y[1] - x[1]) * t), (int) Math.round(x[2] + (y[2] - x[2]) * t));
    }

    static String rgba(String hex, double a) {
        int[] c = rgb(hex);
        return "rgba(" + c[0] + "," + c[1] + "," + c[2] + "," + String.format(Locale.ROOT, "%.2f", a) + ")";
    }

    static double luma(String hex) {
        int[] c = rgb(hex);
        return (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255.0;
    }

    // ================================================================== CSS и JS

    static String css(Site s) {
        Site.Look l = s.look;
        Themes.Fonts f = Themes.fonts(l.fonts);
        int r = Themes.radiusPx(l.radius);
        String head = f.head.isEmpty() ? "system-ui,-apple-system,'Segoe UI',Roboto,sans-serif" : "'" + f.head + "',system-ui,sans-serif";
        String body = f.body.isEmpty() ? "system-ui,-apple-system,'Segoe UI',Roboto,sans-serif" : "'" + f.body + "',system-ui,sans-serif";
        String dark = l.dark ? mix(l.bg, "#000000", 0.45) : (luma(l.text) < 0.25 ? mix(l.text, "#000000", 0.15) : "#111318");
        String darkFg = l.dark ? l.text : "#F5F6F8";
        String light = l.dark ? "#F6F6F4" : "#FFFFFF";
        String soft = mix(l.bg, l.primary, l.dark ? 0.18 : 0.10);
        String onAccent = luma(l.accent) > 0.6 ? "#111111" : "#FFFFFF";
        StringBuilder c = new StringBuilder(24 * 1024);
        c.append(":root{--bg:").append(l.bg).append(";--surface:").append(l.surface).append(";--text:").append(l.text).append(";--muted:").append(l.muted)
                .append(";--primary:").append(l.primary).append(";--on-primary:").append(l.onPrimary).append(";--accent:").append(l.accent)
                .append(";--on-accent:").append(onAccent).append(";--border:").append(l.border).append(";--soft:").append(soft)
                .append(";--card:").append(l.dark ? mix(l.surface, "#FFFFFF", 0.02) : l.bg)
                .append(";--r:").append(r).append("px;--r-sm:").append(Math.max(0, r / 2)).append("px;--btn-r:").append(l.radius.equals("xl") ? "999px" : Math.min(r, 16) + "px")
                .append(";--maxw:").append(Themes.widthPx(l.width)).append("px;--fh:").append(head).append(";--fb:").append(body).append(";--hw:").append(f.headWeight)
                .append(";--shadow:").append(l.shadows ? (l.dark ? "0 18px 50px rgba(0,0,0,.45)" : "0 18px 50px " + rgba(l.text, 0.10)) : "none")
                .append(";--shadow-sm:").append(l.shadows ? (l.dark ? "0 6px 20px rgba(0,0,0,.35)" : "0 6px 20px " + rgba(l.text, 0.07)) : "none")
                .append(";--glow1:").append(rgba(l.primary, l.dark ? 0.35 : 0.22)).append(";--glow2:").append(rgba(l.accent, l.dark ? 0.28 : 0.18))
                .append(";--dark:").append(dark).append(";--dark-fg:").append(darkFg).append(";--light:").append(light)
                .append(";--hdr-bg:").append(rgba(l.bg, 0.82))
                .append(";--brand:").append(l.primary).append(";--brand-fg:").append(l.onPrimary).append(";--page-bg:").append(l.bg).append(";--page-text:").append(l.text)
                .append(";--page-muted:").append(l.muted).append(";--page-border:").append(l.border).append(";--page-soft:").append(soft)
                .append(";--page-card:").append(l.dark ? mix(l.surface, "#FFFFFF", 0.02) : l.bg).append("}\n");
        c.append(BASE_CSS);
        // кнопки
        switch (l.buttons) {
            case "outline":
                c.append(".btn-1{background:transparent;color:var(--primary);border-color:var(--primary)}.btn-1:hover{background:var(--primary);color:var(--on-primary)}\n");
                break;
            case "soft":
                c.append(".btn-1{background:var(--soft);color:var(--primary)}.btn-1:hover{background:var(--primary);color:var(--on-primary)}\n");
                break;
            case "gradient":
                c.append(".btn-1{background:linear-gradient(120deg,var(--primary),var(--accent));color:var(--on-primary);box-shadow:0 10px 30px var(--glow1)}\n");
                break;
            default:
                c.append(".btn-1{background:var(--primary);color:var(--on-primary)}.btn-1:hover{box-shadow:0 10px 30px var(--glow1)}\n");
        }
        if (l.animate) c.append(".js .reveal{opacity:0;transform:translateY(22px);transition:opacity .7s ease,transform .7s cubic-bezier(.2,.7,.2,1)}.js .reveal.in{opacity:1;transform:none}\n"
                + "@media (prefers-reduced-motion:reduce){.js .reveal{opacity:1;transform:none;transition:none}}\n");
        if (!s.css.trim().isEmpty()) c.append("/* свой CSS */\n").append(s.css).append('\n');
        return c.toString();
    }

    private static final String BASE_CSS = ""
            + "*,*::before,*::after{box-sizing:border-box}html{scroll-behavior:smooth;-webkit-text-size-adjust:100%;scroll-padding-top:84px}\n"
            + "body{margin:0;background:var(--bg);color:var(--text);font:400 17px/1.65 var(--fb);-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;overflow-x:hidden}\n"
            + "img{max-width:100%;display:block}a{color:var(--primary);text-decoration-thickness:1px;text-underline-offset:3px}\n"
            + "h1,h2,h3{font-family:var(--fh);font-weight:var(--hw);line-height:1.1;letter-spacing:-.022em;margin:0 0 .5em;text-wrap:balance}\n"
            + "h1{font-size:clamp(38px,6.2vw,72px)}h2{font-size:clamp(28px,4vw,46px)}h3{font-size:clamp(19px,2vw,23px);letter-spacing:-.01em;line-height:1.25}\n"
            + "p{margin:0 0 1em}p:last-child{margin-bottom:0}ul,ol{margin:0 0 1em;padding-left:1.3em}li{margin:.3em 0}\n"
            + ".container{width:100%;max-width:var(--maxw);margin:0 auto;padding:0 22px}\n"
            + ".sec{position:relative;color:var(--text)}.pad-none{padding:0}.pad-s{padding:40px 0}.pad-m{padding:clamp(60px,8vw,104px) 0}.pad-l{padding:clamp(84px,12vw,150px) 0}\n"
            + ".bg-surface{background:var(--surface);--card:var(--bg)}.bg-page{background:var(--bg)}\n"
            + ".bg-primary{background:var(--brand);--text:var(--brand-fg);--muted:color-mix(in srgb,var(--brand-fg) 82%,transparent);--primary:var(--brand-fg);--on-primary:var(--brand);--border:rgba(255,255,255,.22);--card:rgba(255,255,255,.1);--soft:rgba(255,255,255,.14)}\n"
            + ".bg-accent{background:var(--accent);--text:var(--on-accent);--muted:color-mix(in srgb,var(--on-accent) 80%,transparent);--primary:var(--on-accent);--on-primary:var(--accent);--border:rgba(0,0,0,.14);--card:rgba(255,255,255,.18)}\n"
            + ".bg-dark{background:var(--dark);--text:var(--dark-fg);--muted:color-mix(in srgb,var(--dark-fg) 70%,transparent);--border:rgba(255,255,255,.12);--card:rgba(255,255,255,.05);--surface:rgba(255,255,255,.06)}\n"
            + ".bg-light{background:var(--light);--text:#14161C;--muted:#5E6472;--border:#E3E6EC;--card:#fff;--surface:#F4F5F8}\n"
            + ".on-dark{--text:#fff;--muted:rgba(255,255,255,.82);--border:rgba(255,255,255,.2);--card:rgba(255,255,255,.08);--surface:rgba(255,255,255,.08)}\n"
            + ".bg-image{background-size:cover;background-position:center}.bg-image::before{content:'';position:absolute;inset:0;background:rgba(0,0,0,.5)}.bg-image>*{position:relative}\n"
            + ".muted,.lead{color:var(--muted)}.lead{font-size:clamp(18px,1.9vw,21px);line-height:1.6}.center{text-align:center}\n"
            + ".eyebrow{display:inline-block;font-size:13px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--primary);margin-bottom:16px}\n"
            + ".btns{display:flex;flex-wrap:wrap;gap:12px;margin-top:30px}.center .btns,.sec-head:not(.left) .btns{justify-content:center}\n"
            + ".btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:52px;padding:0 28px;border-radius:var(--btn-r);font:700 16px/1 var(--fb);text-decoration:none;border:2px solid transparent;cursor:pointer;transition:transform .18s,box-shadow .18s,background .18s,color .18s;white-space:nowrap}\n"
            + ".btn:hover{transform:translateY(-2px)}.btn:active{transform:none}.btn-sm{min-height:42px;padding:0 18px;font-size:15px}.btn.wide{width:100%}\n"
            + ".btn-2{background:transparent;color:var(--text);border-color:color-mix(in srgb,var(--text) 22%,transparent)}.btn-2:hover{border-color:var(--text)}\n"
            + ".card{background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:clamp(22px,3vw,32px);box-shadow:var(--shadow-sm)}\n"
            + ".grid{display:grid;gap:clamp(16px,2.4vw,28px);grid-template-columns:repeat(var(--cols,3),minmax(0,1fr))}\n"
            + ".sec-head{max-width:740px;margin:0 auto clamp(32px,5vw,56px);text-align:center}.sec-head.left{text-align:left;margin-left:0}\n"
            + ".split{display:grid;grid-template-columns:1fr 1fr;gap:clamp(28px,6vw,80px);align-items:center}\n"
            + ".ph{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;background:linear-gradient(135deg,var(--soft),color-mix(in srgb,var(--accent) 16%,var(--surface)));border-radius:var(--r);color:var(--primary);min-height:120px;width:100%}\n"
            + ".ph svg{width:44px;height:44px;fill:currentColor;opacity:.55}.ph span{font-size:13px;color:var(--muted);text-align:center;padding:0 10px}\n"
            + ".pic{border-radius:var(--r);overflow:hidden;background:var(--surface)}.pic img{width:100%;height:100%;object-fit:cover}\n"
            + ".pic:not([style]) img{height:auto}\n"
            // шапка
            + ".hdr{position:relative;z-index:50;background:var(--bg);border-bottom:1px solid var(--border)}.hdr.sticky{position:sticky;top:0;background:var(--hdr-bg);-webkit-backdrop-filter:saturate(1.6) blur(14px);backdrop-filter:saturate(1.6) blur(14px)}\n"
            + ".hdr.over{position:absolute;left:0;right:0;top:0;background:transparent;border-color:transparent;-webkit-backdrop-filter:none;backdrop-filter:none}.hdr.over.sticky{position:fixed}.hdr.over.scrolled{background:var(--hdr-bg);border-color:var(--border);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px)}\n"
            + ".hdr.light:not(.scrolled){--text:#fff;--primary:#fff;--on-primary:#111}\n"
            + ".hdr-in{display:flex;align-items:center;gap:24px;min-height:74px}.logo{font:var(--hw) 21px/1 var(--fh);color:var(--text);text-decoration:none;letter-spacing:-.02em;margin-right:auto}.logo img{max-height:44px;width:auto}\n"
            + ".nav{display:flex;align-items:center;gap:6px}.nav a:not(.btn){color:var(--text);text-decoration:none;font-weight:600;font-size:15px;padding:10px 12px;border-radius:10px;opacity:.82;transition:opacity .15s,background .15s}.nav a:not(.btn):hover,.nav a.cur{opacity:1;background:var(--soft)}\n"
            + ".nav-btn{margin-left:10px}.hdr.v-center .hdr-in{flex-direction:column;gap:6px;padding:16px 22px}.hdr.v-center .logo{margin:0 auto}\n"
            + ".burger{display:none;width:44px;height:44px;border:0;background:transparent;border-radius:12px;cursor:pointer;flex-direction:column;align-items:center;justify-content:center;gap:5px;color:var(--text)}\n"
            + ".burger span{display:block;width:22px;height:2px;background:currentColor;border-radius:2px;transition:transform .25s,opacity .2s}.menu-open .burger span:nth-child(1){transform:translateY(7px) rotate(45deg)}.menu-open .burger span:nth-child(2){opacity:0}.menu-open .burger span:nth-child(3){transform:translateY(-7px) rotate(-45deg)}\n"
            // обложка
            + ".t-hero{overflow:hidden}.hero-in{position:relative;display:flex;align-items:center;padding-top:clamp(36px,6vw,72px);padding-bottom:clamp(36px,6vw,72px)}.hero-in.h-tall{min-height:min(78vh,820px)}.hero-in.h-screen{min-height:100vh;min-height:100svh}\n"
            + ".hero-in.center{justify-content:center;text-align:center}.hero-in.center .hero-text{max-width:860px;margin:0 auto}.hero-in.center .btns{justify-content:center}\n"
            + ".hero-in.bottom{align-items:flex-end}.hero-in .split{width:100%}.hero-text{max-width:720px}.hero-text.big h1{font-size:clamp(44px,8vw,104px);line-height:1}.hero-text .lead{margin-top:6px;max-width:640px}.hero-in.center .lead{margin-left:auto;margin-right:auto}\n"
            + ".under-hdr .hero-in,.under-hdr>.container{padding-top:calc(74px + clamp(36px,6vw,72px))}\n"
            + ".hero-bg{position:absolute;inset:0;background-size:cover;background-position:center;transform:scale(1.02)}.hero-bg.glow{background:radial-gradient(60% 70% at 20% 20%,var(--glow1),transparent 70%),radial-gradient(50% 60% at 85% 80%,var(--glow2),transparent 70%),linear-gradient(160deg,var(--dark),color-mix(in srgb,var(--primary) 35%,var(--dark)))}\n"
            + ".hero-shade{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.25),#000)}\n"
            + ".t-hero.v-full,.t-hero.v-center:has(.hero-bg){--text:#fff;--muted:rgba(255,255,255,.85);--primary:#fff;--on-primary:#111;color:#fff}.t-hero.v-full .btn-1,.t-hero.v-center .hero-bg~.container .btn-1{background:#fff;color:#111;border-color:#fff}.t-hero.v-full .btn-2,.t-hero.v-center .hero-bg~.container .btn-2{color:#fff;border-color:rgba(255,255,255,.5)}\n"
            + ".blob{position:absolute;border-radius:50%;filter:blur(60px);pointer-events:none}.blob.b1{width:520px;height:520px;background:var(--glow1);top:-180px;left:-120px}.blob.b2{width:460px;height:460px;background:var(--glow2);bottom:-200px;right:-120px}\n"
            + ".hero-img .pic,.hero-img .ph{box-shadow:var(--shadow)}\n"
            // текст
            + ".prose{max-width:760px;margin:0 auto}.prose.center{text-align:center}.prose .body{font-size:18px}.prose .body h3{margin-top:1.4em}.tv-two{max-width:none}.tv-two .body{columns:2;column-gap:56px}\n"
            + ".tv-lead .body{font:500 clamp(22px,2.8vw,32px)/1.4 var(--fh);letter-spacing:-.01em;color:var(--text)}\n"
            + "blockquote{margin:0;font:500 clamp(24px,3.2vw,38px)/1.35 var(--fh);letter-spacing:-.015em}.qmark{font:800 96px/0.6 var(--fh);color:var(--primary);height:44px}blockquote cite{display:block;margin-top:22px;font:600 16px/1.4 var(--fb);color:var(--muted);font-style:normal}\n"
            // картинка+текст
            + ".it-right .it-img{order:2}.it-img .pic,.it-img .ph{box-shadow:var(--shadow)}.shape-rect .pic,.shape-rect .ph{border-radius:0}.shape-circle .pic,.shape-circle .ph{border-radius:50%}.shape-arch .pic,.shape-arch .ph{border-radius:999px 999px var(--r) var(--r)}\n"
            + ".it-text .body{font-size:18px;color:var(--muted)}\n"
            // преимущества
            + ".feat{display:block;color:inherit;text-decoration:none}.feat h3{margin-bottom:8px}.feat .muted p{margin:0}a.feat{transition:transform .2s,box-shadow .2s}a.feat:hover{transform:translateY(-4px);box-shadow:var(--shadow)}\n"
            + ".ico{width:56px;height:56px;border-radius:calc(var(--r) * .8 + 4px);background:var(--soft);display:flex;align-items:center;justify-content:center;font-size:27px;margin-bottom:18px}.ico.sm{width:44px;height:44px;font-size:20px;margin:0;flex:none}\n"
            + ".feat-img{margin:-1px -1px 18px}.card .feat-img{margin:calc(clamp(22px,3vw,32px) * -1) calc(clamp(22px,3vw,32px) * -1) 20px}.card .feat-img .pic,.card .feat-img .ph{border-radius:var(--r) var(--r) 0 0}\n"
            + ".fv-numbered .feat{border-top:2px solid var(--border);padding-top:22px}.num{font:var(--hw) 44px/1 var(--fh);color:var(--primary);margin-bottom:14px;letter-spacing:-.03em}\n"
            + ".fv-side .feat{display:flex;gap:18px;align-items:flex-start}.fv-side .ico{margin:0;flex:none}.more{display:inline-block;margin-top:12px;font-weight:700;color:var(--primary);font-size:15px}\n"
            // галерея
            + ".gal{display:grid;gap:14px;grid-template-columns:repeat(var(--cols,3),minmax(0,1fr))}.gal figure{margin:0}.gal figcaption{font-size:14px;color:var(--muted);margin-top:8px}\n"
            + ".gal .pic img{transition:transform .5s}.gal a:hover .pic img{transform:scale(1.04)}.gv-masonry{display:block;columns:var(--cols,3);column-gap:14px}.gv-masonry figure{break-inside:avoid;margin-bottom:14px}\n"
            + ".gv-row{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;gap:14px;padding-bottom:10px;-webkit-overflow-scrolling:touch}.gv-row figure{flex:0 0 clamp(240px,32%,380px);scroll-snap-align:start}\n"
            + ".lbox{position:fixed;inset:0;z-index:999;background:rgba(5,5,8,.94);display:flex;align-items:center;justify-content:center;flex-direction:column;opacity:0;transition:opacity .2s}.lbox.on{opacity:1}\n"
            + ".lbox img{max-width:94vw;max-height:84vh;border-radius:8px;object-fit:contain}.lbox p{color:#ddd;margin:14px 20px 0;text-align:center}.lbox button{position:absolute;background:rgba(255,255,255,.12);color:#fff;border:0;width:52px;height:52px;border-radius:50%;font-size:24px;cursor:pointer}\n"
            + ".lbox .x{top:16px;right:16px}.lbox .pv{left:16px;top:50%;margin-top:-26px}.lbox .nx{right:16px;top:50%;margin-top:-26px}\n"
            // призыв
            + ".cta-band{text-align:center;max-width:820px;margin:0 auto}.t-cta.v-band:not(.bg-primary):not(.bg-dark):not(.bg-accent):not(.bg-image):not(.bg-custom) .cta-band{background:linear-gradient(135deg,var(--brand),color-mix(in srgb,var(--accent) 55%,var(--brand)));color:var(--brand-fg);--text:var(--brand-fg);--muted:color-mix(in srgb,var(--brand-fg) 85%,transparent);--primary:var(--brand-fg);--on-primary:var(--brand);--border:color-mix(in srgb,var(--brand-fg) 40%,transparent);max-width:none;border-radius:calc(var(--r) * 1.5);padding:clamp(40px,7vw,84px) clamp(22px,5vw,60px)}\n"
            + ".cta-band .lead{max-width:620px;margin:0 auto}.cta-band .btns{justify-content:center}.cta-card{display:flex;align-items:center;justify-content:space-between;gap:28px;background:var(--surface);border:1px solid var(--border);border-radius:calc(var(--r) * 1.5);padding:clamp(28px,5vw,56px)}.cta-card h2{margin-bottom:.25em}.cta-card .btns{margin:0;flex:none}\n"
            // цены
            + ".price{position:relative;display:flex;flex-direction:column}.price h3{margin-bottom:12px}.amount{font:var(--hw) clamp(32px,4vw,44px)/1 var(--fh);letter-spacing:-.03em;margin-bottom:20px}.amount small{font:500 16px var(--fb);color:var(--muted);letter-spacing:0}\n"
            + ".checks{list-style:none;padding:0;margin:0 0 26px;flex:1}.checks li{padding-left:30px;position:relative;margin:10px 0}.checks li::before{content:'✓';position:absolute;left:0;top:0;width:20px;height:20px;border-radius:50%;background:var(--soft);color:var(--primary);font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center;margin-top:3px}\n"
            + ".price.featured{border:2px solid var(--primary);box-shadow:var(--shadow);transform:translateY(-8px)}.badge{position:absolute;top:-13px;left:50%;transform:translateX(-50%);background:var(--primary);color:var(--on-primary);font-size:12px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;padding:6px 14px;border-radius:999px;white-space:nowrap}\n"
            + ".prices{align-items:stretch;padding-top:10px}.price-list{max-width:780px;margin:0 auto}.pl-row{display:flex;align-items:baseline;gap:12px;padding:16px 0;border-bottom:1px solid var(--border)}.pl-name{font-weight:600;font-size:18px}.pl-name small{display:block;font-weight:400;font-size:14px;color:var(--muted)}\n"
            + ".pl-dots{flex:1;border-bottom:2px dotted var(--border);transform:translateY(-6px);min-width:20px}.pl-price{font:var(--hw) 20px var(--fh);white-space:nowrap;color:var(--primary)}.pl-price small{font:500 14px var(--fb);color:var(--muted)}\n"
            // вопросы
            + ".faq-one .faq{max-width:820px;margin:0 auto}.faq-split{display:grid;grid-template-columns:1fr 1.6fr;gap:clamp(28px,6vw,80px);align-items:start}.faq-split .sec-head{margin:0}\n"
            + ".faq details{border-bottom:1px solid var(--border)}.faq summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:20px;padding:22px 0;font:600 clamp(17px,1.8vw,20px)/1.35 var(--fh)}.faq summary::-webkit-details-marker{display:none}\n"
            + ".faq summary i{flex:none;width:32px;height:32px;border-radius:50%;background:var(--soft);position:relative;transition:transform .25s}.faq summary i::before,.faq summary i::after{content:'';position:absolute;left:50%;top:50%;width:12px;height:2px;margin:-1px 0 0 -6px;background:var(--primary);border-radius:2px}.faq summary i::after{transform:rotate(90deg);transition:transform .25s}\n"
            + ".faq details[open] summary i::after{transform:rotate(0)}.ans{padding:0 50px 22px 0;color:var(--muted)}\n"
            // отзывы
            + ".review{display:flex;flex-direction:column}.rv-text{flex:1;font-size:17px;margin-bottom:22px}.stars{color:#F5B301;letter-spacing:2px;margin-bottom:12px;font-size:18px}.stars span{opacity:.25}\n"
            + ".who{display:flex;align-items:center;gap:12px}.who span{display:block;font-size:14px;color:var(--muted)}.ava{width:48px;height:48px;border-radius:50%;object-fit:cover;flex:none}\n"
            + ".ava.ini{display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;background:linear-gradient(135deg,hsl(var(--h),70%,55%),hsl(calc(var(--h) + 40),70%,45%))}\n"
            + ".quotes{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;gap:24px;scrollbar-width:none}.quotes::-webkit-scrollbar{display:none}.quotes .review{flex:0 0 100%;scroll-snap-align:center;text-align:center;align-items:center;padding:0 4%}.quotes .rv-text{max-width:860px}\n"
            + ".quotes .rv-text{font:500 clamp(22px,3vw,34px)/1.35 var(--fh)}.q-nav{display:flex;justify-content:center;gap:12px;margin-top:22px}.q-nav button{width:48px;height:48px;border-radius:50%;border:1px solid var(--border);background:var(--card);color:var(--text);font-size:18px;cursor:pointer}\n"
            // цифры
            + ".stat .big{font:var(--hw) clamp(40px,5.5vw,64px)/1 var(--fh);letter-spacing:-.035em;color:var(--primary);margin-bottom:10px}.stats{text-align:center}\n"
            // команда
            + ".person h3{margin:16px 0 4px}.role{color:var(--primary);font-weight:600;font-size:15px;margin-bottom:8px}.ph,.person .ph{overflow:hidden}.person .ph{aspect-ratio:4/5;border-radius:var(--r)}.person .ph img{width:100%;height:100%;object-fit:cover}\n"
            + ".person .ph.none{display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,hsl(var(--h),65%,60%),hsl(calc(var(--h) + 50),65%,42%))}.person .ph.none span{font:800 44px var(--fh);color:#fff;opacity:.9}\n"
            + ".team.round .person{text-align:center}.team.round .ph{width:min(180px,70%);aspect-ratio:1;border-radius:50%;margin:0 auto}\n"
            // контакты
            + ".citem{display:flex;gap:16px;align-items:flex-start}.cinfo:not(.grid) .citem{padding:16px 0;border-bottom:1px solid var(--border)}.clabel{font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--muted);margin-bottom:4px}\n"
            + ".contacts-cards .citem{flex-direction:column;gap:14px}.cval{font-size:17px;font-weight:600;overflow-wrap:anywhere}.cval a{color:var(--text);text-decoration:none}.cval a[target]{color:var(--primary);font-weight:600;font-size:15px}\n"
            + ".socials{display:flex;flex-wrap:wrap;gap:10px;margin-top:22px}.soc{display:inline-flex;align-items:center;min-height:42px;padding:0 18px;border-radius:999px;background:var(--soft);color:var(--primary);font-weight:700;font-size:15px;text-decoration:none}.soc:hover{background:var(--primary);color:var(--on-primary)}\n"
            + ".map{border-radius:var(--r);overflow:hidden;box-shadow:var(--shadow);min-height:360px;background:var(--surface)}.map iframe{width:100%;height:100%;min-height:420px;border:0;display:block}\n"
            + ".map-ph{height:100%;min-height:360px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;font-size:44px;text-align:center;padding:20px}.map-ph span{font-size:16px;font-weight:600}.map-ph small{font-size:13px;color:var(--muted)}\n"
            // форма
            + ".form-card-wrap .form{max-width:640px;margin:0 auto}.form h2{margin-bottom:.3em}.form .lead{margin-bottom:22px}.fld{display:block;margin:0 0 14px}.fld span{display:block;font-size:14px;font-weight:600;margin-bottom:6px;color:var(--muted)}\n"
            + ".fld input,.fld textarea{width:100%;font:inherit;color:var(--text);background:var(--bg);border:1.5px solid var(--border);border-radius:calc(var(--r-sm) + 4px);padding:14px 16px;outline:none;transition:border-color .15s,box-shadow .15s}\n"
            + ".fld input:focus,.fld textarea:focus{border-color:var(--primary);box-shadow:0 0 0 4px var(--soft)}.fld.bad input{border-color:#E5484D}.consent{font-size:13px;color:var(--muted);margin:14px 0 0}\n"
            + ".ok{margin-top:16px;padding:16px;border-radius:var(--r-sm);background:var(--soft);color:var(--text);font-weight:600;text-align:center}\n"
            + ".bg-primary .form,.bg-accent .form,.bg-image .form,.bg-custom .form{background:var(--page-card);color:var(--page-text);--text:var(--page-text);--muted:var(--page-muted);--border:var(--page-border);--primary:var(--brand);--on-primary:var(--brand-fg);--soft:var(--page-soft);--bg:var(--page-bg);box-shadow:var(--shadow)}\n"
            // видео
            + ".video{position:relative;aspect-ratio:16/9;border-radius:var(--r);overflow:hidden;background:#000;box-shadow:var(--shadow)}.video iframe{position:absolute;inset:0;width:100%;height:100%;border:0}\n"
            + ".vph{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;color:#fff;font-size:54px;text-decoration:none;background:linear-gradient(135deg,var(--dark),color-mix(in srgb,var(--primary) 40%,var(--dark)))}.vph span{font-size:15px;font-weight:600;opacity:.85}\n"
            // записи
            + ".post{display:flex;flex-direction:column;color:inherit;text-decoration:none;transition:transform .2s,box-shadow .2s}.post.card{padding:0;overflow:hidden}.post:hover{transform:translateY(-4px);box-shadow:var(--shadow)}.post .cover{aspect-ratio:16/10;overflow:hidden}.post .cover img{width:100%;height:100%;object-fit:cover}\n"
            + ".post-t{padding:20px 22px 24px;flex:1;display:flex;flex-direction:column}.post-t .more{margin-top:auto;padding-top:12px;align-self:flex-start}.post time,.post-head time{display:block;font-size:14px;color:var(--muted);margin-bottom:8px}.post h3{margin-bottom:8px}\n"
            + ".ph-grad{width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,hsl(var(--h),70%,62%),hsl(calc(var(--h) + 60),70%,45%))}.ph-grad span{font:800 48px var(--fh);color:#fff;opacity:.85}\n"
            + ".post-list{max-width:820px;margin:0 auto}.post-list .post{border-bottom:1px solid var(--border)}.post-list .post:hover{transform:none;box-shadow:none}.post-list .post-t{padding:22px 0}\n"
            + ".post-head{padding-bottom:0}.post-head+.sec{padding-top:36px}.post-head .back{display:inline-block;margin-bottom:22px;font-weight:600;text-decoration:none}.post-head h1{font-size:clamp(34px,5vw,58px)}.post-cover{margin-top:36px;border-radius:var(--r);overflow:hidden}.post-cover img{width:100%}\n"
            // разделитель и свой код
            + ".dv-s{height:24px}.dv-m{height:56px}.dv-l{height:110px}.dv{display:flex;align-items:center;justify-content:center}.dv hr{width:100%;border:0;border-top:1px solid var(--border);margin:0}.dv span{color:var(--muted);letter-spacing:8px}\n"
            // подвал
            + ".ftr{padding:clamp(48px,6vw,72px) 0 28px;color:var(--text)}.ftr-cols{display:grid;grid-template-columns:2fr 1fr 1fr;gap:40px}.ftr .logo{display:block;margin-bottom:12px}.fh{font-size:13px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-bottom:14px}\n"
            + ".fnav{display:flex;flex-wrap:wrap;gap:8px 22px}.fnav.col{flex-direction:column;gap:10px}.fnav a{color:var(--text);text-decoration:none;opacity:.85}.fnav a:hover{opacity:1;color:var(--primary)}\n"
            + ".ftr-row{display:flex;align-items:center;gap:28px;flex-wrap:wrap}.ftr-row .logo{margin:0 auto 0 0}.ftr-row .socials{margin:0}\n"
            + ".ftr-bottom{position:relative;display:flex;justify-content:space-between;gap:20px;flex-wrap:wrap;margin-top:44px;padding-top:22px;font-size:14px;color:var(--muted)}.ftr-bottom::before{content:'';position:absolute;top:0;left:22px;right:22px;border-top:1px solid var(--border)}.ftr-bottom .small{max-width:640px}\n"
            // адаптивность
            + ".only-mobile{display:none}\n"
            + "@media (max-width:900px){.grid{grid-template-columns:repeat(min(var(--cols,3),2),minmax(0,1fr))}.gal{grid-template-columns:repeat(min(var(--cols,3),2),minmax(0,1fr))}.gv-masonry{columns:2}\n"
            + ".split,.faq-split{grid-template-columns:1fr}.it-right .it-img{order:0}.ftr-cols{grid-template-columns:1fr 1fr}.ftr-cols .fc-about{grid-column:1/-1}.tv-two .body{columns:1}\n"
            + ".cta-card{flex-direction:column;align-items:flex-start}.hero-img .pic,.hero-img .ph{aspect-ratio:4/3!important}.price.featured{transform:none}.only-mobile{display:block}.only-desktop{display:none}\n"
            + ".burger{display:flex}.nav{position:absolute;top:100%;left:0;right:0;flex-direction:column;align-items:stretch;gap:2px;padding:12px 16px 20px;background:var(--bg);border-bottom:1px solid var(--border);box-shadow:var(--shadow);display:none;--text:" + "inherit}\n"
            + ".menu-open .nav{display:flex}.nav a:not(.btn){padding:14px 12px;font-size:17px;color:var(--text)}.nav-btn{margin:8px 0 0}.hdr.v-center .hdr-in{flex-direction:row;padding:0 22px;min-height:74px}.hdr.v-center .logo{margin:0 auto 0 0}\n"
            + ".hdr.light.menu-open{--text:inherit}.hdr.over.menu-open{background:var(--bg)}}\n"
            + "@media (max-width:600px){body{font-size:16px}.grid,.gal{grid-template-columns:1fr}.reviews,.team{grid-template-columns:1fr}.stats{grid-template-columns:repeat(2,minmax(0,1fr))}.stats.n3{grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.stats.n3 .big{font-size:clamp(26px,8.5vw,40px)}.stats.n3 .card{padding:18px 8px}.stats.n1{grid-template-columns:1fr}.gv-masonry{columns:2;column-gap:10px}.gv-masonry figure{margin-bottom:10px}.gal{gap:10px}\n"
            + ".team.round{grid-template-columns:repeat(2,minmax(0,1fr))}.ftr-cols{grid-template-columns:1fr}.btns .btn{flex:1 1 auto}.hdr .nav-btn{width:100%}.container{padding:0 18px}.ftr-bottom::before{left:18px;right:18px}.ans{padding-right:0}.pl-name{font-size:16px}}\n";

    /** Скрипт готового сайта: меню, прозрачная шапка, появление блоков, галерея на весь экран, отзывы, форма. */
    static String js() {
        return JS;
    }

    private static final String JS = ""
            + "(function(){var d=document,w=window;\n"
            + "var hdr=d.querySelector('.hdr'),bg=d.querySelector('.burger');\n"
            + "if(bg&&hdr){bg.addEventListener('click',function(){var o=hdr.classList.toggle('menu-open');bg.setAttribute('aria-expanded',o)});"
            + "hdr.querySelectorAll('.nav a').forEach(function(a){a.addEventListener('click',function(){hdr.classList.remove('menu-open')})})}\n"
            + "if(hdr&&hdr.classList.contains('over')){var sc=function(){hdr.classList.toggle('scrolled',w.scrollY>30)};sc();w.addEventListener('scroll',sc,{passive:true})}\n"
            + "var rv=d.querySelectorAll('.reveal');if('IntersectionObserver' in w&&!d.body.classList.contains('edit')){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{rootMargin:'0px 0px -8% 0px'});"
            + "rv.forEach(function(el,i){el.style.transitionDelay=(i%4*70)+'ms';io.observe(el)})}else rv.forEach(function(el){el.classList.add('in')})\n"
            // галерея
            + "d.querySelectorAll('[data-lightbox]').forEach(function(g){var ls=[].slice.call(g.querySelectorAll('a.lb'));ls.forEach(function(a,i){a.addEventListener('click',function(e){e.preventDefault();open(ls,i)})})});\n"
            + "function open(ls,i){var b=d.createElement('div');b.className='lbox';b.innerHTML='<img alt=\"\"><p></p><button class=\"x\" aria-label=\"Закрыть\">✕</button><button class=\"pv\" aria-label=\"Назад\">‹</button><button class=\"nx\" aria-label=\"Дальше\">›</button>';"
            + "d.body.appendChild(b);var im=b.querySelector('img'),p=b.querySelector('p');function show(k){i=(k+ls.length)%ls.length;im.src=ls[i].getAttribute('href');p.textContent=ls[i].getAttribute('data-cap')||''}"
            + "show(i);requestAnimationFrame(function(){b.classList.add('on')});function close(){b.remove();d.removeEventListener('keydown',key)}"
            + "function key(e){if(e.key==='Escape')close();if(e.key==='ArrowLeft')show(i-1);if(e.key==='ArrowRight')show(i+1)}d.addEventListener('keydown',key);"
            + "b.querySelector('.x').onclick=close;b.querySelector('.pv').onclick=function(e){e.stopPropagation();show(i-1)};b.querySelector('.nx').onclick=function(e){e.stopPropagation();show(i+1)};"
            + "b.addEventListener('click',function(e){if(e.target===b)close()});var sx=null;b.addEventListener('touchstart',function(e){sx=e.touches[0].clientX},{passive:true});"
            + "b.addEventListener('touchend',function(e){if(sx===null)return;var dx=e.changedTouches[0].clientX-sx;if(Math.abs(dx)>50)show(i+(dx<0?1:-1));sx=null})}\n"
            // отзывы-карусель
            + "d.querySelectorAll('.t-reviews').forEach(function(s){var q=s.querySelector('.quotes');if(!q)return;var go=function(k){q.scrollBy({left:k*q.clientWidth,behavior:'smooth'})};"
            + "var p=s.querySelector('.q-prev'),n=s.querySelector('.q-next');if(p)p.onclick=function(){go(-1)};if(n)n.onclick=function(){go(1)}});\n"
            // форма
            + "d.querySelectorAll('form.form').forEach(function(f){f.addEventListener('submit',function(e){e.preventDefault();var ok=true;"
            + "f.querySelectorAll('[required]').forEach(function(el){var bad=!el.value.trim()||(el.type==='email'&&!/.+@.+\\..+/.test(el.value));el.parentNode.classList.toggle('bad',bad);if(bad)ok=false});if(!ok)return;"
            + "var data=new FormData(f),lines=[];data.forEach(function(v,k){var l=f.querySelector('[name=\"'+k+'\"]');var t=l?l.parentNode.querySelector('span').textContent.replace(' *',''):k;lines.push(t+': '+v)});"
            + "var done=function(){f.querySelector('.ok').hidden=false;f.querySelectorAll('input,textarea').forEach(function(el){el.value=''})};"
            + "if(f.dataset.mode==='url'){fetch(f.dataset.to,{method:'POST',body:data,headers:{Accept:'application/json'}}).then(function(r){if(r.ok)done();else alert('Не удалось отправить, попробуйте ещё раз')}).catch(function(){alert('Нет связи, попробуйте ещё раз')})}"
            + "else{location.href='mailto:'+encodeURIComponent(f.dataset.to)+'?subject='+encodeURIComponent(f.dataset.subject)+'&body='+encodeURIComponent(lines.join('\\n'));done()}})});\n"
            + "})();\n";

    // ------------------------------------------------------------------ редактор (только предпросмотр)

    private static final String EDIT_CSS = ""
            + "html{scroll-behavior:auto!important}[data-block]{cursor:pointer;transition:outline-color .15s}[data-block]:hover{outline:2px dashed rgba(255,45,149,.45);outline-offset:-2px}\n"
            + "[data-block].sel{outline:3px solid #FF2D95;outline-offset:-3px}.is-hidden{opacity:.38}.edit-badge{position:absolute;top:10px;left:10px;z-index:5;background:#FF2D95;color:#fff;font:700 12px/1 system-ui;padding:6px 10px;border-radius:999px}\n"
            + ".edit-note{font:600 13px system-ui;color:#888;text-align:center;margin-top:8px}.hdr.sticky,.hdr.over.sticky{position:sticky}.hdr.over{position:absolute}\n"
            + ".empty-page{text-align:center;color:var(--muted);padding:120px 0}.js .reveal{opacity:1!important;transform:none!important}\n";

    private static final String EDIT_JS = ""
            + "(function(){var d=document;function pick(e){var b=e.target.closest('[data-block]');if(!b)return;e.preventDefault();e.stopPropagation();"
            + "d.querySelectorAll('.sel').forEach(function(x){x.classList.remove('sel')});b.classList.add('sel');if(window.NeonEdit)NeonEdit.select(b.getAttribute('data-block'))}\n"
            + "d.addEventListener('click',function(e){var a=e.target.closest('a,button,summary,input,textarea,label');if(a&&a.tagName==='SUMMARY')return;if(a&&a.classList.contains('burger'))return;if(a)e.preventDefault();pick(e)},true);\n"
            + "d.addEventListener('submit',function(e){e.preventDefault()},true);\n"
            + "window.neonSelect=function(id,scroll){d.querySelectorAll('.sel').forEach(function(x){x.classList.remove('sel')});var b=d.querySelector('[data-block=\"'+id+'\"]');"
            + "if(b){b.classList.add('sel');if(scroll)b.scrollIntoView({block:'center',behavior:'smooth'})}};\n"
            + "window.neonScroll=function(y){window.scrollTo(0,y)};window.neonY=function(){return window.scrollY};\n"
            // замена содержимого без перезагрузки: страница не мигает и остаётся на месте
            + "window.neonSwap=function(h){var n=new DOMParser().parseFromString(h,'text/html'),y=window.scrollY;"
            + "var os=d.querySelector('head style'),ns=n.querySelector('head style');if(os&&ns&&os.textContent!==ns.textContent)os.textContent=ns.textContent;"
            + "var ol=d.querySelector('link[data-fonts]'),nl=n.querySelector('link[data-fonts]');"
            + "if(nl&&(!ol||ol.getAttribute('href')!==nl.getAttribute('href'))){if(ol)ol.remove();var l=d.createElement('link');l.rel='stylesheet';l.setAttribute('data-fonts','');l.href=nl.getAttribute('href');d.head.appendChild(l)}else if(!nl&&ol)ol.remove();"
            + "n.body.querySelectorAll('script').forEach(function(x){x.remove()});d.body.className=n.body.className;d.body.innerHTML=n.body.innerHTML;"
            + "try{if(window.neonSiteInit)neonSiteInit()}catch(e){}var sel=n.documentElement.getAttribute('data-sel');if(sel)neonSelect(sel,false);window.scrollTo({top:y,behavior:'instant'})};\n"
            + "})();\n";

    // ================================================================== каталог блоков и шаблонов

    /** Общая обёртка для галерей с миниатюрами: каждая миниатюра — настоящая страница 1280px в iframe, уменьшенная под ширину карточки. */
    private static final String THUMB_CSS = ""
            + "*{box-sizing:border-box}body{margin:0;background:#0A0812;font-family:system-ui,-apple-system,sans-serif;padding:12px;color:#F2EEFF}"
            + ".t{background:#15111F;border-radius:18px;overflow:hidden;margin-bottom:14px;cursor:pointer;border:2px solid #241D35;-webkit-tap-highlight-color:transparent;transition:border-color .15s}"
            + ".t:active,.t.on{border-color:#FF2D95}.fr{position:relative;overflow:hidden;background:#fff;height:220px}"
            + ".fr iframe{position:absolute;left:0;top:0;width:1280px;height:900px;border:0;transform-origin:0 0;pointer-events:none}"
            + ".tt{display:flex;align-items:center;gap:10px;padding:12px 14px}.tt .n{flex:1;min-width:0}.tt b{font-size:16px;display:block}.tt span{color:#9A91B8;font-size:13px;display:block;margin-top:2px}"
            + ".tt i{font-style:normal;flex:none;width:34px;height:34px;border-radius:50%;background:#FF2D95;color:#fff;display:flex;align-items:center;justify-content:center;font-size:22px;line-height:1}"
            + ".grp{font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:#9A91B8;margin:18px 4px 10px;font-weight:700}.grp:first-child{margin-top:4px}";

    private static final String THUMB_JS = ""
            + "(function(){function fit(f){var w=f.parentNode.clientWidth,k=w/1280;f.style.transform='scale('+k+')';"
            + "try{var d=f.contentDocument,h=Math.max(200,Math.min(Math.ceil(d.body.getBoundingClientRect().height),f.dataset.max?+f.dataset.max:1000));f.style.height=h+'px';f.parentNode.style.height=Math.round(h*k)+'px'}catch(e){}}"
            + "var fs=document.querySelectorAll('.fr iframe');fs.forEach(function(f){f.addEventListener('load',function(){fit(f);setTimeout(function(){fit(f)},400)});fit(f)});"
            + "window.addEventListener('resize',function(){fs.forEach(fit)})})();";

    /** Страница «Добавить блок»: все блоки и варианты в цветах сайта, нажатие — добавить. */
    static String catalog(Site s) {
        Site demo = s.copy();
        demo.pages.clear();
        Site.Page p = new Site.Page();
        p.noHeader = true;
        p.noFooter = true;
        demo.pages.add(p);
        StringBuilder sb = new StringBuilder("<!DOCTYPE html><html lang=\"ru\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><style>")
                .append(THUMB_CSS).append("</style></head><body>");
        Opt o = preview("", 1280);
        for (Blocks.Type t : Blocks.addable()) {
            if (t.id.equals("posts") && s.posts().isEmpty()) {
                // без записей блок «Записи» нечего показать — покажем подсказку текстом
                sb.append("<div class=\"grp\">").append(esc(t.name)).append("</div>");
                sb.append("<div class=\"t\" data-type=\"posts\" data-variant=\"").append(t.variants[0]).append("\"><div class=\"tt\"><div class=\"n\"><b>").append(esc(t.name))
                        .append("</b><span>").append(esc(t.desc)).append(". Сначала добавьте страницу-запись в «Страницах».</span></div><i>+</i></div></div>");
                continue;
            }
            sb.append("<div class=\"grp\">").append(esc(t.name)).append("</div>");
            for (int i = 0; i < t.variants.length; i++) {
                Site.Block b = Blocks.make(t.id, t.variants[i]);
                if (t.id.equals("posts")) demo.pages.addAll(s.posts());
                p.blocks.clear();
                p.blocks.add(b);
                String html = page(demo, p, o);
                if (t.id.equals("posts")) demo.pages.retainAll(java.util.Collections.singletonList(p));
                sb.append("<div class=\"t\" data-type=\"").append(t.id).append("\" data-variant=\"").append(t.variants[i]).append("\"><div class=\"fr\"><iframe loading=\"lazy\" data-max=\"1100\" srcdoc=\"")
                        .append(esc(html)).append("\"></iframe></div><div class=\"tt\"><div class=\"n\"><b>").append(esc(t.variantNames[i])).append("</b><span>").append(esc(t.desc))
                        .append("</span></div><i>+</i></div></div>\n");
            }
        }
        sb.append("<script>").append(THUMB_JS)
                .append("document.querySelectorAll('.t').forEach(function(c){c.addEventListener('click',function(){c.classList.add('on');if(window.NeonEdit)NeonEdit.add(c.dataset.type,c.dataset.variant)})})</script></body></html>");
        return sb.toString();
    }

    /** Галерея шаблонов: главная каждого шаблона в уменьшенном виде. */
    static String templates() {
        StringBuilder sb = new StringBuilder("<!DOCTYPE html><html lang=\"ru\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><style>")
                .append(THUMB_CSS).append(".fr{height:300px}</style></head><body>");
        for (int i = 0; i < Templates.IDS.length; i++) {
            Site s = Templates.make(Templates.IDS[i]);
            Opt o = preview("", 1280);
            String html = page(s, s.home(), o);
            sb.append("<div class=\"t\" data-id=\"").append(Templates.IDS[i]).append("\"><div class=\"fr\"><iframe loading=\"lazy\" data-max=\"880\" srcdoc=\"").append(esc(html)).append("\"></iframe></div>")
                    .append("<div class=\"tt\"><div class=\"n\"><b>").append(esc(Templates.NAMES[i])).append("</b><span>").append(esc(Templates.DESCS[i])).append("</span></div><i>→</i></div></div>\n");
        }
        sb.append("<script>").append(THUMB_JS)
                .append("document.querySelectorAll('.t').forEach(function(t){t.addEventListener('click',function(){t.classList.add('on');if(window.NeonEdit)NeonEdit.template(t.dataset.id)})})</script></body></html>");
        return sb.toString();
    }
}
