package com.neondrift.site;

import android.webkit.WebView;

/** «Добавить блок»: все блоки и их варианты — настоящие миниатюры в цветах вашего сайта. */
final class CatalogScreen extends Screen implements Web.Bridge {
    interface Add {
        void add(String type, String variant);
    }

    private final WebView web;
    private final Add done;
    private boolean picked;

    CatalogScreen(MainActivity a, Add done) {
        super(a);
        this.done = done;
        header("Добавить блок", "Нажмите на вариант — он появится после выбранного блока");
        web = Web.make(a, this);
        web.setWebViewClient(new Web.Client(a, false));
        web.getSettings().setBuiltInZoomControls(false);
        web.getSettings().setSupportZoom(false);
        addView(web, Ui.lp(Ui.MATCH, 0, 1f));
        web.loadDataWithBaseURL(Web.BASE, Gen.catalog(hub.site), "text/html", "utf-8", null);
    }

    @Override
    public void add(String type, String variant) {
        if (picked) return;
        picked = true;
        done.add(type, variant);
        a.back();
    }

    @Override
    public void select(String blockId) {
    }

    @Override
    public void template(String id) {
    }

    @Override
    void onRemoved() {
        web.destroy();
    }
}
