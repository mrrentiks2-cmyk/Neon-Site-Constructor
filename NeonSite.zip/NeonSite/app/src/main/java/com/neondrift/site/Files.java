package com.neondrift.site;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/** Отдаёт готовые архивы другим приложениям («Поделиться», «Открыть») — только чтение и только папку out/. */
public class Files extends ContentProvider {
    static final String AUTH = "com.neondrift.site.files";

    static File outDir(Context c) {
        File d = new File(c.getCacheDir(), "out");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    static Uri uri(Context c, File f) {
        return Uri.parse("content://" + AUTH + "/out/" + Uri.encode(f.getName()));
    }

    private File file(Uri u) throws FileNotFoundException {
        Context c = getContext();
        if (c == null || u.getPath() == null) throw new FileNotFoundException();
        String path = u.getPath();
        if (!path.startsWith("/out/")) throw new FileNotFoundException(path);
        File base = outDir(c), f = new File(base, path.substring(5));
        try {
            if (!f.getCanonicalPath().startsWith(base.getCanonicalPath() + File.separator)) throw new FileNotFoundException("вне папки");
        } catch (IOException e) {
            throw new FileNotFoundException(e.getMessage());
        }
        if (!f.isFile()) throw new FileNotFoundException(path);
        return f;
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        return ParcelFileDescriptor.open(file(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public String getType(Uri uri) {
        String p = uri.getPath() == null ? "" : uri.getPath().toLowerCase(java.util.Locale.ROOT);
        if (p.endsWith(".zip")) return "application/zip";
        if (p.endsWith(".md") || p.endsWith(".txt")) return "text/plain";
        if (p.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        File f;
        try {
            f = file(uri);
        } catch (FileNotFoundException e) {
            return null;
        }
        String[] cols = projection == null ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
        MatrixCursor c = new MatrixCursor(cols);
        Object[] row = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i] = f.getName();
            else if (OpenableColumns.SIZE.equals(cols[i])) row[i] = f.length();
        }
        c.addRow(row);
        return c;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] args) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] args) {
        return 0;
    }
}
