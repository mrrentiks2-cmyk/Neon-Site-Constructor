package com.neondrift.site;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import java.io.File;
import java.util.function.Consumer;

/** Поля форм в стиле приложения: подписи, ввод текста, переключатели, выбор из вариантов, фото, ссылки, цвета. */
final class Form {
    final MainActivity a;
    final Ui ui;
    LinearLayout root;
    /** Вызывается после любого изменения (сохранить, обновить предпросмотр). */
    final Runnable changed;
    /** Подпись у пустого поля картинки. */
    String emptyImage = "Фото не выбрано — будет заглушка";

    Form(MainActivity a, LinearLayout root, Runnable changed) {
        this.a = a;
        this.ui = a.ui;
        this.root = root;
        this.changed = changed;
    }

    void section(String label) {
        root.addView(ui.label(label), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(2), ui.dp(22), 0, ui.dp(10)));
    }

    TextView note(String text) {
        TextView t = ui.text(text, 12.5f, Theme.MUTED, false);
        t.setLineSpacing(0, 1.25f);
        root.addView(t, Ui.margins(Ui.MATCH, Ui.WRAP, ui.dp(2), 0, 0, ui.dp(10)));
        return t;
    }

    private void caption(String label, String hint) {
        if (label != null && !label.isEmpty())
            root.addView(ui.text(label, 13.5f, 0xFFCFC8E6, true), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(2), ui.dp(4), 0, ui.dp(6)));
        if (hint != null && !hint.isEmpty()) {
            TextView h = ui.text(hint, 12, Theme.MUTED, false);
            h.setLineSpacing(0, 1.2f);
            root.addView(h, Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(2), ui.dp(-2), 0, ui.dp(6)));
        }
    }

    // ------------------------------------------------------------------ текст

    EditText text(String label, String hint, String value, boolean multi, Consumer<String> set) {
        caption(label, null);
        EditText e = a.field(value, hint, multi);
        if (multi) e.setMaxLines(14);
        e.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {
            }

            @Override
            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                set.accept(s.toString());
                changed.run();
            }
        });
        root.addView(e, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(12)));
        return e;
    }

    EditText code(String label, String hint, String value, Consumer<String> set) {
        EditText e = text(label, hint, value, true, set);
        e.setTypeface(Typeface.MONOSPACE);
        e.setTextSize(13);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setHorizontallyScrolling(false);
        return e;
    }

    // ------------------------------------------------------------------ варианты

    /** Чипы «один из». */
    void choice(String label, String[] ids, String[] names, String value, Consumer<String> set) {
        caption(label, null);
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = ui.row();
        hs.addView(row);
        TextView[] cs = new TextView[ids.length];
        for (int i = 0; i < ids.length; i++) {
            int k = i;
            cs[i] = ui.chip(names[i], ids[i].equals(value), v -> {
                for (int q = 0; q < cs.length; q++) ui.styleChip(cs[q], q == k);
                set.accept(ids[k]);
                changed.run();
            });
            LinearLayout.LayoutParams lp = Ui.lp(Ui.WRAP, Ui.WRAP);
            lp.rightMargin = ui.dp(8);
            row.addView(cs[i], lp);
        }
        root.addView(hs, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(12)));
    }

    /** Переключатель с подписью. */
    Switch bool(String label, String sub, boolean value, Consumer<Boolean> set) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(14), ui.dp(10), ui.dp(8), ui.dp(10));
        row.setBackground(Ui.round(Theme.SURFACE, ui.dp(14)));
        LinearLayout t = ui.col();
        TextView l = ui.text(label, 15, Theme.TEXT, false);
        t.addView(l);
        if (sub != null && !sub.isEmpty()) {
            TextView s = ui.text(sub, 12, Theme.MUTED, false);
            s.setLineSpacing(0, 1.15f);
            t.addView(s, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(3), 0, 0));
        }
        row.addView(t, Ui.lp(0, Ui.WRAP, 1f));
        Switch sw = new Switch(a);
        sw.setChecked(value);
        sw.setOnCheckedChangeListener((b, on) -> {
            set.accept(on);
            changed.run();
        });
        row.addView(sw);
        row.setOnClickListener(v -> sw.toggle());
        root.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(8)));
        return sw;
    }

    /** Число «− n +». */
    void num(String label, int value, int min, int max, Consumer<Integer> set) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(14), ui.dp(4), ui.dp(4), ui.dp(4));
        row.setBackground(Ui.round(Theme.SURFACE, ui.dp(14)));
        row.addView(ui.text(label, 15, Theme.TEXT, false), Ui.lp(0, Ui.WRAP, 1f));
        int[] v = {Math.max(min, Math.min(max, value))};
        TextView tv = ui.text(String.valueOf(v[0]), 16, Theme.TEXT, true);
        tv.setGravity(Gravity.CENTER);
        int step = max - min > 40 ? 5 : 1;
        ImageView minus = ui.iconButton("minus", Theme.TEXT, 42, 12, x -> {
            v[0] = Math.max(min, v[0] - step);
            tv.setText(String.valueOf(v[0]));
            set.accept(v[0]);
            changed.run();
        });
        ImageView plus = ui.iconButton("plus", Theme.TEXT, 42, 12, x -> {
            v[0] = Math.min(max, v[0] + step);
            tv.setText(String.valueOf(v[0]));
            set.accept(v[0]);
            changed.run();
        });
        row.addView(minus);
        row.addView(tv, Ui.lp(ui.dp(56), Ui.WRAP));
        row.addView(plus);
        root.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(8)));
    }

    // ------------------------------------------------------------------ фото

    /** Фото: миниатюра, «Выбрать», «Убрать». maxSide — ограничение размера (логотипы, значки), 0 — обычное. */
    void image(String label, String hint, String value, int maxSide, Consumer<String> set) {
        caption(label, hint);
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(8), ui.dp(8), ui.dp(8), ui.dp(8));
        row.setBackground(Ui.round(Theme.SURFACE, ui.dp(14)));
        ImageView th = new ImageView(a);
        th.setScaleType(ImageView.ScaleType.CENTER_CROP);
        th.setClipToOutline(true);
        th.setOutlineProvider(Ui.rounded(ui.dp(10)));
        row.addView(th, Ui.lp(ui.dp(64), ui.dp(64)));
        LinearLayout col = ui.col();
        TextView name = ui.oneLine("", 13, Theme.MUTED, false);
        col.addView(name);
        LinearLayout btns = ui.row();
        TextView pick = ui.chip("", false, null);
        TextView clear = ui.chip("Убрать", false, null);
        btns.addView(pick);
        LinearLayout.LayoutParams lp = Ui.lp(Ui.WRAP, Ui.WRAP);
        lp.leftMargin = ui.dp(8);
        btns.addView(clear, lp);
        col.addView(btns, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(8), 0, 0));
        row.addView(col, Ui.margins(0, Ui.WRAP, ui.dp(12), 0, 0, 0));
        ((LinearLayout.LayoutParams) col.getLayoutParams()).weight = 1f;
        String[] cur = {value == null ? "" : value};
        Runnable show = () -> {
            boolean has = !cur[0].isEmpty();
            pick.setText(has ? "Заменить" : "Выбрать фото");
            clear.setVisibility(has ? View.VISIBLE : View.GONE);
            name.setText(has ? cur[0].replaceFirst("^img/", "") : emptyImage);
            thumb(th, cur[0]);
        };
        show.run();
        pick.setOnClickListener(v -> a.pickImages(false, uris -> a.importImages(uris, maxSide, path -> {
            cur[0] = path;
            set.accept(path);
            show.run();
            changed.run();
        }, null)));
        clear.setOnClickListener(v -> {
            cur[0] = "";
            set.accept("");
            show.run();
            changed.run();
        });
        root.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(12)));
    }

    /** Миниатюра картинки проекта (в фоне). */
    void thumb(ImageView iv, String path) {
        iv.setImageDrawable(null);
        iv.setBackground(Ui.round(Theme.SURFACE2, ui.dp(10)));
        if (path == null || path.isEmpty() || a.hub.site == null) {
            iv.setImageDrawable(new Glyph("image", Theme.MUTED));
            iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            iv.setPadding(ui.dp(18), ui.dp(18), ui.dp(18), ui.dp(18));
            return;
        }
        iv.setPadding(0, 0, 0, 0);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        File f = new File(a.hub.dir(), path);
        int px = ui.dp(72);
        Bitmap b = Images.cached(f, px);
        if (b != null) {
            iv.setImageBitmap(b);
            return;
        }
        iv.setTag(path);
        a.hub.io.execute(() -> {
            Bitmap bm = Images.thumb(f, px);
            a.runOnUiThread(() -> {
                if (path.equals(iv.getTag())) {
                    if (bm != null) iv.setImageBitmap(bm);
                    else iv.setImageDrawable(new Glyph("noImage", Theme.MUTED));
                }
            });
        });
    }

    // ------------------------------------------------------------------ ссылка, цвет, значок

    void link(String label, String value, Site.Page page, Consumer<String> set) {
        caption(label, null);
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(14), ui.dp(10), ui.dp(8), ui.dp(10));
        row.setBackground(Ui.ripple(Ui.stroke(Theme.SURFACE2, Theme.LINE, ui.dp(1), ui.dp(12)), Ui.round(0xFFFFFFFF, ui.dp(12))));
        ImageView ic = new ImageView(a);
        ic.setImageDrawable(new Glyph("link", Theme.ACCENT));
        row.addView(ic, Ui.lp(ui.dp(20), ui.dp(20)));
        TextView t = ui.text(Pickers.describe(a.hub.site, value), 14.5f, Theme.TEXT, false);
        t.setMaxLines(2);
        row.addView(t, Ui.margins(0, Ui.WRAP, ui.dp(10), 0, 0, 0));
        ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        row.addView(ui.text("Изменить", 13, Theme.ACCENT, true));
        String[] cur = {value == null ? "" : value};
        row.setOnClickListener(v -> Pickers.link(a, a.hub.site, page, cur[0], nv -> {
            cur[0] = nv;
            set.accept(nv);
            t.setText(Pickers.describe(a.hub.site, nv));
            changed.run();
        }));
        root.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(12)));
    }

    void color(String label, String value, Consumer<String> set) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(14), ui.dp(8), ui.dp(10), ui.dp(8));
        row.setBackground(Ui.ripple(Ui.round(Theme.SURFACE, ui.dp(14)), Ui.round(0xFFFFFFFF, ui.dp(14))));
        row.addView(ui.text(label, 15, Theme.TEXT, false), Ui.lp(0, Ui.WRAP, 1f));
        TextView hex = ui.text(value, 13, Theme.MUTED, false);
        row.addView(hex);
        View sw = new View(a);
        sw.setBackground(Ui.stroke(parse(value), 0x55FFFFFF, ui.dp(1), ui.dp(10)));
        LinearLayout.LayoutParams lp = Ui.lp(ui.dp(36), ui.dp(36));
        lp.leftMargin = ui.dp(10);
        row.addView(sw, lp);
        String[] cur = {value};
        row.setOnClickListener(v -> Pickers.color(a, a.hub.site, cur[0], nv -> {
            cur[0] = nv;
            hex.setText(nv);
            sw.setBackground(Ui.stroke(parse(nv), 0x55FFFFFF, ui.dp(1), ui.dp(10)));
            set.accept(nv);
            changed.run();
        }));
        root.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(8)));
    }

    void icon(String label, String value, Consumer<String> set) {
        caption(label, null);
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = ui.row();
        hs.addView(row);
        java.util.List<TextView> all = new java.util.ArrayList<>();
        String[] cur = {value == null ? "" : value};
        Runnable style = () -> {
            for (TextView t : all) {
                boolean on = t.getTag().equals(cur[0]);
                t.setBackground(Ui.stroke(on ? Theme.alpha(Theme.ACCENT, 60) : Theme.SURFACE2, on ? Theme.ACCENT : Theme.LINE, ui.dp(1), ui.dp(12)));
            }
        };
        TextView none = ui.text("—", 18, Theme.MUTED, true);
        none.setTag("");
        all.add(none);
        for (String ic : Blocks.ICONS) {
            TextView t = ui.text(ic, 22, Theme.TEXT, false);
            t.setTag(ic);
            all.add(t);
        }
        for (TextView t : all) {
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> {
                cur[0] = (String) v.getTag();
                set.accept(cur[0]);
                style.run();
                changed.run();
            });
            LinearLayout.LayoutParams lp = Ui.lp(ui.dp(46), ui.dp(46));
            lp.rightMargin = ui.dp(6);
            row.addView(t, lp);
        }
        // свой значок — любой эмодзи с клавиатуры
        if (!cur[0].isEmpty() && !java.util.Arrays.asList(Blocks.ICONS).contains(cur[0])) {
            TextView t = ui.text(cur[0], 22, Theme.TEXT, false);
            t.setTag(cur[0]);
            t.setGravity(Gravity.CENTER);
            all.add(1, t);
            LinearLayout.LayoutParams lp = Ui.lp(ui.dp(46), ui.dp(46));
            lp.rightMargin = ui.dp(6);
            row.addView(t, 1, lp);
        }
        TextView own = ui.chip("Свой…", false, v -> a.ask("Свой значок", "Любой эмодзи или 1–2 символа", cur[0], "Готово", s -> {
            String x = s.length() > 4 ? s.substring(0, 4) : s;
            cur[0] = x;
            set.accept(x);
            changed.run();
            if (a.top() instanceof BlockScreen) ((BlockScreen) a.top()).rebuild();
        }));
        row.addView(own);
        style.run();
        root.addView(hs, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(12)));
    }

    static int parse(String hex) {
        try {
            return Color.parseColor(hex == null || hex.isEmpty() ? "#000000" : hex.trim());
        } catch (Exception e) {
            return 0xFF888888;
        }
    }

    TextView button(String text, boolean primary, View.OnClickListener l) {
        TextView b = ui.button(text, primary, l);
        root.addView(b, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(4), 0, ui.dp(10)));
        return b;
    }
}
