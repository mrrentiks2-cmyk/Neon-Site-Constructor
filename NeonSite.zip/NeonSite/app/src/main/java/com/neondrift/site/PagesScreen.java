package com.neondrift.site;

import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Страницы сайта: порядок (первая — главная), добавление, настройки, удаление. */
final class PagesScreen extends Screen {
    private final EditorScreen ed;
    private final LinearLayout list;

    PagesScreen(MainActivity a, EditorScreen ed) {
        super(a);
        this.ed = ed;
        header("Страницы", "Первая в списке — главная (index.html)");
        ScrollView sv = new ScrollView(a);
        list = ui.col();
        list.setPadding(ui.dp(16), ui.dp(6), ui.dp(16), ui.dp(40));
        sv.addView(list);
        addView(sv, Ui.lp(Ui.MATCH, 0, 1f));
    }

    @Override
    void refresh() {
        list.removeAllViews();
        Site s = hub.site;
        for (int i = 0; i < s.pages.size(); i++) list.addView(row(s, i), Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(8)));
        list.addView(ui.button("+ Новая страница", true, v -> addPage(a, ed)), Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(8), 0, 0));
        TextView n = ui.text("Нажмите на страницу, чтобы открыть её в редакторе. «⋯» — название, адрес, SEO, меню, копия, удаление. "
                + "Записи блога появляются в блоке «Записи блога» и не попадают в меню.", 12.5f, Theme.MUTED, false);
        n.setLineSpacing(0, 1.25f);
        list.addView(n, Ui.margins(Ui.MATCH, Ui.WRAP, ui.dp(2), ui.dp(14), 0, 0));
    }

    private View row(Site s, int i) {
        Site.Page p = s.pages.get(i);
        LinearLayout r = ui.row();
        r.setPadding(ui.dp(12), ui.dp(8), ui.dp(2), ui.dp(8));
        boolean cur = p == ed.page;
        r.setBackground(Ui.ripple(Ui.stroke(Theme.SURFACE, cur ? Theme.ACCENT : Theme.LINE, ui.dp(1), ui.dp(16)), Ui.round(0xFFFFFFFF, ui.dp(16))));
        TextView ic = ui.text(i == 0 ? "🏠" : p.post() ? "📝" : "📄", 18, Theme.TEXT, false);
        ic.setGravity(Gravity.CENTER);
        r.addView(ic, Ui.lp(ui.dp(32), ui.dp(32)));
        LinearLayout t = ui.col();
        t.addView(ui.oneLine(p.title, 15.5f, Theme.TEXT, true));
        String sub = s.file(p) + " · " + p.blocks.size() + " " + HomeScreen.plural(p.blocks.size(), "блок", "блока", "блоков")
                + (p.post() ? " · запись" + (p.date.isEmpty() ? "" : " от " + Gen.date(p.date)) : !p.menu ? " · не в меню" : "");
        t.addView(ui.oneLine(sub, 12, Theme.MUTED, false), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(3), 0, 0));
        r.addView(t, Ui.margins(0, Ui.WRAP, ui.dp(10), 0, 0, 0));
        ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        ImageView up = ui.iconButton("up", Theme.TEXT, 38, 10, v -> move(i, -1));
        up.setAlpha(i > 0 ? 0.9f : 0.25f);
        ImageView down = ui.iconButton("down", Theme.TEXT, 38, 10, v -> move(i, 1));
        down.setAlpha(i < s.pages.size() - 1 ? 0.9f : 0.25f);
        r.addView(up);
        r.addView(down);
        r.addView(ui.iconButton("more", Theme.TEXT, 40, 10, v -> a.push(new PageScreen(a, ed, p))));
        r.setOnClickListener(v -> {
            ed.showPage(p, null);
            a.back();
        });
        return r;
    }

    private void move(int i, int d) {
        Site s = hub.site;
        int j = i + d;
        if (j < 0 || j >= s.pages.size()) return;
        Site.Page p = s.pages.remove(i);
        s.pages.add(j, p);
        if (j == 0 || i == 0) a.toast("Главная теперь — «" + s.pages.get(0).title + "»");
        hub.saveSoon();
        refresh();
    }

    /** Новая страница: пустая, с обложкой и текстом, запись блога или копия текущей. */
    static void addPage(MainActivity a, EditorScreen ed) {
        SidePanel panel = a.panel;
        LinearLayout p = panel.open("Новая страница");
        panel.option(p, "Обложка и текст", "Заголовок страницы и пара абзацев — дальше добавите блоки", false, () -> create(a, ed, "start"));
        panel.option(p, "Пустая", "Только шапка и подвал", false, () -> create(a, ed, "empty"));
        panel.option(p, "Контакты", "Адрес, телефон, карта и форма заявки", false, () -> create(a, ed, "contacts"));
        panel.option(p, "Запись блога", "С датой, обложкой и анонсом — появится в блоке «Записи блога»", false, () -> create(a, ed, "post"));
        panel.option(p, "Копия текущей страницы", "«" + ed.page.title + "» со всеми блоками", false, () -> create(a, ed, "copy"));
    }

    private static void create(MainActivity a, EditorScreen ed, String kind) {
        String def = kind.equals("post") ? "Новая запись" : kind.equals("contacts") ? "Контакты" : kind.equals("copy") ? ed.page.title + " (копия)" : "Новая страница";
        a.ask("Название страницы", "Например: О нас", def, "Создать", title -> {
            Site s = a.hub.site;
            Site.Page np = new Site.Page();
            np.title = title;
            switch (kind) {
                case "start": {
                    Site.Block h = Blocks.make("hero", "minimal");
                    h.v.put("eyebrow", "");
                    h.v.put("title", title);
                    h.v.put("text", "Коротко о том, что на этой странице.");
                    h.v.put("button", "");
                    h.v.put("button2", "");
                    h.v.put("height", "auto");
                    np.blocks.add(h);
                    Site.Block t = Blocks.make("text", "normal");
                    t.v.put("title", "");
                    np.blocks.add(t);
                    break;
                }
                case "contacts": {
                    Site.Block c = Blocks.make("contacts", "split");
                    c.anchor = ed.freeAnchor("contacts");
                    np.blocks.add(c);
                    Site.Block f = Blocks.make("form", "card");
                    f.anchor = ed.freeAnchor("form");
                    np.blocks.add(f);
                    break;
                }
                case "post": {
                    np.kind = "post";
                    np.menu = false;
                    np.date = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(new Date());
                    np.excerpt = "Пара предложений о чём запись — их видно в списке записей.";
                    Site.Block t = Blocks.make("text", "normal");
                    t.v.put("title", "");
                    t.v.put("text", "Текст записи. Пишите абзацами; **жирный**, *курсив*, списки через «- ».");
                    np.blocks.add(t);
                    break;
                }
                case "copy": {
                    Site.Page src = ed.page;
                    np.kind = src.kind;
                    np.menu = src.menu;
                    np.noHeader = src.noHeader;
                    np.noFooter = src.noFooter;
                    for (Site.Block b : src.blocks) {
                        Site.Block c = b.copy();
                        c.anchor = ""; // якоря должны быть уникальными
                        np.blocks.add(c);
                    }
                    break;
                }
                default:
                    break;
            }
            int at = s.pages.indexOf(ed.page) + 1;
            if (at <= 0 || at > s.pages.size()) at = s.pages.size();
            s.pages.add(at, np);
            a.hub.saveSoon();
            // сразу в редактор на новую страницу
            ed.showPage(np, null);
            a.popTo(ed);
            a.toast("Страница «" + title + "» создана — " + s.file(np));
        });
    }
}
