package com.neondrift.site;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.LruCache;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

/** Фото из галереи — в папку проекта: поворот по EXIF, уменьшение до разумного размера, сжатие. */
final class Images {
    private Images() {}

    /** Длинная сторона для обычных фото: хватает для широких экранов, а сайт остаётся лёгким. */
    static final int MAX = 1920;

    /**
     * Скопировать картинку в img/ проекта. maxSide — ограничение длинной стороны (0 — обычное).
     * Возвращает путь вида «img/имя.jpg».
     */
    static String put(Context c, Uri uri, File imgDir, int maxSide) throws IOException {
        ContentResolver cr = c.getContentResolver();
        String name = displayName(c, uri);
        String type = cr.getType(uri);
        String ext = ext(name, type);
        String base = Slug.of(stripExt(name));
        if (base.isEmpty()) base = "foto";
        if (base.length() > 32) base = base.substring(0, 32);
        String id = Long.toString(System.currentTimeMillis() % 1_000_000_000L, 36);
        if (!imgDir.isDirectory() && !imgDir.mkdirs()) throw new IOException("нет папки для картинок");

        // анимации и векторы — как есть
        if (ext.equals("gif") || ext.equals("svg")) {
            File out = new File(imgDir, base + "-" + id + "." + ext);
            try (InputStream in = cr.openInputStream(uri); OutputStream o = new FileOutputStream(out)) {
                if (in == null) throw new IOException("файл не открывается");
                byte[] buf = new byte[64 * 1024];
                int n;
                long total = 0;
                while ((n = in.read(buf)) > 0) {
                    total += n;
                    if (total > 15L * 1024 * 1024) throw new IOException("файл больше 15 МБ");
                    o.write(buf, 0, n);
                }
            }
            return "img/" + out.getName();
        }

        int side = maxSide > 0 ? maxSide : MAX;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = cr.openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, o);
        }
        if (o.outWidth <= 0 || o.outHeight <= 0) throw new IOException("это не картинка или формат не поддерживается");
        int sample = 1;
        while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= side) sample *= 2;
        BitmapFactory.Options d = new BitmapFactory.Options();
        d.inSampleSize = sample;
        Bitmap bmp;
        try (InputStream in = cr.openInputStream(uri)) {
            bmp = BitmapFactory.decodeStream(in, null, d);
        }
        if (bmp == null) throw new IOException("картинка не читается");
        int rot = rotation(cr, uri);
        float k = Math.min(1f, side / (float) Math.max(bmp.getWidth(), bmp.getHeight()));
        if (rot != 0 || k < 1f) {
            Matrix m = new Matrix();
            if (k < 1f) m.postScale(k, k);
            if (rot != 0) m.postRotate(rot);
            Bitmap r = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            if (r != bmp) bmp.recycle();
            bmp = r;
        }
        boolean alpha = bmp.hasAlpha() && (ext.equals("png") || ext.equals("webp")) && hasTransparency(bmp);
        String outExt = alpha ? "png" : "jpg";
        File out = new File(imgDir, base + "-" + id + "." + outExt);
        try (OutputStream os = new FileOutputStream(out)) {
            bmp.compress(alpha ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, 84, os);
        } finally {
            bmp.recycle();
        }
        return "img/" + out.getName();
    }

    private static boolean hasTransparency(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        int stepX = Math.max(1, w / 40), stepY = Math.max(1, h / 40);
        for (int y = 0; y < h; y += stepY) for (int x = 0; x < w; x += stepX) if ((b.getPixel(x, y) >>> 24) < 250) return true;
        return (b.getPixel(0, 0) >>> 24) < 250 || (b.getPixel(w - 1, h - 1) >>> 24) < 250;
    }

    private static int rotation(ContentResolver cr, Uri uri) {
        try (InputStream in = cr.openInputStream(uri)) {
            if (in == null) return 0;
            ExifInterface e = new ExifInterface(in);
            switch (e.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                case ExifInterface.ORIENTATION_ROTATE_90: return 90;
                case ExifInterface.ORIENTATION_ROTATE_180: return 180;
                case ExifInterface.ORIENTATION_ROTATE_270: return 270;
                default: return 0;
            }
        } catch (Exception e) {
            return 0;
        }
    }

    static String displayName(Context c, Uri uri) {
        try (Cursor cur = c.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                String s = cur.getString(0);
                if (s != null && !s.isEmpty()) return s;
            }
        } catch (Exception ignored) {
        }
        String p = uri.getLastPathSegment();
        return p == null ? "foto" : p;
    }

    private static String stripExt(String n) {
        int k = n.lastIndexOf('.');
        return k > 0 ? n.substring(0, k) : n;
    }

    private static String ext(String name, String type) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".gif") || "image/gif".equals(type)) return "gif";
        if (n.endsWith(".svg") || "image/svg+xml".equals(type)) return "svg";
        if (n.endsWith(".png") || "image/png".equals(type)) return "png";
        if (n.endsWith(".webp") || "image/webp".equals(type)) return "webp";
        return "jpg";
    }

    // ------------------------------------------------------------------ миниатюры для форм

    private static final LruCache<String, Bitmap> THUMBS = new LruCache<String, Bitmap>(8 * 1024 * 1024) {
        @Override
        protected int sizeOf(String k, Bitmap b) {
            return b.getByteCount();
        }
    };

    /** Маленькая копия для списка (на главном потоке — только из кэша, иначе null). */
    static Bitmap cached(File f, int px) {
        return THUMBS.get(f.getAbsolutePath() + "@" + px + "@" + f.lastModified());
    }

    static Bitmap thumb(File f, int px) {
        String key = f.getAbsolutePath() + "@" + px + "@" + f.lastModified();
        Bitmap b = THUMBS.get(key);
        if (b != null) return b;
        if (!f.isFile()) return null;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        if (o.outWidth <= 0) return null;
        int s = 1;
        while (Math.min(o.outWidth, o.outHeight) / (s * 2) >= px) s *= 2;
        BitmapFactory.Options d = new BitmapFactory.Options();
        d.inSampleSize = s;
        b = BitmapFactory.decodeFile(f.getAbsolutePath(), d);
        if (b != null) THUMBS.put(key, b);
        return b;
    }
}
