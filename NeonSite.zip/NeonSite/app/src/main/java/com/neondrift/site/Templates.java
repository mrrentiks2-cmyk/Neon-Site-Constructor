package com.neondrift.site;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Стартовые сайты: открываешь — и меняешь под себя. Все названия и люди вымышленные. */
final class Templates {
    private Templates() {}

    static final String[] IDS = {"coffee", "service", "portfolio", "blog", "event", "blank"};
    static final String[] NAMES = {"Кофейня", "Услуги мастера", "Портфолио", "Блог", "Мероприятие", "Пустой сайт"};
    static final String[] DESCS = {
            "Одна страница: меню с ценами, фото, отзывы, адрес с картой",
            "Лендинг: этапы работы, услуги, цены, вопросы, заявка",
            "Несколько страниц: работы, обо мне, услуги, контакты",
            "Записи с обложками, страница «Обо мне»",
            "Тёмный неоновый лендинг: программа, спикеры, билеты",
            "Шапка, обложка и подвал — дальше сами"};

    static Site make(String id) {
        Site s;
        switch (id) {
            case "coffee": s = coffee(); break;
            case "service": s = service(); break;
            case "portfolio": s = portfolio(); break;
            case "blog": s = blog(); break;
            case "event": s = event(); break;
            default: s = blank(); break;
        }
        s.template = id;
        if (!s.description.isEmpty() && s.footer != null) s.footer.v.put("text", s.description);
        return s;
    }

    private static Site base(String name, String palette, String fonts) {
        Site s = new Site();
        s.name = name;
        s.look.palette(Themes.palette(palette));
        s.look.fonts = fonts;
        s.header = Blocks.make("header", "left");
        s.header.v.put("logo", name);
        s.footer = Blocks.make("footer", "columns");
        s.footer.v.put("logo", name);
        s.footer.v.put("copyright", "© " + java.util.Calendar.getInstance().get(java.util.Calendar.YEAR) + " " + name);
        return s;
    }

    /** Пункты меню в шапке: текст, ссылка, текст, ссылка… */
    private static void nav(Site s, String... tl) {
        List<Map<String, Object>> l = items(s.header);
        for (int i = 0; i + 1 < tl.length; i += 2) l.add(Blocks.item("text", tl[i], "link", tl[i + 1]));
    }

    private static void qa(Site.Block faq, String... qa) {
        List<Map<String, Object>> l = items(faq);
        for (int i = 0; i + 1 < qa.length; i += 2) l.add(Blocks.item("q", qa[i], "a", qa[i + 1]));
    }

    private static void reviews(Site.Block r, String... tnr) {
        List<Map<String, Object>> l = items(r);
        for (int i = 0; i + 2 < tnr.length; i += 3) l.add(Blocks.item("text", tnr[i], "name", tnr[i + 1], "role", tnr[i + 2], "photo", "", "stars", 5L));
    }

    private static Site.Page page(Site s, String title) {
        Site.Page p = new Site.Page();
        p.title = title;
        s.pages.add(p);
        return p;
    }

    private static Site.Block add(Site.Page p, String type, String variant) {
        Site.Block b = Blocks.make(type, variant);
        p.blocks.add(b);
        return b;
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> items(Site.Block b) {
        List<Map<String, Object>> l = new ArrayList<>();
        b.v.put("items", l);
        return l;
    }

    // ------------------------------------------------------------------ кофейня

    private static Site coffee() {
        Site s = base("Зерно и пар", "coffee", "elegant");
        s.description = "Кофейня у дома: свежая обжарка, выпечка каждое утро, уютные столики у окна.";
        s.header.v.put("button", "Как добраться");
        s.header.v.put("buttonLink", "#contacts");
        nav(s, "Меню", "#menu", "Отзывы", "#reviews", "Контакты", "#contacts");
        Site.Page p = page(s, "Главная");
        Site.Block hero = add(p, "hero", "split");
        hero.v.put("eyebrow", "Кофейня у дома");
        hero.v.put("title", "Кофе, ради которого хочется просыпаться");
        hero.v.put("text", "Обжариваем зерно сами, печём круассаны каждое утро и знаем постоянных гостей по имени.");
        hero.v.put("button", "Смотреть меню");
        hero.v.put("buttonLink", "#menu");
        hero.v.put("button2", "Как добраться");
        hero.v.put("button2Link", "#contacts");
        Site.Block f = add(p, "features", "plain");
        f.v.put("title", "За что нас любят");
        f.v.put("text", "");
        List<Map<String, Object>> fi = items(f);
        fi.add(Blocks.item("icon", "☕", "image", "", "title", "Свежая обжарка", "text", "Зерно обжариваем небольшими партиями каждую неделю.", "link", ""));
        fi.add(Blocks.item("icon", "🥐", "image", "", "title", "Выпечка с утра", "text", "Круассаны и булочки — из нашей печи, ещё тёплые.", "link", ""));
        fi.add(Blocks.item("icon", "🌿", "image", "", "title", "Тихо и уютно", "text", "Столики у окна, розетки и быстрый Wi-Fi.", "link", ""));
        Site.Block menu = add(p, "pricing", "list");
        menu.anchor = "menu";
        menu.bg = "surface";
        menu.v.put("title", "Меню");
        menu.v.put("text", "Молоко на выбор: обычное, овсяное, миндальное.");
        List<Map<String, Object>> mi = items(menu);
        String[][] pos = {{"Эспрессо", "150 ₽"}, {"Капучино", "220 ₽"}, {"Флэт уайт", "240 ₽"}, {"Раф ванильный", "260 ₽"}, {"Какао с маршмеллоу", "230 ₽"},
                {"Круассан", "180 ₽"}, {"Чизкейк", "290 ₽"}};
        for (String[] x : pos) mi.add(Blocks.item("name", x[0], "price", x[1], "period", "", "text", "", "button", "", "link", "", "featured", false));
        Site.Block g = add(p, "gallery", "masonry");
        g.v.put("title", "Загляните к нам");
        Site.Block r = add(p, "reviews", "cards");
        r.bg = "surface";
        r.anchor = "reviews";
        r.v.put("title", "Что говорят гости");
        reviews(r, "Лучший флэт уайт в районе. Захожу каждое утро по пути на работу.", "Ирина", "постоянный гость",
                "Круассаны правда тёплые, а бариста помнит, что я пью без сахара.", "Олег", "живёт рядом",
                "Тихое место, чтобы поработать пару часов. Розетки у каждого столика!", "Вика", "фрилансер");
        Site.Block c = add(p, "contacts", "split");
        c.v.put("text", "Мы в двух минутах от метро. Можно с собакой.");
        c.v.put("hours", "Будни 8:00–21:00, выходные 9:00–22:00");
        return s;
    }

    // ------------------------------------------------------------------ услуги

    private static Site service() {
        Site s = base("Мастер Дома", "snow", "modern");
        s.description = "Ремонт квартир под ключ: фиксированная смета, сроки в договоре, гарантия 2 года.";
        s.header.v.put("button", "Рассчитать стоимость");
        s.header.v.put("buttonLink", "#form");
        nav(s, "Услуги", "#services", "Работы", "#works", "Цены", "#prices", "Вопросы", "#faq");
        Site.Page p = page(s, "Главная");
        Site.Block hero = add(p, "hero", "center");
        hero.bg = "dark";
        hero.v.put("eyebrow", "Ремонт квартир под ключ");
        hero.v.put("title", "Ремонт без нервов — по смете и в срок");
        hero.v.put("text", "Фиксируем цену и сроки в договоре. Каждую неделю — фотоотчёт. Гарантия 2 года.");
        hero.v.put("button", "Рассчитать стоимость");
        hero.v.put("buttonLink", "#form");
        hero.v.put("button2", "Наши работы");
        hero.v.put("button2Link", "#works");
        Site.Block st = add(p, "stats", "plain");
        List<Map<String, Object>> si = items(st);
        si.add(Blocks.item("num", "12", "label", "лет на рынке"));
        si.add(Blocks.item("num", "340+", "label", "квартир сдано"));
        si.add(Blocks.item("num", "2 года", "label", "гарантии"));
        si.add(Blocks.item("num", "0 ₽", "label", "выезд и замер"));
        Site.Block sv = add(p, "features", "cards");
        sv.anchor = "services";
        sv.v.put("title", "Что мы делаем");
        sv.v.put("text", "Берём на себя всё — от черновых работ до уборки.");
        List<Map<String, Object>> svi = items(sv);
        svi.add(Blocks.item("icon", "🏠", "image", "", "title", "Ремонт под ключ", "text", "Квартира полностью готова к жизни.", "link", ""));
        svi.add(Blocks.item("icon", "🔧", "image", "", "title", "Сантехника", "text", "Разводка, установка, тёплые полы.", "link", ""));
        svi.add(Blocks.item("icon", "⚡", "image", "", "title", "Электрика", "text", "Проводка по нормам, щиток, освещение.", "link", ""));
        svi.add(Blocks.item("icon", "🎨", "image", "", "title", "Отделка", "text", "Покраска, обои, плитка, ламинат.", "link", ""));
        svi.add(Blocks.item("icon", "📦", "image", "", "title", "Материалы", "text", "Закупаем и привозим сами — со скидкой.", "link", ""));
        svi.add(Blocks.item("icon", "🛡️", "image", "", "title", "Гарантия", "text", "2 года на все работы — в договоре.", "link", ""));
        Site.Block steps = add(p, "features", "numbered");
        steps.bg = "surface";
        steps.v.put("columns", "4");
        List<Map<String, Object>> sti = items(steps);
        sti.add(Blocks.item("icon", "", "image", "", "title", "Замер", "text", "Приезжаем бесплатно, обсуждаем задачу.", "link", ""));
        sti.add(Blocks.item("icon", "", "image", "", "title", "Смета", "text", "Точная стоимость по каждому пункту.", "link", ""));
        sti.add(Blocks.item("icon", "", "image", "", "title", "Работы", "text", "Еженедельные фотоотчёты в мессенджер.", "link", ""));
        sti.add(Blocks.item("icon", "", "image", "", "title", "Сдача", "text", "Принимаете работу — подписываем акт.", "link", ""));
        Site.Block g = add(p, "gallery", "grid");
        g.anchor = "works";
        g.v.put("title", "Наши работы");
        Site.Block pr = add(p, "pricing", "cards");
        pr.anchor = "prices";
        pr.v.put("title", "Сколько стоит");
        pr.v.put("text", "Цена за квадратный метр, материалы — отдельно по чекам.");
        List<Map<String, Object>> pri = items(pr);
        pri.add(Blocks.item("name", "Косметический", "price", "от 4 500 ₽", "period", "м²", "text", "Покраска и обои\nНапольные покрытия\nЗамена розеток", "button", "Рассчитать", "link", "#form", "featured", false));
        pri.add(Blocks.item("name", "Капитальный", "price", "от 9 000 ₽", "period", "м²", "text", "Демонтаж и выравнивание\nЭлектрика и сантехника\nЧистовая отделка", "button", "Рассчитать", "link", "#form", "featured", true));
        pri.add(Blocks.item("name", "Дизайнерский", "price", "от 15 000 ₽", "period", "м²", "text", "Дизайн-проект\nАвторский надзор\nКомплектация мебелью", "button", "Рассчитать", "link", "#form", "featured", false));
        Site.Block rv = add(p, "reviews", "cards");
        rv.bg = "surface";
        reviews(rv, "Сделали ванную и кухню за пять недель, как и обещали. Смета не выросла ни на рубль.", "Наталья", "двушка, 54 м²",
                "Фотоотчёты каждую пятницу — я был в отъезде и всё равно спокойно спал.", "Андрей", "студия, 31 м²",
                "Аккуратные ребята: после себя убрали так, что можно было сразу заезжать.", "Светлана", "трёшка, 78 м²");
        Site.Block faq = add(p, "faq", "split");
        faq.anchor = "faq";
        qa(faq, "Можно ли жить в квартире во время ремонта?", "Если ремонт косметический — да, делаем по комнатам. При капитальном лучше съехать на время черновых работ.",
                "Что если смета вырастет?", "Цена фиксируется в договоре. Если вы сами захотите добавить работы — согласуем отдельно и письменно.",
                "Кто закупает материалы?", "Можем мы — со своей скидкой и по чекам. Можете вы — тогда дадим точный список.",
                "Какая гарантия?", "2 года на все работы. Если что-то пойдёт не так — приедем и исправим бесплатно.");
        Site.Block form = add(p, "form", "split");
        form.bg = "primary";
        form.v.put("title", "Рассчитаем стоимость за 15 минут");
        form.v.put("text", "Опишите квартиру и что нужно сделать — перезвоним с предварительной сметой.");
        add(p, "contacts", "cards");
        return s;
    }

    // ------------------------------------------------------------------ портфолио

    private static Site portfolio() {
        Site s = base("Анна Светлова", "graphite", "strict");
        s.description = "Фотограф: портреты, семейные и свадебные съёмки.";
        s.header.v.put("button", "Записаться");
        Site.Page home = page(s, "Работы");
        Site.Block hero = add(home, "hero", "minimal");
        hero.v.put("eyebrow", "Фотограф");
        hero.v.put("title", "Снимаю людей такими, какие они есть");
        hero.v.put("text", "Портреты, семьи, свадьбы. Москва и путешествия.");
        hero.v.put("button", "Записаться на съёмку");
        hero.v.put("button2", "Обо мне");
        Site.Block g = add(home, "gallery", "masonry");
        g.v.put("title", "");
        g.v.put("columns", "3");
        List<Map<String, Object>> gi = items(g);
        for (int i = 0; i < 9; i++) gi.add(Blocks.item("image", "", "caption", ""));
        Site.Block cta = add(home, "cta", "band");
        cta.v.put("title", "Хотите такие же фото?");
        cta.v.put("text", "Расскажите, какую съёмку планируете — предложу идеи и место.");
        cta.v.put("button", "Записаться");

        Site.Page about = page(s, "Обо мне");
        Site.Block it = add(about, "imagetext", "left");
        it.v.put("shape", "arch");
        it.v.put("eyebrow", "Привет!");
        it.v.put("title", "Меня зовут Анна");
        it.v.put("text", "Я снимаю уже восемь лет. Люблю естественный свет, живые эмоции и истории, которые остаются в кадре.\n\nНа съёмке помогаю расслабиться — позировать не нужно.");
        it.v.put("button", "");
        Site.Block st = add(about, "stats", "cards");
        List<Map<String, Object>> si = items(st);
        si.add(Blocks.item("num", "8", "label", "лет снимаю"));
        si.add(Blocks.item("num", "600+", "label", "съёмок"));
        si.add(Blocks.item("num", "14", "label", "стран"));

        Site.Page price = page(s, "Услуги");
        Site.Block pr = add(price, "pricing", "cards");
        pr.v.put("title", "Съёмки и цены");
        pr.v.put("text", "Все фото — с обработкой, готовы через 10 дней.");
        List<Map<String, Object>> pri = items(pr);
        pri.add(Blocks.item("name", "Портрет", "price", "8 000 ₽", "period", "1 час", "text", "40 фото в обработке\nОдна локация\nПомощь с образом", "button", "Записаться", "link", "", "featured", false));
        pri.add(Blocks.item("name", "Семейная", "price", "12 000 ₽", "period", "1,5 часа", "text", "70 фото в обработке\nДо 6 человек\nЛюбая локация в городе", "button", "Записаться", "link", "", "featured", true));
        pri.add(Blocks.item("name", "Свадьба", "price", "от 45 000 ₽", "period", "день", "text", "От 400 фото\nСборы, церемония, банкет\nФотокнига в подарок", "button", "Обсудить", "link", "", "featured", false));
        Site.Block pf = add(price, "faq", "list");
        qa(pf, "Как подготовиться к съёмке?", "Перед съёмкой пришлю памятку: что надеть, какие цвета работают лучше и как выбрать место.",
                "Когда будут готовы фото?", "Через 10 дней. Свадьбы — до 4 недель. Пять превью пришлю уже на следующий день.",
                "Можно ли перенести дату?", "Да, один раз бесплатно, если предупредите хотя бы за двое суток.");

        Site.Page contact = page(s, "Контакты");
        Site.Block c = add(contact, "contacts", "cards");
        c.v.put("address", "");
        c.v.put("hours", "");
        c.v.put("telegram", "@username");
        Site.Block form = add(contact, "form", "card");
        form.v.put("title", "Запись на съёмку");
        form.v.put("text", "Напишите, какую съёмку хотите и на какие даты.");

        // ссылки кнопок — на страницы сайта
        String contactLink = "page:" + contact.id, aboutLink = "page:" + about.id;
        s.header.v.put("buttonLink", contactLink);
        hero.v.put("buttonLink", contactLink);
        hero.v.put("button2Link", aboutLink);
        cta.v.put("buttonLink", contactLink);
        for (Map<String, Object> m : pri) m.put("link", contactLink);
        return s;
    }

    // ------------------------------------------------------------------ блог

    private static Site blog() {
        Site s = base("Заметки в дороге", "lavender", "friendly");
        s.description = "Блог о путешествиях: маршруты, советы, истории.";
        s.header.v.put("button", "");
        Site.Page home = page(s, "Главная");
        Site.Block hero = add(home, "hero", "center");
        hero.v.put("eyebrow", "Блог о путешествиях");
        hero.v.put("title", "Маршруты, которые хочется повторить");
        hero.v.put("text", "Пишу о местах, где был сам: как добраться, где жить и что попробовать.");
        hero.v.put("button", "Читать записи");
        hero.v.put("buttonLink", "#posts");
        hero.v.put("button2", "");
        hero.v.put("height", "auto");
        Site.Block posts = add(home, "posts", "grid");
        posts.anchor = "posts";
        Site.Page about = page(s, "Обо мне");
        Site.Block it = add(about, "imagetext", "right");
        it.v.put("shape", "circle");
        it.v.put("eyebrow", "");
        it.v.put("title", "Привет, это мой блог");
        it.v.put("text", "Работаю удалённо и путешествую. Здесь — честные заметки без рекламы.");
        it.v.put("button", "Написать мне");
        it.v.put("buttonLink", "mailto:hello@example.com");
        String[][] ps = {
                {"Три дня в горах: маршрут для новичков", "2026-09-14", "Как подготовиться, что взять с собой и где остановиться на ночь."},
                {"Как я собираю рюкзак за 20 минут", "2026-08-02", "Список вещей, который проверен двадцатью поездками."},
                {"Город у моря вне сезона", "2026-06-21", "Пустые пляжи, тёплый ветер и лучшие кафе для местных."}};
        for (String[] x : ps) {
            Site.Page pp = page(s, x[0]);
            pp.kind = "post";
            pp.menu = false;
            pp.date = x[1];
            pp.excerpt = x[2];
            Site.Block t = add(pp, "text", "normal");
            t.v.put("title", "");
            t.v.put("text", x[2] + "\n\nЗдесь будет текст записи. Пишите абзацами, добавляйте **выделения** и списки:\n- первое\n- второе\n- третье\n\nКартинки удобно добавлять отдельными блоками «Картинка и текст» или «Галерея».");
        }
        return s;
    }

    // ------------------------------------------------------------------ мероприятие

    private static Site event() {
        Site s = base("Код и кофе 2027", "neon", "bold");
        s.description = "Конференция для разработчиков: доклады, мастер-классы и нетворкинг.";
        s.header.v.put("button", "Купить билет");
        s.header.v.put("buttonLink", "#tickets");
        s.header.v.put("transparent", true);
        nav(s, "Программа", "#program", "Спикеры", "#speakers", "Билеты", "#tickets");
        s.look.buttons = "gradient";
        Site.Page p = page(s, "Главная");
        Site.Block hero = add(p, "hero", "full");
        hero.v.put("eyebrow", "17–18 апреля 2027 · Москва");
        hero.v.put("title", "Код и кофе 2027");
        hero.v.put("text", "Два дня докладов, мастер-классов и разговоров с теми, кто делает продукты, которыми вы пользуетесь каждый день.");
        hero.v.put("button", "Купить билет");
        hero.v.put("buttonLink", "#tickets");
        hero.v.put("button2", "Программа");
        hero.v.put("button2Link", "#program");
        Site.Block st = add(p, "stats", "plain");
        List<Map<String, Object>> si = items(st);
        si.add(Blocks.item("num", "40", "label", "докладов"));
        si.add(Blocks.item("num", "2", "label", "дня"));
        si.add(Blocks.item("num", "1500", "label", "участников"));
        si.add(Blocks.item("num", "6", "label", "мастер-классов"));
        Site.Block prog = add(p, "features", "numbered");
        prog.anchor = "program";
        prog.v.put("title", "Программа");
        prog.v.put("text", "");
        prog.v.put("columns", "2");
        List<Map<String, Object>> pi = items(prog);
        pi.add(Blocks.item("icon", "", "image", "", "title", "Открытие и главный доклад", "text", "10:00 · Большой зал", "link", ""));
        pi.add(Blocks.item("icon", "", "image", "", "title", "Архитектура мобильных приложений", "text", "11:30 · Зал «Альфа»", "link", ""));
        pi.add(Blocks.item("icon", "", "image", "", "title", "Мастер-класс: дизайн интерфейсов", "text", "14:00 · Лаборатория", "link", ""));
        pi.add(Blocks.item("icon", "", "image", "", "title", "Вечеринка участников", "text", "19:00 · Крыша", "link", ""));
        Site.Block team = add(p, "team", "round");
        team.anchor = "speakers";
        team.v.put("title", "Спикеры");
        team.v.put("columns", "4");
        List<Map<String, Object>> ti = items(team);
        String[][] sp = {{"Алексей Миронов", "Ведущий разработчик"}, {"Ольга Ким", "Дизайнер интерфейсов"}, {"Дмитрий Орлов", "Архитектор"}, {"Екатерина Лис", "Продакт-менеджер"}};
        for (String[] x : sp) ti.add(Blocks.item("photo", "", "name", x[0], "role", x[1], "text", ""));
        Site.Block pr = add(p, "pricing", "cards");
        pr.anchor = "tickets";
        pr.bg = "surface";
        pr.v.put("title", "Билеты");
        pr.v.put("text", "Цена растёт ближе к событию.");
        List<Map<String, Object>> pri = items(pr);
        pri.add(Blocks.item("name", "Онлайн", "price", "3 900 ₽", "period", "", "text", "Трансляция всех залов\nЗаписи докладов", "button", "Купить", "link", "#form", "featured", false));
        pri.add(Blocks.item("name", "Стандарт", "price", "14 900 ₽", "period", "", "text", "Оба дня очно\nОбеды и кофе\nЗаписи докладов", "button", "Купить", "link", "#form", "featured", true));
        pri.add(Blocks.item("name", "Бизнес", "price", "29 900 ₽", "period", "", "text", "Всё из «Стандарта»\nЗакрытая зона\nУжин со спикерами", "button", "Купить", "link", "#form", "featured", false));
        Site.Block ef = add(p, "faq", "split");
        qa(ef, "Будут ли записи докладов?", "Да, записи получат все участники через неделю после конференции.",
                "Можно ли вернуть билет?", "Полностью — до 1 апреля. Позже можно передать билет коллеге, написав нам.",
                "Есть ли скидки для студентов?", "Да, 50% на «Стандарт» по студенческому билету — напишите нам перед покупкой.");
        Site.Block form = add(p, "form", "card");
        form.v.put("title", "Заявка на билет");
        form.v.put("text", "Оставьте контакты — пришлём счёт и подтверждение.");
        form.v.put("fEmail", true);
        form.v.put("fMessage", false);
        return s;
    }

    private static Site blank() {
        Site s = base("Мой сайт", "snow", "modern");
        Site.Page p = page(s, "Главная");
        Site.Block hero = add(p, "hero", "minimal");
        hero.v.put("title", "Заголовок сайта");
        hero.v.put("text", "Нажмите на любой блок, чтобы изменить его, или добавьте новый.");
        hero.v.put("button", "");
        hero.v.put("button2", "");
        s.header.v.put("button", "");
        return s;
    }
}
