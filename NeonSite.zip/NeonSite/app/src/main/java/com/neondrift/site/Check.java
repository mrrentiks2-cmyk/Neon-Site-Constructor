package com.neondrift.site;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Проверка сайта перед выгрузкой: забытые образцы текста, пустые фото, битые ссылки, форма без адреса. */
final class Check {
    private Check() {}

    static final int INFO = 0, WARN = 1, ERROR = 2;

    static final class Issue {
        final int level;
        final String text;
        /** Куда вести по нажатию (может быть пусто). */
        final String pageId, blockId;

        Issue(int level, String text, String pageId, String blockId) {
            this.level = level;
            this.text = text;
            this.pageId = pageId;
            this.blockId = blockId;
        }
    }

    /** Строки из образцов: если они остались на сайте — их, скорее всего, забыли поменять. */
    private static final String[] SAMPLES = {"+7 900 000-00-00", "hello@example.com", "г. Город, ул. Улица, 1", "Имя Фамилия", "Крупный заголовок о главном",
            "Расскажите о себе", "Расскажите подробнее", "Одно-два предложения", "Пара слов о том, чем вы занимаетесь", "Текст отзыва.", "@username"};

    static List<Issue> run(Site s) {
        List<Issue> out = new ArrayList<>();
        Map<String, Integer> anchors = new HashMap<>();
        Set<String> pageIds = new HashSet<>();
        for (Site.Page p : s.pages) {
            pageIds.add(p.id);
            for (Site.Block b : p.blocks) if (!b.anchor.isEmpty()) anchors.merge(b.anchor, 1, Integer::sum);
        }
        if (s.pages.isEmpty()) out.add(new Issue(ERROR, "На сайте нет ни одной страницы", "", ""));
        for (Map.Entry<String, Integer> e : anchors.entrySet())
            if (e.getValue() > 1) out.add(new Issue(WARN, "Якорь «#" + e.getKey() + "» стоит у нескольких блоков — ссылка найдёт только первый", "", ""));

        if (s.header != null) block(s, null, s.header, anchors, pageIds, out);
        for (Site.Page p : s.pages) {
            if (p.blocks.isEmpty()) out.add(new Issue(WARN, "Страница «" + p.title + "» пустая", p.id, ""));
            if (p.post() && p.date.isEmpty()) out.add(new Issue(INFO, "У записи «" + p.title + "» нет даты", p.id, ""));
            for (Site.Block b : p.blocks) if (!b.hidden) block(s, p, b, anchors, pageIds, out);
        }
        if (s.footer != null) block(s, null, s.footer, anchors, pageIds, out);

        if (s.description.trim().isEmpty()) out.add(new Issue(INFO, "Нет описания сайта — его показывают поисковики и мессенджеры в превью ссылки", "", ""));
        if (s.domain.trim().isEmpty()) out.add(new Issue(INFO, "Не указан домен — без него не будет sitemap.xml и полных ссылок для соцсетей", "", ""));
        return out;
    }

    private static void block(Site s, Site.Page p, Site.Block b, Map<String, Integer> anchors, Set<String> pageIds, List<Issue> out) {
        String pid = p == null ? "" : p.id;
        String where = where(p, b);
        Blocks.Type t = Blocks.type(b.type);
        // образцы текста
        String sample = sample(b.v);
        if (sample != null) out.add(new Issue(WARN, where + ": остался текст-образец «" + cut(sample) + "»", pid, b.id));
        // фото
        int noPhoto = 0, slots = 0;
        for (Blocks.Field f : t.fields) {
            if (!f.visible(b.variant, b.v)) continue;
            if (f.kind.equals(Blocks.IMAGE) && required(b, f.key)) {
                slots++;
                if (b.s(f.key).isEmpty()) noPhoto++;
            }
            if (f.kind.equals(Blocks.ITEMS) && f.sub != null) {
                for (Map<String, Object> it : b.items()) {
                    for (Blocks.Field sf : f.sub) {
                        if (!sf.kind.equals(Blocks.IMAGE) || !requiredItem(b, sf.key, it)) continue;
                        slots++;
                        Object v = it.get(sf.key);
                        if (v == null || String.valueOf(v).isEmpty()) noPhoto++;
                    }
                }
            }
        }
        if (noPhoto > 0) out.add(new Issue(WARN, where + ": не выбрано фото" + (slots > 1 ? " (" + noPhoto + " из " + slots + ")" : "") + " — на сайте будет заглушка", pid, b.id));
        // ссылки
        List<String> links = new ArrayList<>();
        collectLinks(t.fields, b.v, links);
        for (String l : links) {
            String bad = badLink(l, anchors, pageIds);
            if (bad != null) out.add(new Issue(ERROR, where + ": " + bad, pid, b.id));
        }
        // особые случаи
        switch (b.type) {
            case "form":
                if (b.s("sendTo").equals("url")) {
                    if (!b.s("action").startsWith("http")) out.add(new Issue(ERROR, where + ": не указан адрес обработчика формы", pid, b.id));
                } else if (!b.s("email").contains("@") || b.s("email").equals("hello@example.com")) {
                    out.add(new Issue(ERROR, where + ": не указана почта, куда придут заявки", pid, b.id));
                } else {
                    out.add(new Issue(INFO, where + ": заявки будут открывать почтовое приложение посетителя. Надёжнее — обработчик форм (например, Formspree)", pid, b.id));
                }
                break;
            case "video":
                if (b.s("url").trim().isEmpty()) out.add(new Issue(WARN, where + ": нет ссылки на видео", pid, b.id));
                else if (Gen.embed(b.s("url")) == null) out.add(new Issue(INFO, where + ": это видео не встроится в страницу — будет кнопка «Смотреть»", pid, b.id));
                break;
            case "contacts":
                if (b.variant.equals("split") && b.b("map") && b.s("address").isEmpty()) out.add(new Issue(WARN, where + ": для карты нужен адрес", pid, b.id));
                break;
            case "posts":
                if (s.posts().isEmpty()) out.add(new Issue(WARN, where + ": на сайте нет записей блога", pid, b.id));
                break;
            case "html":
                if (b.s("code").trim().isEmpty()) out.add(new Issue(WARN, where + ": пустой блок кода", pid, b.id));
                break;
            default:
                break;
        }
        if (!b.notes.trim().isEmpty()) out.add(new Issue(INFO, where + ": есть пожелание — «" + cut(b.notes.trim()) + "»", pid, b.id));
    }

    /** Картинки, без которых блок выглядит пустым. Логотип-картинка, фоновое фото и т. п. — необязательные. */
    private static boolean required(Site.Block b, String key) {
        switch (b.type) {
            case "hero": return key.equals("image") && (b.variant.equals("split") || b.variant.equals("full"));
            case "imagetext": return key.equals("image");
            default: return false;
        }
    }

    private static boolean requiredItem(Site.Block b, String key, Map<String, Object> it) {
        switch (b.type) {
            case "gallery": return key.equals("image");
            case "features": return false;
            case "team": return false;
            default: return false;
        }
    }

    @SuppressWarnings("unchecked")
    private static void collectLinks(List<Blocks.Field> fields, Map<String, Object> v, List<String> out) {
        for (Blocks.Field f : fields) {
            if (f.kind.equals(Blocks.LINK)) {
                Object o = v.get(f.key);
                // кнопка без текста — ссылка не показывается
                String btnKey = f.key.endsWith("Link") ? f.key.substring(0, f.key.length() - 4) : null;
                if (btnKey != null && v.containsKey(btnKey) && String.valueOf(v.get(btnKey)).trim().isEmpty()) continue;
                if (o != null && !String.valueOf(o).trim().isEmpty()) out.add(String.valueOf(o).trim());
            } else if (f.kind.equals(Blocks.ITEMS) && f.sub != null && v.get("items") instanceof List) {
                for (Object it : (List<Object>) v.get("items")) {
                    if (!(it instanceof Map)) continue;
                    Map<String, Object> m = (Map<String, Object>) it;
                    for (Blocks.Field sf : f.sub) {
                        if (!sf.kind.equals(Blocks.LINK)) continue;
                        Object o = m.get(sf.key);
                        if (sf.key.equals("link") && m.containsKey("button") && String.valueOf(m.get("button")).trim().isEmpty()) continue;
                        if (o != null && !String.valueOf(o).trim().isEmpty()) out.add(String.valueOf(o).trim());
                    }
                }
            }
        }
    }

    private static String badLink(String l, Map<String, Integer> anchors, Set<String> pageIds) {
        if (l.equals("#")) return "кнопка ведёт в никуда («#»)";
        if (l.startsWith("page:")) {
            String id = l.substring(5), a = "";
            int h = id.indexOf('#');
            if (h >= 0) {
                a = id.substring(h + 1);
                id = id.substring(0, h);
            }
            if (!pageIds.contains(id)) return "ссылка на удалённую страницу";
            if (!a.isEmpty() && !anchors.containsKey(a)) return "ссылка на якорь «#" + a + "», которого нет";
            return null;
        }
        if (l.startsWith("#") && !anchors.containsKey(l.substring(1))) return "ссылка на «" + l + "», а блока с таким якорем нет";
        return null;
    }

    @SuppressWarnings("unchecked")
    private static String sample(Object o) {
        if (o instanceof String) {
            String s = (String) o;
            for (String x : SAMPLES) if (s.contains(x)) return x;
            return null;
        }
        if (o instanceof Map) {
            for (Object v : ((Map<String, Object>) o).values()) {
                String r = sample(v);
                if (r != null) return r;
            }
        }
        if (o instanceof List) {
            for (Object v : (List<Object>) o) {
                String r = sample(v);
                if (r != null) return r;
            }
        }
        return null;
    }

    static String where(Site.Page p, Site.Block b) {
        String name = Blocks.type(b.type).name;
        if (p == null) return name;
        String title = b.s("title");
        return "«" + p.title + "» → " + name + (title.isEmpty() ? "" : " «" + cut(title.replace("*", "")) + "»");
    }

    static String cut(String s) {
        s = s.replace('\n', ' ');
        return s.length() > 40 ? s.substring(0, 38) + "…" : s;
    }
}
