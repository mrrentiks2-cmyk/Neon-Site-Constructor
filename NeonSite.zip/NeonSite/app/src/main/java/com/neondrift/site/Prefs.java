package com.neondrift.site;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки приложения. */
final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    int accent() { return sp.getInt("accent", 0); }

    /** Предпросмотр: 0 — телефон, 1 — компьютер. */
    int device() { return sp.getInt("device", 0); }

    /** Показывать живой предпросмотр над формой блока. */
    boolean blockPreview() { return sp.getBoolean("blockPreview", true); }

    boolean tipsShown(String k) { return sp.getBoolean("tip." + k, false); }

    void tipShown(String k) { sp.edit().putBoolean("tip." + k, true).apply(); }

    void put(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }

    void put(String k, int v) { sp.edit().putInt(k, v).apply(); }

    void put(String k, String v) { sp.edit().putString(k, v).apply(); }

    String str(String k, String def) { return sp.getString(k, def); }
}
