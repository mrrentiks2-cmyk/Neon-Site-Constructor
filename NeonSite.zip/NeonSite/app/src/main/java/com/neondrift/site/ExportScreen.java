package com.neondrift.site;

import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** «Готово»: проект для Claude, готовый сайт архивом, просмотр целиком и проверка перед отправкой. */
final class ExportScreen extends Screen {
    private final EditorScreen ed;
    private final LinearLayout body;

    ExportScreen(MainActivity a, EditorScreen ed) {
        super(a);
        this.ed = ed;
        header("Готово", hub.site.name);
        ScrollView sv = new ScrollView(a);
        body = ui.col();
        body.setPadding(ui.dp(16), ui.dp(6), ui.dp(16), ui.dp(48));
        sv.addView(body);
        addView(sv, Ui.lp(Ui.MATCH, 0, 1f));
    }

    @Override
    void refresh() {
        body.removeAllViews();
        Site s = hub.site;
        String base = Slug.of(s.name);
        if (base.isEmpty()) base = "sait";
        final String fileBase = base;

        // ---------- проект для Claude
        LinearLayout c1 = card(true);
        c1.addView(ui.text("Проект для Claude", 19, 0xFFFFFFFF, true));
        TextView d1 = ui.text("Архив: описание сайта и ваши пожелания (ДЛЯ_CLAUDE.md), project.json, все фото и черновик сайта. "
                + "Пришлите его в чат Claude и напишите: «Сделай из этого готовый сайт».", 13.5f, 0xE6FFFFFF, false);
        d1.setLineSpacing(0, 1.25f);
        c1.addView(d1, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(6), 0, ui.dp(12)));
        LinearLayout r1 = ui.row();
        r1.addView(whiteButton("Отправить", true, v -> claude(fileBase, true)), Ui.lp(0, Ui.WRAP, 1f));
        LinearLayout.LayoutParams lp = Ui.lp(0, Ui.WRAP, 1f);
        lp.leftMargin = ui.dp(8);
        r1.addView(whiteButton("В «Загрузки»", false, v -> claude(fileBase, false)), lp);
        c1.addView(r1);
        TextView copy = ui.text("Нельзя прикрепить архив? Скопировать проект текстом", 13, 0xFFFFFFFF, true);
        copy.setPadding(0, ui.dp(12), 0, ui.dp(2));
        copy.setOnClickListener(v -> copyText());
        c1.addView(copy);
        body.addView(c1, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(4), 0, ui.dp(12)));

        // ---------- готовый сайт
        LinearLayout c2 = card(false);
        c2.addView(ui.text("Готовый сайт", 18, Theme.TEXT, true));
        TextView d2 = ui.text("Страницы HTML, стили, скрипт и фото — можно сразу выложить на любой хостинг: GitHub Pages, Netlify, Яндекс Object Storage, обычный хостинг.",
                13.5f, Theme.MUTED, false);
        d2.setLineSpacing(0, 1.25f);
        c2.addView(d2, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(6), 0, ui.dp(12)));
        LinearLayout r2 = ui.row();
        r2.addView(ui.button("Скачать ZIP", true, v -> site(fileBase)), Ui.lp(0, Ui.WRAP, 1f));
        LinearLayout.LayoutParams lp2 = Ui.lp(0, Ui.WRAP, 1f);
        lp2.leftMargin = ui.dp(8);
        r2.addView(ui.button("Посмотреть", false, v -> a.push(new PreviewScreen(a, ed.page))), lp2);
        c2.addView(r2);
        body.addView(c2, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(8)));

        // ---------- проверка
        List<Check.Issue> issues = Check.run(s);
        int err = 0, warn = 0;
        for (Check.Issue i : issues) {
            if (i.level == Check.ERROR) err++;
            else if (i.level == Check.WARN) warn++;
        }
        body.addView(ui.label("ПРОВЕРКА" + (err + warn == 0 ? " — ВСЁ В ПОРЯДКЕ" : "")), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(2), ui.dp(18), 0, ui.dp(8)));
        if (issues.isEmpty()) {
            body.addView(ui.text("Замечаний нет 🎉", 14, Theme.MUTED, false));
        }
        for (Check.Issue i : issues) body.addView(issue(i), Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(6)));
        if (err + warn > 0) {
            TextView n = ui.text("Это подсказки, а не запрет: архив можно отправить и так — Claude увидит этот список и подскажет, что заменить.", 12.5f, Theme.MUTED, false);
            n.setLineSpacing(0, 1.25f);
            body.addView(n, Ui.margins(Ui.MATCH, Ui.WRAP, ui.dp(2), ui.dp(6), 0, 0));
        }
    }

    private LinearLayout card(boolean accent) {
        LinearLayout c = ui.col();
        c.setPadding(ui.dp(18), ui.dp(16), ui.dp(18), ui.dp(16));
        if (accent) {
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Theme.ACCENT, Theme.mix(Theme.ACCENT, Theme.ACCENT2, 0.8f)});
            g.setCornerRadius(ui.dp(20));
            c.setBackground(g);
        } else c.setBackground(Ui.stroke(Theme.SURFACE, Theme.LINE, ui.dp(1), ui.dp(20)));
        return c;
    }

    private TextView whiteButton(String text, boolean filled, View.OnClickListener l) {
        TextView b = ui.text(text, 15, filled ? 0xFF111111 : 0xFFFFFFFF, true);
        b.setGravity(android.view.Gravity.CENTER);
        b.setPadding(ui.dp(12), ui.dp(12), ui.dp(12), ui.dp(12));
        b.setBackground(Ui.ripple(filled ? Ui.round(0xFFFFFFFF, ui.dp(14)) : Ui.stroke(0x00000000, 0xAAFFFFFF, ui.dp(1), ui.dp(14)), null));
        b.setOnClickListener(l);
        return b;
    }

    private View issue(Check.Issue i) {
        LinearLayout r = ui.row();
        r.setPadding(ui.dp(12), ui.dp(10), ui.dp(10), ui.dp(10));
        r.setBackground(Ui.ripple(Ui.round(Theme.SURFACE, ui.dp(14)), Ui.round(0xFFFFFFFF, ui.dp(14))));
        ImageView ic = new ImageView(a);
        int col = i.level == Check.ERROR ? 0xFFFF6B6B : i.level == Check.WARN ? 0xFFFFB547 : Theme.MUTED;
        ic.setImageDrawable(new Glyph(i.level == Check.INFO ? "info" : "alert", col));
        r.addView(ic, Ui.lp(ui.dp(20), ui.dp(20)));
        TextView t = ui.text(i.text, 13.5f, i.level == Check.INFO ? Theme.MUTED : Theme.TEXT, false);
        t.setLineSpacing(0, 1.2f);
        r.addView(t, Ui.margins(0, Ui.WRAP, ui.dp(10), 0, 0, 0));
        ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        if (!i.blockId.isEmpty() || !i.pageId.isEmpty()) {
            ImageView go = new ImageView(a);
            go.setImageDrawable(new Glyph("chevronRight", Theme.MUTED));
            r.addView(go, Ui.lp(ui.dp(18), ui.dp(18)));
            r.setOnClickListener(v -> jump(i));
        }
        return r;
    }

    /** К блоку с замечанием: в редактор, на его страницу, сразу в форму блока. */
    private void jump(Check.Issue i) {
        Site s = hub.site;
        Site.Block b = i.blockId.isEmpty() ? null : s.block(i.blockId);
        Site.Page p = i.pageId.isEmpty() ? null : s.page(i.pageId);
        if (b != null && (b == s.header || b == s.footer)) {
            a.push(new BlockScreen(a, b, null));
            return;
        }
        if (p != null) {
            ed.showPage(p, b == null ? null : b.id);
            a.popTo(ed);
            if (b != null) a.push(new BlockScreen(a, b, p));
        }
    }

    private void claude(String base, boolean share) {
        Site s = hub.site;
        hub.saveSync();
        final Site snap = s.copy();
        snap.id = s.id;
        a.export(base + "-dlya-claude.zip", "application/zip", out -> Pack.claudeZip(snap, hub.store.dir(s.id), out, a.version()), (f, where) -> {
            if (share) a.share(f, "application/zip", "Сделай из этого проекта готовый сайт. Описание и пожелания — в ДЛЯ_CLAUDE.md внутри архива.");
            a.toast(where == null ? "Архив готов" : "Сохранено в «" + where + "»: " + f.getName());
        });
    }

    private void site(String base) {
        Site s = hub.site;
        hub.saveSync();
        final Site snap = s.copy();
        snap.id = s.id;
        a.export(base + "-site.zip", "application/zip", out -> Pack.siteZip(snap, hub.store.dir(s.id), out), (f, where) -> {
            a.toast(where == null ? "Архив готов" : "Сохранено в «" + where + "»: " + f.getName());
            a.share(f, "application/zip", null);
        });
    }

    private void copyText() {
        Site s = hub.site;
        String t = ClaudeDoc.make(s, a.version()) + "\n\n## project.json\n\n```json\n" + s.toJson() + "\n```\n";
        a.copy("Проект для Claude", t);
        int imgs = Pack.images(s).size();
        a.toast("Проект скопирован текстом — вставьте его в чат Claude." + (imgs > 0 ? " Фото (" + imgs + ") так не передаются — приложите их отдельно или отправьте архив." : ""));
    }
}
