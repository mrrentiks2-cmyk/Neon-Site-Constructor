package com.neondrift.site;

import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Настройки страницы: название, адрес, меню, запись блога, SEO, шапка/подвал; копия и удаление. */
final class PageScreen extends Screen {
    private final EditorScreen ed;
    private final Site.Page p;
    private final LinearLayout body;
    private final Form form;
    private TextView fileNote;

    PageScreen(MainActivity a, EditorScreen ed, Site.Page p) {
        super(a);
        this.ed = ed;
        this.p = p;
        header("Страница", p.title);
        ScrollView sv = new ScrollView(a);
        body = ui.col();
        body.setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(48));
        sv.addView(body);
        addView(sv, Ui.lp(Ui.MATCH, 0, 1f));
        form = new Form(a, body, () -> {
            hub.saveSoon();
            if (fileNote != null) fileNote.setText(fileText());
            setSub(p.title);
        });
        build();
    }

    private String fileText() {
        Site s = hub.site;
        return "Адрес на сайте: " + (Gen.domain(s).isEmpty() ? "" : Gen.domain(s) + "/") + s.file(p);
    }

    private void build() {
        body.removeAllViews();
        Site s = hub.site;
        form.section("ОСНОВНОЕ");
        form.text("Название", "Как страница называется в меню", p.title, false, v -> p.title = v.trim().isEmpty() ? "Страница" : v.trim());
        if (p != s.home()) {
            form.text("Адрес (латиницей)", "Пусто — из названия, например: o-nas", p.slug, false, v -> p.slug = Slug.of(v));
        }
        fileNote = form.note(fileText());
        form.choice("Тип", new String[]{"page", "post"}, new String[]{"Обычная страница", "Запись блога"}, p.kind, v -> {
            p.kind = v;
            if (p.post()) {
                p.menu = false;
                if (p.date.isEmpty()) p.date = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(new Date());
            }
            post(this::build);
        });
        if (!p.post()) form.bool("Показывать в меню", "В шапке и подвале (если у сайта 2+ страницы)", p.menu, v -> p.menu = v);
        if (p.post()) {
            form.section("ЗАПИСЬ БЛОГА");
            form.text("Дата (ГГГГ-ММ-ДД)", "2026-10-22", p.date, false, v -> p.date = v.trim());
            form.text("Анонс", "Пара предложений для списка записей", p.excerpt, true, v -> p.excerpt = v);
            form.image("Обложка", "Видна в списке записей и вверху записи", p.cover, 0, v -> p.cover = v);
        }
        form.section("ПОИСКОВИКИ И СОЦСЕТИ");
        form.text("Заголовок для поиска", "Пусто — «" + p.title + " — " + s.name + "»", p.seoTitle, false, v -> p.seoTitle = v);
        form.text("Описание для поиска", "1–2 предложения: что на странице. Пусто — описание сайта", p.seoDescription, true, v -> p.seoDescription = v);
        form.section("ВИД");
        form.bool("Без шапки", "Не показывать шапку на этой странице", p.noHeader, v -> p.noHeader = v);
        form.bool("Без подвала", "Не показывать подвал на этой странице", p.noFooter, v -> p.noFooter = v);

        form.section("ДЕЙСТВИЯ");
        if (p != s.home()) form.button("Сделать главной", false, v -> {
            s.pages.remove(p);
            s.pages.add(0, p);
            hub.saveSoon();
            a.toast("«" + p.title + "» — теперь главная (index.html)");
            build();
        });
        form.button("Открыть в редакторе", false, v -> {
            ed.showPage(p, null);
            a.popTo(ed);
        });
        form.button("Удалить страницу", false, v -> {
            if (s.pages.size() <= 1) {
                a.toast("Это единственная страница — её нельзя удалить");
                return;
            }
            a.confirm("Удалить «" + p.title + "»?", "Вместе со всеми блоками. Вернуть можно кнопкой «Отменить» в редакторе.", "Удалить", true, () -> {
                s.pages.remove(p);
                hub.saveSoon();
                a.back();
            });
        }).setTextColor(0xFFFF6B6B);
    }

    @Override
    boolean back() {
        a.hideKeyboard();
        return false;
    }
}
