package com.neondrift.site;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

/** Неоновая полоска прогресса; без процента — бегущий блик «идёт поиск». */
final class Bar extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG), glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private float value = -1;
    private int shaderW;

    Bar(Context c) {
        super(c);
        track.setColor(Theme.SURFACE2);
        glow.setColor(Theme.alpha(Theme.ACCENT, 70));
        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    /** 0..1, или &lt; 0 — неизвестно сколько. */
    void set(float v) {
        if (v == value) return;
        value = v;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w == 0) return;
        float rad = h / 2f;
        r.set(0, 0, w, h);
        c.drawRoundRect(r, rad, rad, track);
        if (shaderW != w) {
            shaderW = w;
            fill.setShader(new LinearGradient(0, 0, w, 0, Theme.ACCENT, Theme.ACCENT2, Shader.TileMode.CLAMP));
        }
        if (value < 0) {
            float t = (SystemClock.uptimeMillis() % 1600) / 1600f;
            float seg = w * 0.28f, x = -seg + (w + seg) * t;
            r.set(Math.max(0, x), 0, Math.min(w, x + seg), h);
            c.drawRoundRect(r, rad, rad, fill);
            postInvalidateOnAnimation();
            return;
        }
        float fw = Math.max(h, w * Math.min(1f, value));
        if (value <= 0) return;
        r.set(0, 0, fw, h);
        c.drawRoundRect(r, rad, rad, fill);
    }
}
