package com.neondrift.site;

import java.util.Locale;

/** Адрес страницы из названия: «О нас» → «o-nas», «Цены и услуги» → «tseny-i-uslugi». */
final class Slug {
    private Slug() {}

    private static final String[] RU = {"а", "a", "б", "b", "в", "v", "г", "g", "д", "d", "е", "e", "ё", "e", "ж", "zh", "з", "z", "и", "i", "й", "y",
            "к", "k", "л", "l", "м", "m", "н", "n", "о", "o", "п", "p", "р", "r", "с", "s", "т", "t", "у", "u", "ф", "f", "х", "h", "ц", "ts",
            "ч", "ch", "ш", "sh", "щ", "sch", "ъ", "", "ы", "y", "ь", "", "э", "e", "ю", "yu", "я", "ya", "і", "i", "ї", "yi", "є", "e", "ґ", "g"};

    static String of(String s) {
        if (s == null) return "";
        String low = s.toLowerCase(Locale.ROOT);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < low.length(); i++) {
            String c = String.valueOf(low.charAt(i));
            String t = null;
            for (int k = 0; k < RU.length; k += 2) {
                if (RU[k].equals(c)) {
                    t = RU[k + 1];
                    break;
                }
            }
            if (t != null) sb.append(t);
            else if (c.matches("[a-z0-9]")) sb.append(c);
            else sb.append('-');
        }
        String r = sb.toString().replaceAll("-{2,}", "-").replaceAll("^-|-$", "");
        if (r.length() > 48) r = r.substring(0, 48).replaceAll("-$", "");
        return r;
    }
}
