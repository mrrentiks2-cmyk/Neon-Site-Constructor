package com.neondrift.site;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Главный экран: мои сайты, «Новый сайт», открыть проект из файла. */
final class HomeScreen extends Screen {
    private final LinearLayout list;

    HomeScreen(MainActivity a) {
        super(a);
        LinearLayout h = ui.row();
        h.setPadding(ui.dp(20), ui.dp(14), ui.dp(8), ui.dp(6));
        LinearLayout t = ui.col();
        TextView logo = ui.text("Neon Site", 26, Theme.TEXT, true);
        logo.getPaint().setShader(null);
        t.addView(logo);
        t.addView(ui.text("Конструктор сайтов", 13, Theme.MUTED, false), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(3), 0, 0));
        h.addView(t, Ui.lp(0, Ui.WRAP, 1f));
        h.addView(ui.iconButton("settings", Theme.MUTED, 46, 12, v -> a.settings()));
        addView(h);

        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(true);
        list = ui.col();
        list.setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(32));
        sv.addView(list);
        addView(sv, Ui.lp(Ui.MATCH, 0, 1f));
    }

    @Override
    void refresh() {
        list.removeAllViews();
        // большая кнопка «Новый сайт»
        LinearLayout create = ui.row();
        create.setPadding(ui.dp(18), ui.dp(18), ui.dp(18), ui.dp(18));
        create.setBackground(Ui.ripple(gradient(), Ui.round(0xFFFFFFFF, ui.dp(20))));
        ImageView plus = new ImageView(a);
        plus.setImageDrawable(new Glyph("plus", 0xFFFFFFFF));
        plus.setPadding(ui.dp(10), ui.dp(10), ui.dp(10), ui.dp(10));
        plus.setBackground(Ui.oval(0x33FFFFFF));
        create.addView(plus, Ui.lp(ui.dp(48), ui.dp(48)));
        LinearLayout ct = ui.col();
        ct.addView(ui.text("Новый сайт", 19, 0xFFFFFFFF, true));
        TextView cs = ui.text("Из шаблона или с чистого листа", 13.5f, 0xE6FFFFFF, false);
        ct.addView(cs, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(4), 0, 0));
        create.addView(ct, Ui.margins(0, Ui.WRAP, ui.dp(14), 0, 0, 0));
        ((LinearLayout.LayoutParams) ct.getLayoutParams()).weight = 1f;
        create.setOnClickListener(v -> a.push(new TemplatesScreen(a)));
        list.addView(create, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(6), 0, ui.dp(10)));

        LinearLayout imp = tile("folder", Theme.ACCENT2, "Открыть проект из файла", "Архив .zip из Neon Site (например, с другого телефона)", () -> a.pickZip(u -> a.importProject(u.get(0))));
        list.addView(imp, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(18)));

        List<Store.Meta> ms = hub.store.list();
        if (ms.isEmpty()) {
            list.addView(ui.label("КАК ЭТО РАБОТАЕТ"), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(4), ui.dp(6), 0, ui.dp(10)));
            String[][] steps = {
                    {"1", "Выберите шаблон", "Кофейня, услуги, портфолио, блог, мероприятие — или пустой сайт."},
                    {"2", "Меняйте как хотите", "Нажмите на любой блок: тексты, фото, цвета, кнопки, ссылки. Добавляйте и переставляйте блоки и страницы."},
                    {"3", "Пишите пожелания", "У каждого блока есть поле «Пожелания» — опишите словами, что доработать."},
                    {"4", "Пришлите Claude", "«Готово» → «Проект для Claude». Отправьте архив в чат — получите готовый код сайта."}};
            for (String[] s : steps) list.addView(step(s[0], s[1], s[2]), Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(8)));
            return;
        }
        list.addView(ui.label("МОИ САЙТЫ"), Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(4), ui.dp(4), 0, ui.dp(10)));
        for (Store.Meta m : ms) list.addView(card(m), Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(10)));
    }

    private android.graphics.drawable.Drawable gradient() {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR, new int[]{Theme.ACCENT, Theme.mix(Theme.ACCENT, Theme.ACCENT2, 0.85f)});
        g.setCornerRadius(ui.dp(20));
        return g;
    }

    private View step(String n, String title, String text) {
        LinearLayout row = ui.row();
        row.setGravity(Gravity.TOP);
        row.setPadding(ui.dp(14), ui.dp(14), ui.dp(14), ui.dp(14));
        row.setBackground(Ui.round(Theme.SURFACE, ui.dp(16)));
        TextView num = ui.text(n, 16, Theme.ACCENT, true);
        num.setGravity(Gravity.CENTER);
        num.setBackground(Ui.oval(Theme.alpha(Theme.ACCENT, 38)));
        row.addView(num, Ui.lp(ui.dp(34), ui.dp(34)));
        LinearLayout t = ui.col();
        t.addView(ui.text(title, 15.5f, Theme.TEXT, true));
        TextView d = ui.text(text, 13.5f, Theme.MUTED, false);
        d.setLineSpacing(0, 1.2f);
        t.addView(d, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(4), 0, 0));
        row.addView(t, Ui.margins(0, Ui.WRAP, ui.dp(14), 0, 0, 0));
        ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        return row;
    }

    /** Карточка проекта: «обложка» из цветов сайта, название, сведения, меню. */
    private View card(Store.Meta m) {
        LinearLayout c = ui.col();
        c.setBackground(Ui.ripple(Ui.round(Theme.SURFACE, ui.dp(18)), Ui.round(0xFFFFFFFF, ui.dp(18))));
        c.setClipToOutline(true);
        c.setOutlineProvider(Ui.rounded(ui.dp(18)));
        Swatch sw = new Swatch(a, m);
        c.addView(sw, Ui.lp(Ui.MATCH, ui.dp(86)));
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(16), ui.dp(12), ui.dp(4), ui.dp(12));
        LinearLayout t = ui.col();
        t.addView(ui.oneLine(m.name, 17, Theme.TEXT, true));
        String info = m.pages + " " + plural(m.pages, "страница", "страницы", "страниц") + " · " + m.blocks + " " + plural(m.blocks, "блок", "блока", "блоков")
                + " · " + when(m.updated);
        t.addView(ui.oneLine(info, 13, Theme.MUTED, false), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(4), 0, 0));
        row.addView(t, Ui.lp(0, Ui.WRAP, 1f));
        row.addView(ui.iconButton("more", Theme.MUTED, 44, 11, v -> menu(m)));
        c.addView(row);
        c.setOnClickListener(v -> open(m.id));
        return c;
    }

    private void open(String id) {
        try {
            Site s = hub.store.load(id);
            hub.open(s);
            a.push(new EditorScreen(a));
        } catch (Exception e) {
            a.toast("Проект не открывается: " + e.getMessage());
        }
    }

    private void menu(Store.Meta m) {
        LinearLayout p = a.panel.open(m.name);
        a.panel.option(p, "Открыть", null, false, () -> {
            a.panel.close();
            open(m.id);
        });
        a.panel.option(p, "Переименовать", null, false, () -> a.ask("Название сайта", "Например: Кофейня «Зерно»", m.name, "Сохранить", name -> {
            try {
                Site s = hub.store.load(m.id);
                s.name = name;
                hub.store.save(s);
                refresh();
            } catch (Exception e) {
                a.toast("Не получилось: " + e.getMessage());
            }
        }));
        a.panel.option(p, "Сделать копию", "Со всеми страницами и фото", false, () -> {
            a.panel.close();
            hub.io.execute(() -> {
                try {
                    hub.store.duplicate(m.id);
                    a.runOnUiThread(this::refresh);
                } catch (Exception e) {
                    a.runOnUiThread(() -> a.toast("Не получилось: " + e.getMessage()));
                }
            });
        });
        a.panel.option(p, "Удалить", "Сайт и все его фото будут удалены с телефона", false, () -> a.confirm("Удалить «" + m.name + "»?",
                "Это нельзя отменить. Если нужно сохранить — сначала сделайте «Проект для Claude» или копию.", "Удалить", true, () -> {
                    hub.store.delete(m.id);
                    refresh();
                }));
    }

    static String plural(int n, String one, String few, String many) {
        int m10 = n % 10, m100 = n % 100;
        if (m10 == 1 && m100 != 11) return one;
        if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
        return many;
    }

    static String when(long t) {
        long d = System.currentTimeMillis() - t;
        if (d < 60_000) return "только что";
        if (d < 3600_000) return (d / 60_000) + " мин назад";
        if (d < 86400_000L && new SimpleDateFormat("yyyyMMdd", Locale.ROOT).format(new Date(t)).equals(new SimpleDateFormat("yyyyMMdd", Locale.ROOT).format(new Date())))
            return "сегодня в " + new SimpleDateFormat("HH:mm", Locale.ROOT).format(new Date(t));
        return new SimpleDateFormat("d MMM, HH:mm", new Locale("ru")).format(new Date(t));
    }

    /** Мини-«обложка» сайта из его цветов: полоса шапки, заголовок, кнопка. */
    static final class Swatch extends View {
        private final Store.Meta m;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();

        Swatch(MainActivity a, Store.Meta m) {
            super(a);
            this.m = m;
        }

        private static int col(String hex, int def) {
            try {
                return Color.parseColor(hex);
            } catch (Exception e) {
                return def;
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            float d = getResources().getDisplayMetrics().density;
            int bg = col(m.bg, 0xFFFFFFFF), pr = col(m.primary, 0xFF2B59FF), ac = col(m.accent, 0xFFFF7A1A), tx = col(m.text, 0xFF111111);
            p.setShader(null);
            p.setColor(bg);
            c.drawRect(0, 0, w, h, p);
            // свечение акцентом
            p.setShader(new LinearGradient(w * 0.55f, 0, w, h, Theme.alpha(ac, 0), Theme.alpha(ac, 90), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            // «шапка»
            p.setColor(Theme.alpha(tx, 200));
            r.set(16 * d, 12 * d, 64 * d, 17 * d);
            c.drawRoundRect(r, 3 * d, 3 * d, p);
            p.setColor(pr);
            r.set(w - 64 * d, 10 * d, w - 16 * d, 20 * d);
            c.drawRoundRect(r, 5 * d, 5 * d, p);
            // «заголовок»
            p.setColor(tx);
            r.set(16 * d, 34 * d, Math.min(w - 16 * d, 200 * d), 44 * d);
            c.drawRoundRect(r, 4 * d, 4 * d, p);
            p.setColor(Theme.alpha(tx, 110));
            r.set(16 * d, 50 * d, Math.min(w - 16 * d, 150 * d), 55 * d);
            c.drawRoundRect(r, 3 * d, 3 * d, p);
            p.setColor(pr);
            r.set(16 * d, 64 * d, 70 * d, 76 * d);
            c.drawRoundRect(r, 5 * d, 5 * d, p);
        }
    }

    @SuppressWarnings("unused")
    private static FrameLayout.LayoutParams fl(int w, int h) {
        return new FrameLayout.LayoutParams(w, h);
    }
}
