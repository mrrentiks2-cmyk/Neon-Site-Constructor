package com.neondrift.site;

import android.widget.LinearLayout;
import android.widget.ScrollView;

/** Настройки сайта: название, описание, домен, значок, картинка для соцсетей, шапка и подвал, пожелания, код. */
final class SiteScreen extends Screen {
    private final LinearLayout body;
    private final Form form;

    SiteScreen(MainActivity a) {
        super(a);
        header("Сайт", "Общие настройки");
        ScrollView sv = new ScrollView(a);
        body = ui.col();
        body.setPadding(ui.dp(16), ui.dp(4), ui.dp(16), ui.dp(48));
        sv.addView(body);
        addView(sv, Ui.lp(Ui.MATCH, 0, 1f));
        form = new Form(a, body, () -> hub.saveSoon());
        form.emptyImage = "Не выбрано";
        build();
    }

    private void build() {
        Site s = hub.site;
        body.removeAllViews();
        form.section("ПОЖЕЛАНИЯ КО ВСЕМУ САЙТУ — ДЛЯ CLAUDE");
        form.note("Опишите своими словами, каким должен быть сайт: настроение, примеры, что добавить (онлайн-запись, калькулятор, анимации, тёмная тема…). "
                + "Это главное, что прочитает Claude в «Проекте для Claude».");
        form.text(null, "Например: хочу в стиле минимализма, побольше воздуха; добавь онлайн-запись на услуги…", s.notes, true, v -> s.notes = v);

        form.section("О САЙТЕ");
        form.text("Название", "Кофейня «Зерно и пар»", s.name, false, v -> s.name = v.trim().isEmpty() ? "Мой сайт" : v.trim());
        form.text("Описание", "1–2 предложения: кто вы и что предлагаете — для поисковиков и превью ссылок", s.description, true, v -> s.description = v.trim());
        form.text("Домен (если есть)", "example.ru или имя.github.io", s.domain, false, v -> s.domain = v.trim());
        form.choice("Язык сайта", new String[]{"ru", "en", "uk", "be", "kk", "de"}, new String[]{"Русский", "English", "Українська", "Беларуская", "Қазақша", "Deutsch"},
                s.lang, v -> s.lang = v);

        form.section("ЗНАЧКИ И КАРТИНКИ");
        form.image("Значок сайта (favicon)", "Квадратная картинка — видна на вкладке браузера", s.favicon, 256, v -> s.favicon = v);
        form.image("Картинка для соцсетей", "Показывается, когда ссылкой делятся в мессенджерах (лучше 1200×630)", s.ogImage, 1200, v -> s.ogImage = v);

        form.section("НА ВСЕХ СТРАНИЦАХ");
        if (s.header == null) s.header = Blocks.make("header", "left");
        if (s.footer == null) s.footer = Blocks.make("footer", "columns");
        form.button("Шапка и меню", false, v -> a.push(new BlockScreen(a, s.header, null)));
        form.button("Подвал", false, v -> a.push(new BlockScreen(a, s.footer, null)));

        form.section("ДЛЯ ОПЫТНЫХ");
        form.note("Код в <head> — счётчики (Яндекс Метрика и т. п.), подтверждение домена. Работает только на готовом сайте.");
        form.code(null, "<!-- код счётчика -->", s.headCode, v -> s.headCode = v);
    }

    @Override
    boolean back() {
        a.hideKeyboard();
        return false;
    }
}
